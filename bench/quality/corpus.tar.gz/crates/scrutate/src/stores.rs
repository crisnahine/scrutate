

































use std::path::{Path, PathBuf};
use std::sync::atomic::AtomicBool;
use std::sync::Arc;

use anyhow::Result;

use crate::index::{self, UpdateStats};
use crate::ops;
use crate::search::Searcher;
use crate::textindex::{self, TextStats};


#[derive(Clone, Debug, PartialEq)]
pub enum Changes {

    All,

    Named(Named),
}



#[derive(Clone, Debug, Default, PartialEq)]
pub struct Named {
    pub code: Vec<String>,
    pub text: Vec<String>,
}



#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Writer {

    Index,

    IndexCode,

    IndexText,

    GrepUpdate,

    Watch,

    Reindex,
}

impl Writer {
    fn code(self) -> bool {
        !matches!(self, Writer::IndexText | Writer::GrepUpdate)
    }



    fn text(self, root: &Path) -> bool {
        match self {
            Writer::IndexCode => false,
            Writer::Index | Writer::IndexText | Writer::GrepUpdate => true,
            Writer::Watch | Writer::Reindex => textindex::exists(root),
        }
    }


    fn progress(self) -> bool {
        matches!(self, Writer::Index | Writer::IndexCode | Writer::IndexText) && std::io::IsTerminal::is_terminal(&std::io::stderr())
    }
}


#[derive(Debug, Default)]
pub struct Updated {
    pub code: Option<UpdateStats>,
    pub text: Option<TextStats>,
}




pub fn update(root: &Path, w: Writer, force: bool) -> Result<Updated> {
    if w.code() {
        let mut repo = Repo::open_to_update(root, force)?;
        return repo.update_stores(w, &Changes::All, force);
    }
    let root = std::fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    Ok(Updated { code: None, text: Some(update_text(&root, &Changes::All, force, w.progress())?) })
}


fn update_text(root: &Path, changes: &Changes, force: bool, progress: bool) -> Result<TextStats> {
    let r = match changes {
        Changes::Named(n) if !force => textindex::update_paths(root, &n.text),
        _ => textindex::update(root, force, progress),
    };
    match r {
        Err(e) if e.is::<textindex::Damaged>() => {
            eprintln!("[scrutate] text index damaged ({e:#}); rebuilding");
            textindex::update(root, true, progress)
        }
        r => r,
    }
}



pub struct Repo {

    searcher: Option<Searcher>,
    root: PathBuf,

    stale: bool,

    updated: bool,
}

impl Repo {

    pub fn open(root: &Path) -> Result<Repo> {
        let searcher = crate::open(root)?;
        Ok(Repo { root: searcher.ix.root.clone(), searcher: Some(searcher), stale: false, updated: false })
    }



    pub fn open_to_update(root: &Path, force: bool) -> Result<Repo> {
        match Repo::open(root) {
            Err(e) if force && e.is::<index::Newer>() => {
                index::wipe_index(root);
                Repo::open(root)
            }
            r => r,
        }
    }

    pub fn into_searcher(self) -> Searcher {
        self.searcher.expect("the index was not reopened after a rebuild")
    }


    pub fn is_stale(&self) -> bool {
        self.stale
    }


    pub fn take_updated(&mut self) -> bool {
        std::mem::take(&mut self.updated)
    }


    pub fn set_cancel(&mut self, cancel: Arc<AtomicBool>) {
        if let Some(s) = &mut self.searcher {
            // an update the operation runs (a reindex, the scan before a read) stops at its next batch
            s.ix.cancel = Arc::clone(&cancel);
            s.cancel = cancel;
        }
    }





    fn reopened(&mut self) -> Result<()> {
        match &mut self.searcher {
            None => {
                self.reopen(false)?;
            }
            Some(s) => {
                s.ix.reopen_if_replaced()?;
                if let Some(n) = s.ix.newer().filter(|n| !n.readable) {
                    return Err(n.into());
                }
            }
        }
        Ok(())
    }



    pub fn update(&mut self, force: bool) -> Result<UpdateStats> {
        self.update_code(&Changes::All, force, false)
    }


    fn update_code(&mut self, changes: &Changes, force: bool, progress: bool) -> Result<UpdateStats> {
        self.reopened()?;
        self.ix.progress |= progress;
        let r = match changes {
            Changes::Named(n) if !force => self.ix.update_paths(&n.code, true),
            _ => self.ix.update(force),
        };
        let r = match r {
            Err(e) if index::error_is_corruption(&e) => self.recover(&e),
            other => other,
        };
        self.updated |= r.is_ok();
        r
    }



    pub fn update_stores(&mut self, w: Writer, changes: &Changes, force: bool) -> Result<Updated> {
        let code = if w.code() { Some(self.update_code(changes, force, w.progress())?) } else { None };
        let text = if w.text(&self.root) { Some(update_text(&self.root, changes, force, w.progress())?) } else { None };
        Ok(Updated { code, text })
    }



    // shortcut: a rebuild after damage and the text index do not see the flag, give them the flag if that matters
    pub fn update_until(&mut self, force: bool, cancel: Arc<AtomicBool>) -> Result<Updated> {
        self.reopened()?;
        self.ix.cancel = cancel;
        let r = self.update_stores(Writer::Reindex, &Changes::All, force);
        if let Some(s) = &mut self.searcher {
            s.ix.cancel = Default::default();
        }
        r
    }





    pub fn refresh(&mut self, min_interval: f64) -> Result<Option<UpdateStats>> {
        self.reopened()?;
        match self.ix.refresh_or_fail(min_interval) {
            Err(e) if index::error_is_corruption(&e) => self.recover(&e).map(Some),
            Err(e) if e.is::<index::Busy>() && !self.ix.has_files()? => Err(index::BeingBuilt.into()),
            Err(e) if e.is::<index::Newer>() => Err(e),
            Err(e) => {
                if !self.stale {
                    eprintln!("[scrutate] index not updated ({e:#}); answering from it as it is");
                    self.stale = true;
                }
                Ok(None)
            }
            Ok(st) => {
                self.stale &= st.is_none();
                self.updated |= st.is_some();
                Ok(st)
            }
        }
    }



    pub fn run(&mut self, op: &ops::Op, min_interval: f64) -> Result<ops::Answer> {
        if !matches!(op, ops::Op::Read { symbol: None, .. } | ops::Op::Reindex { .. }) {
            self.refresh(min_interval)?;
        }
        self.run_as_is(op)
    }







    pub fn run_as_is(&mut self, op: &ops::Op) -> Result<ops::Answer> {
        if let ops::Op::Reindex { force } = op {
            let up = self.update_stores(Writer::Reindex, &Changes::All, *force)?;
            return Ok(ops::Answer::Reindexed(up.code.unwrap_or_default()));
        }
        let first = self.recovering(|s| ops::run(s, op));
        if self.searcher.is_none() {
            return first;
        }
        let named = op.named_paths();
        let mut paths = named.clone();
        if let Ok(a) = &first {
            paths.extend(a.cited().into_iter().map(str::to_string));
        }
        let paths: Vec<&str> = paths.iter().map(String::as_str).collect();
        let stale = match self.ix.stale(&paths) {
            Ok(mut s) => {
                s.extend(self.ix.unindexed(&named));
                s
            }
            Err(_) => return first,
        };
        if stale.is_empty() {
            return first;
        }
        match self.ix.update_paths(&stale, false) {
            Ok(_) => self.recovering(|s| ops::run(s, op)),
            Err(e) if index::error_is_corruption(&e) => {
                self.recover(&e)?;
                self.recovering(|s| ops::run(s, op))
            }
            // another writer holds the lock, or the index cannot be written: answer as it is
            Err(_) => first,
        }
    }



    pub fn recovering<T>(&mut self, mut f: impl FnMut(&mut Searcher) -> Result<T>) -> Result<T> {
        self.reopened()?;
        match f(self) {
            Err(e) if index::error_is_corruption(&e) => {
                self.recover(&e)?;
                f(self)
            }
            other => other,
        }
    }



    pub fn recover(&mut self, why: &anyhow::Error) -> Result<UpdateStats> {
        eprintln!("[scrutate] index damaged ({why:#}); rebuilding");
        let progress = self.searcher.as_ref().is_some_and(|s| s.ix.progress);
        self.searcher = None; // the database is closed before its files are deleted
        index::wipe_index(&self.root);
        self.reopen(progress)
    }

    fn reopen(&mut self, progress: bool) -> Result<UpdateStats> {
        let mut s = crate::open(&self.root)?;
        s.ix.progress = progress;
        let st = s.ix.update(true);
        self.searcher = Some(s);
        st
    }
}

impl std::ops::Deref for Repo {
    type Target = Searcher;
    fn deref(&self) -> &Searcher {
        self.searcher.as_ref().expect("the index was not reopened after a rebuild")
    }
}

impl std::ops::DerefMut for Repo {
    fn deref_mut(&mut self) -> &mut Searcher {
        self.searcher.as_mut().expect("the index was not reopened after a rebuild")
    }
}



pub fn recorded(root: &Path) -> std::collections::HashMap<String, (index::Stat, String)> {
    index::recorded(root)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_rebuild_that_could_not_reopen_the_index_is_an_error_until_it_can() {
        let root = std::env::temp_dir().join(format!("scrutate_reopen_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        let mut repo = Repo { searcher: None, root: root.clone(), stale: false, updated: false };
        let op = ops::Op::Symbol { name: "f".into(), limit: 5 };
        repo.set_cancel(Arc::default());
        assert!(repo.update(false).is_err());
        assert!(repo.refresh(0.0).is_err());
        assert!(repo.run(&op, 0.0).is_err());
        assert!(repo.run_as_is(&op).is_err());
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("a.py"), "def f():\n    return 1\n").unwrap();
        assert!(matches!(repo.run_as_is(&op), Ok(ops::Answer::Hits { ref hits, .. }) if hits.len() == 1));
        drop(repo);
        let _ = std::fs::remove_dir_all(&root);
    }
}
