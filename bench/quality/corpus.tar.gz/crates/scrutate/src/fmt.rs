


use std::borrow::Cow;

use crate::search::Hit;



pub fn unshown(s: &str) -> Cow<'_, str> {
    if !s.contains('\\') {
        return Cow::Borrowed(s);
    }
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(i) = rest.find('\\') {
        out.push_str(&rest[..i]);
        let tail = &rest[i + 1..];
        let hex = |digits: Option<&str>| digits.and_then(|d| u32::from_str_radix(d, 16).ok()).and_then(char::from_u32);
        let (c, used) = match tail.as_bytes().first() {
            Some(b'\\') => (Some('\\'), 1),
            Some(b'n') => (Some('\n'), 1),
            Some(b'r') => (Some('\r'), 1),
            Some(b't') => (Some('\t'), 1),
            Some(b'x') => (hex(tail.get(1..3)), 3),
            Some(b'u') => match tail.find('}') {
                Some(end) if tail.starts_with("u{") => (hex(tail.get(2..end)), end + 1),
                _ => (None, 0),
            },
            _ => (None, 0),
        };
        match c {
            Some(c) => {
                out.push(c);
                rest = &tail[used..];
            }
            None => {
                out.push('\\');
                rest = tail;
            }
        }
    }
    out.push_str(rest);
    Cow::Owned(out)
}




pub fn shown(s: &str) -> Cow<'_, str> {
    escaped(s, true)
}

fn escaped(s: &str, backslash: bool) -> Cow<'_, str> {
    if !s.chars().any(|c| c.is_control() || (backslash && c == '\\')) {
        return Cow::Borrowed(s);
    }
    let mut out = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '\\' if backslash => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c.is_control() && (c as u32) < 0x100 => out.push_str(&format!("\\x{:02x}", c as u32)),
            c if c.is_control() => out.push_str(&format!("\\u{{{:x}}}", c as u32)),
            c => out.push(c),
        }
    }
    Cow::Owned(out)
}


const ECHO_CHARS: usize = 200;



pub fn echo(s: &str) -> String {
    let n = s.chars().count();
    if n <= ECHO_CHARS {
        return escaped(s, false).into_owned();
    }
    let head: String = s.chars().take(ECHO_CHARS).collect();
    format!("{}... (cut: {n} characters in all)", escaped(&head, false))
}


pub fn loc(h: &Hit) -> String {
    format!("{}:{}-{}", shown(&h.path), h.start, h.end)
}

pub fn fmt_hits(hits: &[Hit], words: &[String], snippet: bool, why: bool) -> String {
    if hits.is_empty() {
        return "(no results)".to_string();
    }
    hit_blocks(hits, words, snippet, why).join("\n")
}


pub fn hit_blocks(hits: &[Hit], words: &[String], snippet: bool, why: bool) -> Vec<String> {
    let mut out = Vec::with_capacity(hits.len());
    for h in hits {
        let name = if h.qualname.is_empty() { &h.name } else { &h.qualname };
        let mut head = format!("{}  [{}] {}", loc(h), h.kind, shown(name));
        if why && !h.why.is_empty() {
            head.push_str(&format!("  ({})", h.why.iter().map(|(k, _)| k.as_str()).collect::<Vec<_>>().join(", ")));
        }
        if snippet {
            let body = h.snippet(words, 8);
            head.push('\n');
            head.push_str(&body.split('\n').map(|l| format!("    {l}")).collect::<Vec<_>>().join("\n"));
        }
        out.push(head);
    }
    out
}

pub fn hits_json(hits: &[Hit]) -> serde_json::Value {
    serde_json::Value::Array(
        hits.iter()
            .map(|h| {
                let why: serde_json::Map<String, serde_json::Value> = h.why.iter().cloned().collect();
                serde_json::json!({
                    "id": h.loc(), "path": h.path, "start": h.start, "end": h.end,
                    "name": if h.qualname.is_empty() { &h.name } else { &h.qualname },
                    "kind": h.kind, "score": h.score, "why": why,
                })
            })
            .collect(),
    )
}
