












use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::time::Instant;

use anyhow::{anyhow, bail, Context, Result};
use grep_matcher::{LineTerminator, Match as MatchSpan, Matcher, NoCaptures, NoError};
use grep_regex::RegexMatcherBuilder;
use grep_searcher::{BinaryDetection, Searcher, SearcherBuilder, Sink, SinkContext, SinkMatch};
use ignore::{overrides::OverrideBuilder, WalkBuilder, WalkState};

#[path = "foldfind.rs"]
mod foldfind;
#[path = "source.rs"]
mod source;
use source::{file_worker, FileWorker};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Mode {
    Regex,
    Literal,

    Identifier,

    Fuzzy {
        max_edits: u8,
    },

    Pcre2,

    FuzzyRegex {
        max_edits: u8,
    },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Case {
    Sensitive,
    Insensitive,

    Smart,
}


#[derive(Clone, Debug)]
pub struct Pattern {
    pub text: String,
    pub mode: Mode,
    pub case: Case,
    pub word: bool,
    pub multiline: bool,

    pub regex_size_limit: usize,
    pub dfa_size_limit: usize,
}

impl Default for Pattern {
    fn default() -> Self {
        Pattern {
            text: String::new(),
            mode: Mode::Regex,
            case: Case::Sensitive,
            word: false,
            multiline: false,
            regex_size_limit: 20 * (1 << 20),
            dfa_size_limit: 10 * (1 << 20),
        }
    }
}


#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Report {

    #[default]
    Lines,

    Counts,

    Files,
}


#[derive(Clone, Debug)]
pub struct Query {
    pub pattern: Pattern,

    pub invert: bool,
    pub report: Report,

    pub before: usize,
    pub after: usize,

    pub max_count: Option<u64>,

    pub max_results: Option<u64>,





    pub first_in_path_order: bool,

    pub want_bytes: bool,


    pub want_spans: bool,


    pub text_spans: bool,


    pub raw_member_names: bool,

    pub with_filename: bool,

    pub line_numbers: bool,
}

impl Default for Query {
    fn default() -> Self {
        Query {
            pattern: Pattern::default(),
            invert: false,
            report: Report::Lines,
            before: 0,
            after: 0,
            max_count: None,
            max_results: None,
            first_in_path_order: false,
            want_bytes: false,
            want_spans: false,
            text_spans: false,
            raw_member_names: false,
            with_filename: true,
            line_numbers: true,
        }
    }
}


#[derive(Clone, Debug)]
pub enum Paths {

    Walk(Vec<PathBuf>),


    List { root: PathBuf, files: Vec<String> },



    Memory(Vec<(String, Vec<u8>)>),
}


#[derive(Clone, Debug)]
pub struct Files {
    pub paths: Paths,
    pub hidden: bool,
    pub no_ignore: bool,
    pub follow_links: bool,
    pub max_filesize: Option<u64>,
    pub max_depth: Option<usize>,
    pub globs: Vec<String>,

    pub scoped_globs: Option<Arc<ScopedGlobs>>,

    pub types: Vec<String>,

    pub search_zip: bool,




    pub paths_as_given: bool,


    pub cwd: Option<PathBuf>,
    pub threads: usize,


    pub small_tree: Option<usize>,


    pub split_file_bytes: u64,
}

impl Default for Files {
    fn default() -> Self {
        Files {
            paths: Paths::Walk(Vec::new()),
            hidden: false,
            no_ignore: false,
            follow_links: false,
            max_filesize: None,
            max_depth: None,
            globs: Vec::new(),
            scoped_globs: None,
            types: Vec::new(),
            search_zip: false,
            paths_as_given: false,
            cwd: None,
            threads: 0,
            small_tree: None,
            split_file_bytes: 64 << 20,
        }
    }
}

impl Files {

    pub fn walk(roots: Vec<PathBuf>) -> Files {
        Files { paths: Paths::Walk(roots), ..Files::default() }
    }


    pub fn list(root: PathBuf, files: Vec<String>) -> Files {
        Files { paths: Paths::List { root, files }, ..Files::default() }
    }
}



#[derive(Clone, Debug)]
pub struct Line {

    pub path: Arc<str>,

    pub path_bytes: Option<Arc<[u8]>>,
    pub line: u64,
    pub column: u64,
    pub text: String,


    pub spans: Vec<(usize, usize)>,
}


#[derive(Clone, Debug)]
pub enum Record {
    Match(Line),

    Context(Line),

    Count {
        path: Arc<str>,
        path_bytes: Option<Arc<[u8]>>,
        count: u64,
    },

    File {
        path: Arc<str>,
        path_bytes: Option<Arc<[u8]>>,
    },


    Note {
        path: Arc<str>,
        path_bytes: Option<Arc<[u8]>>,
        text: String,
    },
}

impl Record {
    pub fn path(&self) -> &Arc<str> {
        match self {
            Record::Match(l) | Record::Context(l) => &l.path,
            Record::Count { path, .. } | Record::File { path, .. } | Record::Note { path, .. } => path,
        }
    }

    pub fn path_bytes(&self) -> Option<&[u8]> {
        match self {
            Record::Match(l) | Record::Context(l) => l.path_bytes.as_deref(),
            Record::Count { path_bytes, .. } | Record::File { path_bytes, .. } | Record::Note { path_bytes, .. } => path_bytes.as_deref(),
        }
    }


    pub fn order(&self) -> u64 {
        match self {
            Record::Match(l) | Record::Context(l) => l.line,
            Record::Note { .. } => u64::MAX,
            Record::Count { .. } | Record::File { .. } => 0,
        }
    }
}


pub enum Output<'a> {


    Records(&'a mut dyn FnMut(Record)),

    Plain(Arc<PlainSink>),
}


pub const STDIN_LABEL: &str = "<stdin>";

#[derive(Debug, Default, Clone, serde::Serialize)]
pub struct Stats {
    pub files_searched: u64,
    pub files_matched: u64,
    pub matches: u64,
    pub bytes_searched: u64,
    pub errors: u64,
    pub elapsed_ms: f64,
    pub cancelled: bool,

    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub failures: Vec<String>,
}

// ------------------------------------------------------------------------- fuzzy matcher





#[derive(Clone)]
pub struct FuzzyMatcher {
    fwd: Peq,

    rev: Peq,
    m: usize,
    k: usize,
    prefilter: Option<aho_corasick::AhoCorasick>,

    long: Option<Box<(Blocks, Blocks)>>,
}


pub const FUZZY_MAX: usize = 4096;


#[inline]
pub(crate) fn wide_char(hay: &[u8], i: usize) -> (Option<char>, usize) {
    let n = match hay[i] {
        0xC2..=0xDF => 2,
        0xE0..=0xEF => 3,
        0xF0..=0xF4 => 4,
        _ => return (None, 1),
    };
    match hay.get(i..i + n).and_then(|b| std::str::from_utf8(b).ok()) {
        Some(s) => (s.chars().next(), n),
        None => (None, 1),
    }
}

#[inline]
fn unit_len(hay: &[u8], i: usize) -> usize {
    if hay[i] < 0x80 {
        1
    } else {
        wide_char(hay, i).1
    }
}



fn fold_class(c: char) -> Vec<char> {
    use regex_syntax::hir::{ClassUnicode, ClassUnicodeRange};
    let mut cls = ClassUnicode::new([ClassUnicodeRange::new(c, c)]);
    if cls.try_case_fold_simple().is_err() {
        return vec![c];
    }
    cls.iter().flat_map(|r| (r.start() as u32..=r.end() as u32).filter_map(char::from_u32)).collect()
}


fn fuzzy_classes(pattern: &str, fold: bool) -> Vec<Vec<char>> {
    pattern.chars().map(|c| if fold { fold_class(c) } else { vec![c] }).collect()
}





pub fn fuzzy_pieces(pattern: &str, max_edits: u8, fold: bool) -> Option<Vec<Vec<u8>>> {
    let classes = fuzzy_classes(pattern, fold);
    let n = max_edits as usize + 1;
    let len = classes.len() / n;
    if len == 0 {
        return None;
    }
    let mut out: Vec<String> = Vec::new();
    for i in 0..n {
        let mut spellings = vec![String::new()];
        for cls in &classes[i * len..if i == n - 1 { classes.len() } else { (i + 1) * len }] {
            let mut alts: Vec<char> = cls.iter().copied().filter(|c| !c.is_ascii()).collect();
            alts.extend(cls.iter().copied().find(char::is_ascii));
            spellings = spellings.iter().flat_map(|s| alts.iter().map(move |a| format!("{s}{a}"))).collect();
            if out.len() + spellings.len() > 64 {
                return None;
            }
        }
        out.extend(spellings);
    }
    Some(out.into_iter().map(String::into_bytes).collect())
}



#[derive(Clone)]
struct Peq {
    ascii: [u128; 128],

    wide: Vec<(char, u128)>,
}

impl Peq {
    fn new(classes: &[Vec<char>]) -> Peq {
        let mut p = Peq { ascii: [0; 128], wide: Vec::new() };
        for (j, cls) in classes.iter().enumerate().take(128) {
            for &c in cls {
                if c.is_ascii() {
                    p.ascii[c as usize] |= 1 << j;
                } else if let Some(e) = p.wide.iter_mut().find(|e| e.0 == c) {
                    e.1 |= 1 << j;
                } else {
                    p.wide.push((c, 1 << j));
                }
            }
        }
        p.ascii[b'\n' as usize] = 0;
        p.wide.sort_by_key(|e| e.0);
        p
    }


    #[inline]
    fn at(&self, hay: &[u8], i: usize) -> (u128, usize) {
        let b = hay[i];
        if b < 0x80 {
            return (self.ascii[b as usize], 1);
        }
        let (c, n) = wide_char(hay, i);
        (c.and_then(|c| self.wide.binary_search_by_key(&c, |e| e.0).ok()).map_or(0, |x| self.wide[x].1), n)
    }
}



#[derive(Clone)]
struct Blocks {
    words: usize,
    m: usize,

    ascii: Vec<u64>,

    wide: Vec<char>,
    rows: Vec<u64>,
    zero: Vec<u64>,
}

impl Blocks {
    fn new(classes: &[Vec<char>]) -> Blocks {
        let words = classes.len().div_ceil(64);
        let mut ascii = vec![0u64; 128 * words];
        let mut wide: std::collections::BTreeMap<char, Vec<u64>> = Default::default();
        for (j, cls) in classes.iter().enumerate() {
            for &c in cls {
                if c.is_ascii() {
                    ascii[c as usize * words + j / 64] |= 1 << (j % 64);
                } else {
                    wide.entry(c).or_insert_with(|| vec![0; words])[j / 64] |= 1 << (j % 64);
                }
            }
        }
        for w in 0..words {
            ascii[b'\n' as usize * words + w] = 0;
        }
        let (wide, rows): (Vec<char>, Vec<Vec<u64>>) = wide.into_iter().unzip();
        Blocks { words, m: classes.len(), ascii, wide, rows: rows.concat(), zero: vec![0; words] }
    }


    #[inline]
    fn eq_at(&self, hay: &[u8], i: usize) -> (&[u64], usize) {
        let b = hay[i];
        if b < 0x80 {
            let r = b as usize * self.words;
            return (&self.ascii[r..r + self.words], 1);
        }
        let (c, n) = wide_char(hay, i);
        match c.and_then(|c| self.wide.binary_search(&c).ok()) {
            Some(r) => (&self.rows[r * self.words..(r + 1) * self.words], n),
            None => (&self.zero, n),
        }
    }

    fn start(&self) -> (Vec<u64>, Vec<u64>) {
        let mut pv = vec![u64::MAX; self.words];
        if !self.m.is_multiple_of(64) {
            pv[self.words - 1] = (1u64 << (self.m % 64)) - 1;
        }
        (pv, vec![0; self.words])
    }



    fn step(&self, pv: &mut [u64], mv: &mut [u64], eq: &[u64]) -> isize {
        let last = self.words - 1;
        let top = 1u64 << ((self.m - 1) % 64);
        let (mut carry, mut ph_in, mut mh_in, mut delta) = (0u64, 0u64, 0u64, 0isize);
        for w in 0..self.words {
            let eq = eq[w];
            let xv = eq | mv[w];
            let (s1, o1) = (eq & pv[w]).overflowing_add(pv[w]);
            let (s2, o2) = s1.overflowing_add(carry);
            carry = (o1 | o2) as u64;
            let xh = (s2 ^ pv[w]) | eq;
            let ph = mv[w] | !(xh | pv[w]);
            let mh = pv[w] & xh;
            if w == last {
                delta = if ph & top != 0 {
                    1
                } else if mh & top != 0 {
                    -1
                } else {
                    0
                };
            }
            let ph_s = (ph << 1) | ph_in;
            let mh_s = (mh << 1) | mh_in;
            ph_in = ph >> 63;
            mh_in = mh >> 63;
            pv[w] = mh_s | !(xv | ph_s);
            mv[w] = ph_s & xv;
        }
        if !self.m.is_multiple_of(64) {
            let mask = (1u64 << (self.m % 64)) - 1;
            pv[last] &= mask;
            mv[last] &= mask;
        }
        delta
    }
}



#[inline]
fn myers_step(eq: u128, pv: &mut u128, mv: &mut u128, top: u128, mask: u128) -> isize {
    let xv = eq | *mv;
    let xh = (((eq & *pv).wrapping_add(*pv)) ^ *pv) | eq;
    let mut ph = *mv | !(xh | *pv);
    let mut mh = *pv & xh;
    let delta = if ph & top != 0 {
        1
    } else if mh & top != 0 {
        -1
    } else {
        0
    };
    ph = (ph << 1) & mask;
    mh = (mh << 1) & mask;
    *pv = (mh | !(xv | ph)) & mask;
    *mv = ph & xv;
    delta
}

impl FuzzyMatcher {
    pub fn new(pattern: &str, max_edits: u8, fold_case: bool) -> Result<FuzzyMatcher> {
        let classes = fuzzy_classes(pattern, fold_case);
        let m = classes.len();
        if m == 0 || m > FUZZY_MAX {
            bail!("fuzzy patterns must be 1..={FUZZY_MAX} characters");
        }
        if max_edits as usize >= m {
            bail!("the number of edits ({max_edits}) must be smaller than the pattern length ({m} characters)");
        }
        let reversed: Vec<Vec<char>> = classes.iter().rev().cloned().collect();
        let prefilter = fuzzy_pieces(pattern, max_edits, fold_case)
            .filter(|ps| ps.iter().all(|p| p.len() >= 2))
            .and_then(|ps| aho_corasick::AhoCorasick::builder().ascii_case_insensitive(fold_case).build(ps).ok());
        let long = (m > 128).then(|| Box::new((Blocks::new(&classes), Blocks::new(&reversed))));
        Ok(FuzzyMatcher { fwd: Peq::new(&classes), rev: Peq::new(&reversed), m, k: max_edits as usize, prefilter, long })
    }


    fn line_bounds(hay: &[u8], at: usize, pos: usize) -> (usize, usize) {
        let start = hay[at..pos].iter().rposition(|&b| b == b'\n').map(|i| at + i + 1).unwrap_or(at);
        let end = hay[pos..].iter().position(|&b| b == b'\n').map(|i| pos + i).unwrap_or(hay.len());
        (start, end)
    }


    fn first_end_filtered(&self, hay: &[u8], at: usize) -> Option<(usize, usize)> {
        let Some(ac) = &self.prefilter else {
            return self.first_end(hay, at);
        };
        let mut from = at;
        while from < hay.len() {
            let found = ac.find(&hay[from..])?;
            let (ls, le) = Self::line_bounds(hay, from, from + found.start());
            if let Some((end, d)) = self.first_end(&hay[..le], ls) {
                return Some((end, d));
            }
            from = le + 1;
        }
        None
    }


    fn first_end(&self, hay: &[u8], at: usize) -> Option<(usize, usize)> {
        let mut i = at;
        if let Some(b) = &self.long {
            let (fwd, _) = &**b;
            let (mut pv, mut mv) = fwd.start();
            let mut score = self.m as isize;
            while i < hay.len() {
                if hay[i] == b'\n' {
                    (pv, mv) = fwd.start();
                    score = self.m as isize;
                    i += 1;
                    continue;
                }
                let (eq, n) = fwd.eq_at(hay, i);
                score += fwd.step(&mut pv, &mut mv, eq);
                i += n;
                if score <= self.k as isize {
                    return Some((i, score as usize));
                }
            }
            return None;
        }
        let m = self.m;
        let top = 1u128 << (m - 1);
        let mask = if m == 128 { u128::MAX } else { (1u128 << m) - 1 };
        let mut pv = mask;
        let mut mv = 0u128;
        let mut score = m as isize;
        while i < hay.len() {
            let c = hay[i];
            let (eq, n) = if c < 0x80 {
                if c == b'\n' {
                    pv = mask;
                    mv = 0;
                    score = m as isize;
                    i += 1;
                    continue;
                }
                (self.fwd.ascii[c as usize], 1)
            } else {
                self.fwd.at(hay, i)
            };
            score += myers_step(eq, &mut pv, &mut mv, top, mask);
            i += n;
            if score <= self.k as isize {
                return Some((i, score as usize));
            }
        }
        None
    }




    fn start_for(&self, hay: &[u8], end: usize, d: usize) -> usize {
        let m = self.m;
        // the window: back to the line start or m + k characters, whichever is nearer
        let units = m + self.k;
        let (mut lo, mut n) = (end, 0);
        while lo > 0 && n < units && hay[lo - 1] != b'\n' && end - lo < 4 * units {
            lo -= 1;
            if hay[lo] & 0xC0 != 0x80 {
                n += 1;
            }
        }
        if n < units && end - lo >= 4 * units {
            let stop = (lo + 3).min(end);
            while lo < stop && hay[lo] & 0xC0 == 0x80 {
                lo += 1;
            }
        }
        let mut starts = Vec::with_capacity(units);
        let mut i = lo;
        while i < end {
            starts.push(i);
            i += unit_len(hay, i);
        }
        let mut best = None;
        if let Some(b) = &self.long {
            let (_, rev) = &**b;
            let (mut pv, mut mv) = rev.start();
            let mut score = m as isize;
            for &u in starts.iter().rev() {
                score += rev.step(&mut pv, &mut mv, rev.eq_at(hay, u).0);
                if score <= d as isize {
                    best = Some(u);
                }
            }
        } else {
            let top = 1u128 << (m - 1);
            let mask = if m == 128 { u128::MAX } else { (1u128 << m) - 1 };
            let (mut pv, mut mv, mut score) = (mask, 0u128, m as isize);
            for &u in starts.iter().rev() {
                score += myers_step(self.rev.at(hay, u).0, &mut pv, &mut mv, top, mask);
                if score <= d as isize {
                    best = Some(u);
                }
            }
        }
        best.unwrap_or_else(|| starts.len().checked_sub(m).map_or(lo, |j| starts[j]))
    }
}

impl Matcher for FuzzyMatcher {
    type Captures = NoCaptures;
    type Error = NoError;

    fn find_at(&self, haystack: &[u8], at: usize) -> Result<Option<MatchSpan>, NoError> {
        match self.first_end_filtered(haystack, at) {
            Some((end, d)) => {
                let start = self.start_for(haystack, end, d);
                Ok(Some(MatchSpan::new(start.max(at), end)))
            }
            None => Ok(None),
        }
    }

    fn new_captures(&self) -> Result<NoCaptures, NoError> {
        Ok(NoCaptures::new())
    }

    fn line_terminator(&self) -> Option<LineTerminator> {
        Some(LineTerminator::default()) // matches never span a line (see first_end)
    }
}



#[derive(Clone, Debug)]
pub struct Literal(memchr::memmem::Finder<'static>);

impl Literal {
    fn of(o: &Pattern, insensitive: bool) -> Option<Literal> {
        let p = o.text.as_bytes();
        let plain = o.mode == Mode::Literal && !insensitive && !o.word && !o.multiline;
        // the length bound keeps it to patterns the regex engine's size limit lets through
        (plain && !p.is_empty() && p.len() <= 1024 && !p.contains(&b'\n')).then(|| Literal(memchr::memmem::Finder::new(p).into_owned()))
    }
}

impl Matcher for Literal {
    type Captures = NoCaptures;
    type Error = NoError;

    fn find_at(&self, haystack: &[u8], at: usize) -> Result<Option<MatchSpan>, NoError> {
        let n = self.0.needle().len();
        Ok(haystack.get(at..).and_then(|h| self.0.find(h)).map(|i| MatchSpan::new(at + i, at + i + n)))
    }

    fn new_captures(&self) -> Result<NoCaptures, NoError> {
        Ok(NoCaptures::new())
    }

    fn line_terminator(&self) -> Option<LineTerminator> {
        Some(LineTerminator::default())
    }

    fn find_candidate_line(&self, haystack: &[u8]) -> Result<Option<grep_matcher::LineMatchKind>, NoError> {
        Ok(self.0.find(haystack).map(grep_matcher::LineMatchKind::Confirmed))
    }
}

// ------------------------------------------------------------------------- matcher selection
#[derive(Clone)]
pub enum AnyMatcher {
    Literal(Literal),
    Regex(LineRegex),
    Fuzzy(Box<FuzzyMatcher>),
    Pcre2(grep_pcre2::RegexMatcher),
    FuzzyRegex(Box<crate::fuzzyre::FuzzyRegex>),
}

impl AnyMatcher {

    fn spans_lines(&self) -> bool {
        fn can<M: Matcher>(m: &M) -> bool {
            m.line_terminator().is_none() && !m.non_matching_bytes().is_some_and(|b| b.contains(b'\n'))
        }
        match self {
            AnyMatcher::Literal(m) => can(m),
            AnyMatcher::Regex(m) => can(m),
            AnyMatcher::Fuzzy(m) => can(m.as_ref()),
            AnyMatcher::Pcre2(m) => can(m),
            AnyMatcher::FuzzyRegex(m) => can(m.as_ref()),
        }
    }

    fn search_slice<S: Sink>(&self, searcher: &mut Searcher, slice: &[u8], sink: S) -> Result<(), S::Error> {
        match self {
            AnyMatcher::Literal(m) => searcher.search_slice(m, slice, sink),
            AnyMatcher::Regex(m) => searcher.search_slice(m, slice, sink),
            AnyMatcher::Fuzzy(m) => searcher.search_slice(m.as_ref(), slice, sink),
            AnyMatcher::Pcre2(m) => searcher.search_slice(m, slice, sink),
            AnyMatcher::FuzzyRegex(m) => searcher.search_slice(m.as_ref(), slice, sink),
        }
    }

    fn search_file<S: Sink>(&self, searcher: &mut Searcher, file: &std::fs::File, sink: S) -> Result<(), S::Error> {
        match self {
            AnyMatcher::Literal(m) => searcher.search_file(m, file, sink),
            AnyMatcher::Regex(m) => searcher.search_file(m, file, sink),
            AnyMatcher::Fuzzy(m) => searcher.search_file(m.as_ref(), file, sink),
            AnyMatcher::Pcre2(m) => searcher.search_file(m, file, sink),
            AnyMatcher::FuzzyRegex(m) => searcher.search_file(m.as_ref(), file, sink),
        }
    }

    fn search_reader<R: std::io::Read, S: Sink>(&self, searcher: &mut Searcher, reader: R, sink: S) -> Result<(), S::Error> {
        match self {
            AnyMatcher::Literal(m) => searcher.search_reader(m, reader, sink),
            AnyMatcher::Regex(m) => searcher.search_reader(m, reader, sink),
            AnyMatcher::Fuzzy(m) => searcher.search_reader(m.as_ref(), reader, sink),
            AnyMatcher::Pcre2(m) => searcher.search_reader(m, reader, sink),
            AnyMatcher::FuzzyRegex(m) => searcher.search_reader(m.as_ref(), reader, sink),
        }
    }
}






#[derive(Clone, Debug)]
pub struct LineRegex {
    inner: grep_regex::RegexMatcher,
    suffixes: Option<regex::bytes::Regex>,
    line_start: Option<LineStart>,
    fold: Option<foldfind::FoldFinder>,
}




#[derive(Clone, Debug)]
struct LineStart {
    anchored: regex_automata::meta::Regex,
    prefixes: Vec<Vec<u8>>,

    starts: regex::bytes::Regex,
}

impl LineRegex {
    fn new(inner: grep_regex::RegexMatcher, pattern: &str, insensitive: bool) -> LineRegex {
        let lines = inner.line_terminator().is_some();
        let suffixes = if lines { suffix_searcher(pattern, insensitive) } else { None };
        let line_start = if lines && suffixes.is_none() { line_start(pattern, insensitive) } else { None };
        LineRegex { inner, suffixes, line_start, fold: None }
    }

    fn plain(inner: grep_regex::RegexMatcher) -> LineRegex {
        LineRegex { inner, suffixes: None, line_start: None, fold: None }
    }



    fn at_line_start(&self, haystack: &[u8], at: usize, earliest: bool) -> Result<Option<MatchSpan>, ()> {
        let ls = self.line_start.as_ref().ok_or(())?;
        if at > haystack.len() || memchr::memchr(b'\n', &haystack[at..]).is_some() {
            return Err(());
        }
        if at > 0 && haystack[at - 1] != b'\n' {
            return Ok(None);
        }
        let input = regex_automata::Input::new(haystack).range(at..).anchored(regex_automata::Anchored::Yes).earliest(earliest);
        Ok(ls.anchored.search(&input).map(|m| MatchSpan::new(m.start(), m.end())))
    }
}



fn line_start(pattern: &str, insensitive: bool) -> Option<LineStart> {
    use regex_syntax::hir::{
        literal::{ExtractKind, Extractor},
        Look,
    };
    let hir = regex_syntax::ParserBuilder::new().case_insensitive(insensitive).multi_line(true).utf8(false).build().parse(pattern).ok()?;
    // `\A` and `\z` mean the line's ends when the searcher checks a line, the buffer's ends here
    let looks = hir.properties().look_set();
    if !hir.properties().look_set_prefix().contains(Look::StartLF) || looks.contains(Look::Start) || looks.contains(Look::End) {
        return None;
    }
    let lits = Extractor::new().kind(ExtractKind::Prefix).extract(&hir);
    let lits = lits.literals()?;
    if lits.is_empty() || lits.len() > 64 || lits.iter().any(|l| l.is_empty() || l.as_bytes().contains(&b'\n')) {
        return None;
    }
    let prefixes: Vec<Vec<u8>> = lits.iter().map(|l| l.as_bytes().to_vec()).collect();
    let alts: Vec<String> = prefixes.iter().map(|l| l.iter().map(|b| format!("\\x{b:02X}")).collect()).collect();
    let starts = regex::bytes::Regex::new(&format!("(?-u:\\n(?:{}))", alts.join("|"))).ok()?;
    let anchored = regex_automata::meta::Regex::builder().configure(regex_automata::meta::Config::new().utf8_empty(false)).build_from_hir(&hir).ok()?;
    Some(LineStart { anchored, prefixes, starts })
}



fn suffix_searcher(pattern: &str, insensitive: bool) -> Option<regex::bytes::Regex> {
    use regex_syntax::hir::literal::{ExtractKind, Extractor};
    let hir = regex_syntax::ParserBuilder::new().case_insensitive(insensitive).utf8(false).build().parse(pattern).ok()?;
    let prefixes = Extractor::new().kind(ExtractKind::Prefix).extract(&hir);
    if prefixes.literals().is_some_and(|l| !l.is_empty() && l.iter().all(|x| x.len() >= 2)) {
        return None; // the engine's own prefilter already searches for these
    }
    let suffixes = Extractor::new().kind(ExtractKind::Suffix).extract(&hir);
    let lits = suffixes.literals()?;
    if lits.is_empty() || lits.len() > 64 || lits.iter().any(|l| l.len() < 3 || l.as_bytes().contains(&b'\n')) {
        return None;
    }
    let alts: Vec<String> = lits.iter().map(|l| l.as_bytes().iter().map(|b| format!("\\x{b:02X}")).collect()).collect();
    regex::bytes::Regex::new(&format!("(?-u:{})", alts.join("|"))).ok()
}

impl Matcher for LineRegex {
    type Captures = grep_regex::RegexCaptures;
    type Error = NoError;

    fn find_at(&self, haystack: &[u8], at: usize) -> Result<Option<MatchSpan>, NoError> {
        match self.at_line_start(haystack, at, false) {
            Ok(m) => Ok(m),
            Err(()) => self.inner.find_at(haystack, at),
        }
    }
    fn new_captures(&self) -> Result<Self::Captures, NoError> {
        self.inner.new_captures()
    }
    fn capture_count(&self) -> usize {
        self.inner.capture_count()
    }
    fn capture_index(&self, name: &str) -> Option<usize> {
        self.inner.capture_index(name)
    }
    fn try_find_iter<F, E>(&self, haystack: &[u8], matched: F) -> Result<Result<(), E>, NoError>
    where
        F: FnMut(MatchSpan) -> Result<bool, E>,
    {
        self.inner.try_find_iter(haystack, matched)
    }
    fn captures_at(&self, haystack: &[u8], at: usize, caps: &mut Self::Captures) -> Result<bool, NoError> {
        self.inner.captures_at(haystack, at, caps)
    }
    fn shortest_match_at(&self, haystack: &[u8], at: usize) -> Result<Option<usize>, NoError> {
        match self.at_line_start(haystack, at, true) {
            Ok(m) => Ok(m.map(|m| m.end())),
            Err(()) => self.inner.shortest_match_at(haystack, at),
        }
    }
    fn non_matching_bytes(&self) -> Option<&grep_matcher::ByteSet> {
        self.inner.non_matching_bytes()
    }
    fn line_terminator(&self) -> Option<LineTerminator> {
        self.inner.line_terminator()
    }
    fn find_candidate_line(&self, haystack: &[u8]) -> Result<Option<grep_matcher::LineMatchKind>, NoError> {
        if let Some(f) = &self.fold {
            return Ok(f.find(haystack).map(grep_matcher::LineMatchKind::Candidate));
        }
        if let Some(ls) = &self.line_start {
            // the searcher calls this at the start of a line, with whole lines
            let mut next = ls.prefixes.iter().any(|p| haystack.starts_with(p)).then_some(0);
            let mut from = 0;
            loop {
                let at = match next.take() {
                    Some(at) => at,
                    None => match ls.starts.find_at(haystack, from) {
                        Some(m) => m.start() + 1,
                        None => return Ok(None),
                    },
                };
                let input = regex_automata::Input::new(haystack).range(at..).anchored(regex_automata::Anchored::Yes).earliest(true);
                match ls.anchored.search_half(&input) {
                    // no match here, so none for grep-regex's line regex either (it matches less)
                    None => from = at,
                    // a match within the line is one for grep-regex too
                    Some(m) if memchr::memchr(b'\n', &haystack[at..m.offset()]).is_none() => return Ok(Some(grep_matcher::LineMatchKind::Confirmed(at))),
                    Some(_) => return Ok(Some(grep_matcher::LineMatchKind::Candidate(at))),
                }
            }
        }
        match &self.suffixes {
            Some(re) => Ok(re.find(haystack).map(|m| grep_matcher::LineMatchKind::Candidate(m.start()))),
            None => self.inner.find_candidate_line(haystack),
        }
    }
}




pub fn ident_parts(ident: &str) -> Vec<String> {
    let chars: Vec<char> = ident.chars().collect();
    let mut parts: Vec<String> = Vec::new();
    let mut cur = String::new();
    for (i, &c) in chars.iter().enumerate() {
        if !c.is_alphanumeric() {
            if !cur.is_empty() {
                parts.push(std::mem::take(&mut cur));
            }
            continue;
        }
        if let Some(prev) = cur.chars().last() {
            let boundary = (prev.is_lowercase() && c.is_uppercase())
                || (prev.is_ascii_digit() != c.is_ascii_digit())
                || (prev.is_uppercase() && c.is_uppercase() && chars.get(i + 1).map(|n| n.is_lowercase()).unwrap_or(false));
            if boundary {
                parts.push(std::mem::take(&mut cur));
            }
        }
        cur.push(c);
    }
    if !cur.is_empty() {
        parts.push(cur);
    }
    parts
}




pub fn identifier_regex(ident: &str) -> String {
    let parts = ident_parts(ident);
    if parts.is_empty() {
        return regex::escape(ident);
    }
    let body = parts.iter().map(|p| regex::escape(p)).collect::<Vec<_>>().join("[_\\-]?");
    format!("(?i)\\b{body}\\b")
}



pub fn join_patterns(patterns: &[String], mode: Mode, fixed: bool) -> Result<(String, Mode)> {
    if let [one] = patterns {
        let one = if mode == Mode::Pcre2 && fixed { regex::escape(one) } else { one.clone() };
        return Ok((one, mode));
    }
    if matches!(mode, Mode::Fuzzy { .. }) {
        bail!("--fuzzy takes one pattern");
    }
    let part = |p: &str| match mode {
        Mode::Literal => regex::escape(p),
        Mode::Pcre2 if fixed => regex::escape(p),
        Mode::Identifier => identifier_regex(p),
        _ => p.to_string(),
    };
    let joined = patterns.iter().map(|p| format!("(?:{})", part(p))).collect::<Vec<_>>().join("|");
    Ok((joined, if matches!(mode, Mode::Pcre2 | Mode::FuzzyRegex { .. }) { mode } else { Mode::Regex }))
}



pub struct Translated<'a> {

    pub insensitive: bool,

    pub pattern: std::borrow::Cow<'a, str>,
}

impl Pattern {
    pub fn translate(&self) -> Translated<'_> {
        let insensitive = match self.case {
            Case::Sensitive => false,
            Case::Insensitive => true,
            Case::Smart => smart_folds(&self.text, matches!(self.mode, Mode::Regex | Mode::Pcre2 | Mode::FuzzyRegex { .. })),
        };
        match self.mode {
            Mode::Literal => Translated { insensitive, pattern: regex::escape(&self.text).into() },
            // the identifier regex carries its own (?i)
            Mode::Identifier => Translated { insensitive: false, pattern: identifier_regex(&self.text).into() },
            _ => Translated { insensitive, pattern: self.text.as_str().into() },
        }
    }
}

impl Files {

    pub fn check_indexable(&self) -> Result<()> {
        if self.search_zip {
            bail!("--index does not cover archive members; search with -z and without --index");
        }
        if self.hidden || self.no_ignore || self.follow_links || self.max_depth.is_some() || self.max_filesize.is_some() {
            bail!("--index searches the files of the default walk; drop --hidden/--no-ignore/-L/--max-depth/--max-filesize or search without --index");
        }
        Ok(())
    }
}



fn smart_folds(pattern: &str, regex: bool) -> bool {
    use regex_syntax::ast::{Ast, ClassSet, ClassSetItem};
    fn lit(c: char, seen: &mut (bool, bool)) {
        seen.0 = true;
        seen.1 |= c.is_uppercase();
    }
    fn item(i: &ClassSetItem, seen: &mut (bool, bool)) {
        match i {
            ClassSetItem::Literal(l) => lit(l.c, seen),
            ClassSetItem::Range(r) => {
                lit(r.start.c, seen);
                lit(r.end.c, seen);
            }
            ClassSetItem::Bracketed(b) => set(&b.kind, seen),
            ClassSetItem::Union(u) => u.items.iter().for_each(|x| item(x, seen)),
            _ => {}
        }
    }
    fn set(s: &ClassSet, seen: &mut (bool, bool)) {
        match s {
            ClassSet::Item(i) => item(i, seen),
            ClassSet::BinaryOp(op) => {
                set(&op.lhs, seen);
                set(&op.rhs, seen);
            }
        }
    }
    fn walk(a: &Ast, seen: &mut (bool, bool)) {
        match a {
            Ast::Literal(l) => lit(l.c, seen),
            Ast::ClassBracketed(c) => set(&c.kind, seen),
            Ast::Repetition(r) => walk(&r.ast, seen),
            Ast::Group(g) => walk(&g.ast, seen),
            Ast::Alternation(x) => x.asts.iter().for_each(|x| walk(x, seen)),
            Ast::Concat(x) => x.asts.iter().for_each(|x| walk(x, seen)),
            _ => {}
        }
    }
    if !regex {
        return !uppercase_literal(pattern, false);
    }
    match regex_syntax::ast::parse::Parser::new().parse(pattern) {
        Ok(ast) => {
            let mut seen = (false, false);
            walk(&ast, &mut seen);
            seen.0 && !seen.1
        }
        // PCRE2-only syntax
        Err(_) => !uppercase_literal(pattern, true),
    }
}



fn uppercase_literal(pattern: &str, regex: bool) -> bool {
    let mut chars = pattern.chars().peekable();
    while let Some(c) = chars.next() {
        if regex && c == '\\' {
            match chars.next() {
                Some('p' | 'P') if chars.peek() == Some(&'{') => {
                    chars.by_ref().find(|&d| d == '}');
                }
                Some('p' | 'P') => {
                    chars.next();
                }
                // a letter by its code point stands for itself: `\x41`, `\x{41}`, `\u0041`, `\U00000041`
                Some(kind @ ('x' | 'u' | 'U')) => {
                    let digits: String = if chars.peek() == Some(&'{') {
                        chars.by_ref().skip(1).take_while(|&d| d != '}').collect()
                    } else {
                        chars
                            .by_ref()
                            .take(if kind == 'x' {
                                2
                            } else if kind == 'u' {
                                4
                            } else {
                                8
                            })
                            .collect()
                    };
                    if u32::from_str_radix(&digits, 16).ok().and_then(char::from_u32).is_some_and(char::is_uppercase) {
                        return true;
                    }
                }
                _ => {}
            }
        } else if c.is_uppercase() {
            return true;
        }
    }
    false
}

pub fn build_matcher(p: &Pattern) -> Result<AnyMatcher> {
    if matches!(p.mode, Mode::Fuzzy { .. } | Mode::FuzzyRegex { .. }) {
        // neither matcher looks beyond a line or at word boundaries: saying so beats finding nothing
        if p.word {
            bail!("whole-word matching (-w) is not available with --fuzzy or --fuzzy-regex");
        }
        if p.multiline {
            bail!("multiline matching (-U) is not available with --fuzzy or --fuzzy-regex");
        }
    }
    let Translated { insensitive, pattern: pat } = p.translate();
    if let Some(m) = Literal::of(p, insensitive) {
        return Ok(AnyMatcher::Literal(m));
    }
    match p.mode {
        Mode::Fuzzy { max_edits } => Ok(AnyMatcher::Fuzzy(Box::new(FuzzyMatcher::new(&pat, max_edits, insensitive)?))),
        Mode::FuzzyRegex { max_edits } => Ok(AnyMatcher::FuzzyRegex(Box::new(crate::fuzzyre::FuzzyRegex::new(&pat, max_edits, insensitive)?))),
        Mode::Pcre2 => {
            let m = grep_pcre2::RegexMatcherBuilder::new()
                .caseless(insensitive)
                .word(p.word)
                .multi_line(true)
                .dotall(false)
                .utf(true)
                .ucp(true)
                .jit_if_available(true)
                .build(&pat)
                .with_context(|| format!("invalid PCRE2 pattern {:?}", p.text))?;
            Ok(AnyMatcher::Pcre2(m))
        }
        _ => {
            let mut b = RegexMatcherBuilder::new();
            // ^ and $ are line anchors in every mode, as in ripgrep; without it the searcher has to
            // run the regex one line at a time
            b.case_insensitive(insensitive)
                .word(p.word)
                .multi_line(true)
                .dot_matches_new_line(false)
                .size_limit(p.regex_size_limit)
                .dfa_size_limit(p.dfa_size_limit)
                .line_terminator(if p.multiline { None } else { Some(b'\n') });
            let m = b.build(&pat).with_context(|| format!("invalid pattern {:?}", p.text))?;
            let suffix_ok = !p.word && p.mode != Mode::Literal;
            let mut m = if suffix_ok { LineRegex::new(m, &pat, insensitive) } else { LineRegex::plain(m) };
            if insensitive && m.line_terminator().is_some() {
                m.fold = foldfind::FoldFinder::new(&pat);
            }
            Ok(AnyMatcher::Regex(m))
        }
    }
}

// ------------------------------------------------------------------------- file types

pub fn type_globs(name: &str) -> Option<Vec<String>> {
    let id = match name {
        "py" => "python",
        "js" => "javascript",
        "ts" => "typescript",
        "rb" => "ruby",
        "rs" => "rust",
        "cs" => "csharp",
        "kt" => "kotlin",
        "hs" => "haskell",
        "ex" => "elixir",
        "sh" | "shell" => "bash",
        "md" => "markdown",
        "yml" => "yaml",
        "tf" | "terraform" => "hcl",
        other => other,
    };
    let spec = crate::langs::by_id(id)?;
    let mut globs: Vec<String> = spec.exts.iter().map(|e| format!("*{e}")).collect();
    globs.extend(spec.files.iter().map(|f| f.to_string()));
    Some(globs)
}

pub fn type_list() -> Vec<(String, Vec<String>)> {
    crate::langs::LANGS.iter().map(|s| (s.id.to_string(), type_globs(s.id).unwrap_or_default())).collect()
}

// ------------------------------------------------------------------------- the search








pub struct PlainSink {
    out: Mutex<std::io::BufWriter<Box<dyn Write + Send>>>,

    left: AtomicU64,

    holding: AtomicBool,
    start: Instant,

    pub broken: AtomicBool,

    grouped: AtomicBool,
}


const HOLD_NS: u64 = 1_000_000;

impl PlainSink {
    pub fn new(out: Box<dyn Write + Send>) -> PlainSink {
        PlainSink {
            out: Mutex::new(std::io::BufWriter::with_capacity(1 << 16, out)),
            left: AtomicU64::new(0),
            holding: AtomicBool::new(false),
            start: Instant::now(),
            broken: AtomicBool::new(false),
            grouped: AtomicBool::new(false),
        }
    }

    fn waited(&self) -> Option<u64> {
        let now = self.start.elapsed().as_nanos() as u64;
        (now.saturating_sub(self.left.load(Ordering::Relaxed)) >= HOLD_NS).then_some(now)
    }



    fn with(&self, stop: &Stop, f: impl FnOnce(&mut dyn Write) -> std::io::Result<()>) {
        if self.broken.load(Ordering::Relaxed) {
            return;
        }
        let res = match self.out.lock() {
            Ok(mut w) => f(&mut *w).and_then(|_| {
                if let Some(now) = self.waited().filter(|_| !w.buffer().is_empty()) {
                    self.left.store(now, Ordering::Relaxed);
                    w.flush()?;
                }
                self.holding.store(!w.buffer().is_empty(), Ordering::Relaxed);
                Ok(())
            }),
            Err(_) => Err(std::io::Error::other("output lock poisoned")),
        };
        if res.is_err() {
            self.broken.store(true, Ordering::Relaxed);
            stop.set();
        }
    }



    fn write(&self, buf: &[u8], first: bool, stop: &Stop) {
        if !buf.is_empty() {
            self.with(stop, |w| self.separate(w, first).and_then(|_| w.write_all(buf)));
        }
    }



    fn write_line(&self, before: &[u8], head: &[u8], text: Text, first: bool, stop: &Stop) -> std::io::Result<()> {
        let mut read = Ok(());
        self.with(stop, |w| {
            self.separate(w, first)?;
            w.write_all(before)?;
            w.write_all(head)?;
            match text {
                Text::Here(b) => write_lossy(w, b, 1 << 18)?,
                Text::At(at, len) => read = write_lossy_from(w, at, len)?,
            }
            w.write_all(b"\n")
        });
        read
    }

    fn separate(&self, w: &mut dyn Write, first: bool) -> std::io::Result<()> {
        if first && self.grouped.swap(true, Ordering::Relaxed) {
            w.write_all(b"--\n")?;
        }
        Ok(())
    }



    fn tick(&self, stop: &Stop) {
        if self.holding.load(Ordering::Relaxed) && self.waited().is_some() {
            self.with(stop, |_| Ok(()));
        }
    }

    pub fn flush(&self) -> std::io::Result<()> {
        match self.out.lock() {
            Ok(mut w) => w.flush(),
            Err(_) => Err(std::io::Error::other("output lock poisoned")),
        }
    }
}



fn lossy(b: &[u8]) -> std::borrow::Cow<'_, str> {
    match std::str::from_utf8(b) {
        Ok(s) => std::borrow::Cow::Borrowed(s),
        Err(_) => String::from_utf8_lossy(b),
    }
}



fn write_lossy(w: &mut dyn Write, b: &[u8], piece: usize) -> std::io::Result<()> {
    let mut at = 0;
    while at < b.len() {
        let end = b.len().min(at + piece.max(4));
        at = end - write_lossy_part(w, &b[at..end], end < b.len())?;
    }
    Ok(())
}



fn write_lossy_part(w: &mut dyn Write, b: &[u8], more: bool) -> std::io::Result<usize> {
    let mut at = 0;
    while at < b.len() {
        match std::str::from_utf8(&b[at..]) {
            Ok(_) => {
                w.write_all(&b[at..])?;
                at = b.len();
            }
            Err(e) => {
                let ok = at + e.valid_up_to();
                w.write_all(&b[at..ok])?;
                match e.error_len() {
                    Some(bad) => {
                        w.write_all("\u{FFFD}".as_bytes())?;
                        at = ok + bad;
                    }
                    None if more => return Ok(b.len() - ok),
                    None => {
                        w.write_all("\u{FFFD}".as_bytes())?;
                        at = b.len();
                    }
                }
            }
        }
    }
    Ok(0)
}



#[derive(Clone, Copy)]
enum Text<'t> {
    Here(&'t [u8]),
    At(&'t dyn source::ReadAt, u64),
}



fn write_lossy_from(w: &mut dyn Write, at: &dyn source::ReadAt, len: u64) -> std::io::Result<std::io::Result<()>> {
    const PIECE: usize = 1 << 18;
    let mut buf = vec![0u8; PIECE + 3];
    let (mut pos, mut kept) = (0u64, 0usize);
    while pos < len {
        let want = (PIECE as u64).min(len - pos) as usize;
        let got = match at.read_at(&mut buf[kept..kept + want], pos) {
            Ok(0) => return Ok(Err(std::io::Error::other("changed while it was searched, or a read failed"))),
            Ok(n) => n,
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Ok(Err(e)),
        };
        pos += got as u64;
        let end = kept + got;
        let left = write_lossy_part(w, &buf[..end], pos < len)?;
        buf.copy_within(end - left..end, 0);
        kept = left;
    }
    Ok(Ok(()))
}




pub fn format_plain(out: &mut Vec<u8>, path: &[u8], line: u64, text: &[u8], context: bool) {
    let sep = if context { b'-' } else { b':' };
    for (k, part) in text.split(|&b| b == b'\n').enumerate() {
        if !path.is_empty() {
            out.extend_from_slice(path);
            out.push(sep);
        }
        if line != 0 {
            let mut n = line + k as u64;
            let mut digits = [0u8; 20];
            let mut i = digits.len();
            loop {
                i -= 1;
                digits[i] = b'0' + (n % 10) as u8;
                n /= 10;
                if n == 0 {
                    break;
                }
            }
            out.extend_from_slice(&digits[i..]);
            out.push(sep);
        }
        out.extend_from_slice(part);
        out.push(b'\n');
    }
}

struct Collector<'a> {
    path: Arc<str>,

    raw: Option<Arc<[u8]>>,

    tx: Option<&'a mpsc::SyncSender<Vec<Record>>>,
    counters: &'a Counters,

    batch: Vec<Record>,
    plain: Option<&'a PlainSink>,
    out: Vec<u8>,
    want_spans: bool,
    text_spans: bool,
    stats_matches: &'a AtomicU64,
    max_results: Option<u64>,
    matched: bool,
    stop: &'a Stop,
    matcher: &'a AnyMatcher,
    invert: bool,
    report: Report,
    file_count: u64,

    line_base: u64,

    hold: bool,

    binary: bool,

    convert: bool,

    binary_at: Option<u64>,

    multiline: bool,

    first: bool,


    whole_groups: bool,

    named: bool,

    numbered: bool,

    count_each: bool,
}




fn text_offsets(spans: &mut [(usize, usize)], line: &[u8], text: &str, valid: bool) {
    // each piece of the line: where it starts in `line` and in `text`, its valid and invalid bytes
    let whole = [(0, 0, line.len(), 0)];
    let split: Vec<(usize, usize, usize, usize)>;
    let pieces = if valid {
        &whole[..]
    } else {
        let (mut r, mut t) = (0, 0);
        split = line
            .utf8_chunks()
            .map(|c| {
                let p = (r, t, c.valid().len(), c.invalid().len());
                r += p.2 + p.3;
                t += p.2 + if p.3 > 0 { '\u{FFFD}'.len_utf8() } else { 0 };
                p
            })
            .collect();
        &split
    };
    let at = |x: usize, up: bool| {
        let Some(&(r, t, v, n)) = pieces.get(pieces.partition_point(|p| p.0 <= x).saturating_sub(1)) else { return 0 };
        let d = x - r;
        let mut y = if d <= v {
            t + d
        } else if d < v + n {
            t + v + if up { '\u{FFFD}'.len_utf8() } else { 0 }
        } else {
            text.len()
        };
        y = y.min(text.len());
        while !text.is_char_boundary(y) {
            y = if up { y + 1 } else { y - 1 };
        }
        y
    };
    for s in spans {
        *s = (at(s.0, false), at(s.1, true));
    }
}

fn spans_in(matcher: &AnyMatcher, line: &[u8]) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    each_match(matcher, line, |a, b| {
        out.push((a, b));
        true
    });
    out
}


fn each_match(matcher: &AnyMatcher, line: &[u8], mut f: impl FnMut(usize, usize) -> bool) {
    let mut at = 0;
    let find = |at: usize| -> Option<MatchSpan> {
        match matcher {
            AnyMatcher::Literal(m) => m.find_at(line, at).ok().flatten(),
            AnyMatcher::Regex(m) => m.find_at(line, at).ok().flatten(),
            AnyMatcher::Fuzzy(m) => m.find_at(line, at).ok().flatten(),
            AnyMatcher::Pcre2(m) => m.find_at(line, at).ok().flatten(),
            AnyMatcher::FuzzyRegex(m) => m.find_at(line, at).ok().flatten(),
        }
    };
    while at <= line.len() {
        match find(at) {
            Some(m) => {
                at = if m.end() > m.start() { m.end() } else { m.end() + 1 };
                if !f(m.start(), m.end()) {
                    break;
                }
            }
            None => break,
        }
    }
}

impl<'a> Sink for Collector<'a> {
    type Error = std::io::Error;

    fn matched(&mut self, _s: &Searcher, mat: &SinkMatch<'_>) -> Result<bool, std::io::Error> {
        let bytes = mat.bytes();
        let line = bytes.strip_suffix(b"\n").map(|b| b.strip_suffix(b"\r").unwrap_or(b)).unwrap_or(bytes);
        self.take_match(bytes, Text::Here(line), mat.line_number())
    }

    fn context(&mut self, _s: &Searcher, ctx: &SinkContext<'_>) -> Result<bool, std::io::Error> {
        let bytes = ctx.bytes();
        let line = bytes.strip_suffix(b"\n").map(|b| b.strip_suffix(b"\r").unwrap_or(b)).unwrap_or(bytes);
        if self.plain.is_some() {
            let name = if self.named { self.raw.as_deref().unwrap_or(self.path.as_bytes()) } else { b"" };
            let number = if self.numbered { ctx.line_number().unwrap_or(0) + self.line_base } else { 0 };
            format_plain(&mut self.out, name, number, lossy(line).as_bytes(), true);
            return Ok(true);
        }
        let text = lossy(line).into_owned();
        self.push(Record::Context(Line {
            path: Arc::clone(&self.path),
            path_bytes: self.raw.clone(),
            line: ctx.line_number().unwrap_or(0) + self.line_base,
            column: 0,
            text,
            spans: Vec::new(),
        }));
        Ok(true)
    }

    fn context_break(&mut self, _s: &Searcher) -> Result<bool, std::io::Error> {
        if let Some(p) = self.plain.filter(|_| self.whole_groups && !self.hold && self.out.len() >= 1 << 16) {
            // the next group is a first output: the sink writes the `--` before it
            p.write(&self.out, std::mem::take(&mut self.first), self.stop);
            self.out.clear();
            self.first = true;
        } else if self.plain.is_some() {
            self.out.extend_from_slice(b"--\n");
        }
        Ok(true)
    }

    fn binary_data(&mut self, _s: &Searcher, offset: u64) -> Result<bool, std::io::Error> {
        self.binary_at = Some(offset);
        Ok(true)
    }

    fn finish(&mut self, _s: &Searcher, f: &grep_searcher::SinkFinish) -> Result<(), std::io::Error> {
        self.binary = f.binary_byte_offset().is_some();
        if let (true, Report::Lines, Some(at)) = (self.matched, self.report, self.binary_at) {
            // as ripgrep: a named file's line output ends here; a walked file stopped being searched
            let note = if self.convert {
                format!("binary file matches (found \"\\0\" byte around offset {at})")
            } else {
                format!("WARNING: stopped searching binary file after match (found \"\\0\" byte around offset {at})")
            };
            if self.plain.is_some() {
                if self.named {
                    self.out.extend_from_slice(self.raw.as_deref().unwrap_or(self.path.as_bytes()));
                    self.out.extend_from_slice(b": ");
                }
                self.out.extend_from_slice(note.as_bytes());
                self.out.push(b'\n');
            } else {
                self.push(Record::Note { path: Arc::clone(&self.path), path_bytes: self.raw.clone(), text: note });
            }
        }
        self.flush();
        Ok(())
    }
}

impl Collector<'_> {


    fn take_match(&mut self, bytes: &[u8], text: Text, number: Option<u64>) -> Result<bool, std::io::Error> {
        if self.stop.is_set() {
            return Ok(false);
        }
        if self.report != Report::Lines {
            if self.report == Report::Files && self.matched {
                return Ok(true);
            }
            let n = self.stats_matches.fetch_add(1, Ordering::Relaxed) + 1;
            if self.over_limit(n) {
                return Ok(false);
            }
            self.matched = true;
            // as ripgrep: merged matches that span lines count one by one
            self.file_count += if self.count_each {
                let mut n = 0;
                each_match(self.matcher, bytes, |_, _| {
                    n += 1;
                    true
                });
                n.max(1)
            } else {
                1
            };
            if self.max_results.is_some_and(|max| n >= max) {
                self.stop.set();
                return Ok(false);
            }
            // one match is enough to list the file; with -v ripgrep reads on and drops a file
            // with a NUL byte
            return Ok(self.report != Report::Files || (self.invert && !self.convert));
        }
        if self.convert && self.binary_at.is_some() {
            // as ripgrep: a match past a NUL byte ends the output, `finish` writes the note
            let n = self.stats_matches.fetch_add(1, Ordering::Relaxed) + 1;
            self.matched |= !self.over_limit(n);
            return Ok(false);
        }
        if let Some(p) = self.plain {
            let n = self.stats_matches.fetch_add(1, Ordering::Relaxed) + 1;
            if self.over_limit(n) {
                return Ok(false);
            }
            self.matched = true;
            let number = if self.numbered { number.unwrap_or(0) + self.line_base } else { 0 };
            let name = if self.named { self.raw.as_deref().unwrap_or(self.path.as_bytes()) } else { b"" };
            match text {
                Text::Here(line) if line.len() < 1 << 16 || self.hold || self.whole_groups || (self.multiline && memchr::memchr(b'\n', line).is_some()) => {
                    format_plain(&mut self.out, name, number, lossy(line).as_bytes(), false);
                }
                _ => {
                    // a very long line is written from where it is instead of being copied into the buffer
                    let mut head = Vec::with_capacity(name.len() + 24);
                    format_plain(&mut head, name, number, b"", false);
                    head.pop(); // the newline: the text goes between
                    let read = p.write_line(&self.out, &head, text, std::mem::take(&mut self.first), self.stop);
                    self.out.clear();
                    read?;
                }
            }
            if self.out.len() >= 1 << 16 && !self.hold && !self.whole_groups {
                p.write(&self.out, std::mem::take(&mut self.first), self.stop);
                self.out.clear();
            }
            if let Some(max) = self.max_results {
                if n >= max {
                    self.stop.set();
                    return Ok(false);
                }
            }
            return Ok(true);
        }
        let Text::Here(line) = text else { return Err(std::io::Error::other("a line not in memory has no hit")) };
        let n = self.stats_matches.fetch_add(1, Ordering::Relaxed) + 1;
        if self.over_limit(n) {
            return Ok(false);
        }
        let text = lossy(line);
        let mut spans = if self.invert || !self.want_spans { Vec::new() } else { spans_in(self.matcher, bytes) };
        if self.text_spans {
            text_offsets(&mut spans, line, &text, matches!(text, std::borrow::Cow::Borrowed(_)));
        }
        let text = text.into_owned();
        let column = spans.first().map(|s| s.0 as u64 + 1).unwrap_or(0);
        self.matched = true;
        let path_bytes = self.raw.clone();
        self.push(Record::Match(Line { path: Arc::clone(&self.path), path_bytes, line: number.unwrap_or(0) + self.line_base, column, text, spans }));
        if let Some(max) = self.max_results {
            if n >= max {
                self.stop.set();
                return Ok(false);
            }
        }
        Ok(true)
    }



    fn over_limit(&self, n: u64) -> bool {
        let over = self.max_results.is_some_and(|max| n > max);
        if over {
            self.stats_matches.fetch_sub(1, Ordering::Relaxed);
            self.stop.set();
        }
        over
    }

    fn push(&mut self, h: Record) {
        self.batch.push(h);
        if self.batch.len() >= 512 {
            self.flush();
        }
    }
    fn flush(&mut self) {
        if let (Some(p), false, false) = (self.plain, self.hold, self.out.is_empty()) {
            p.write(&self.out, std::mem::take(&mut self.first), self.stop);
            self.out.clear();
        }
        if let Some(tx) = self.tx.filter(|_| !self.batch.is_empty()) {
            send(self.counters, tx, std::mem::take(&mut self.batch));
        }
    }
}





pub fn default_threads(f: &Files) -> usize {
    static N: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    if f.threads != 0 {
        return asked_threads(f);
    }
    *N.get_or_init(|| performance_cores().map_or_else(cores, |p| p.clamp(2, cores())))
}



pub const MAX_THREADS: usize = 256;


fn asked_threads(f: &Files) -> usize {
    f.threads.min(MAX_THREADS)
}




const COLD_READ_NS: u64 = if cfg!(target_os = "linux") { 30_000 } else { 75_000 };

fn reads_from_disk(c: &Counters) -> bool {
    // three quarters slow: a few reads delayed by a busy machine do not make a warm tree look cold
    let reads = c.small_reads.load(Ordering::Relaxed);
    reads >= 16 && c.slow_reads.load(Ordering::Relaxed) * 4 >= reads * 3
}






fn cold_threads() -> usize {
    if cfg!(target_os = "linux") {
        64
    } else {
        2 * cores()
    }
}





const COLD_READS_PER_THREAD: u64 = 16;


fn cold_extra(f: &Files, c: &Counters) -> usize {
    if f.threads == 0 && reads_from_disk(c) {
        let most = cold_threads().saturating_sub(default_threads(f));
        ((c.slow_reads.load(Ordering::Relaxed) / COLD_READS_PER_THREAD) as usize).min(most)
    } else {
        0
    }
}



fn range_threads(f: &Files) -> usize {
    if f.threads != 0 {
        asked_threads(f)
    } else {
        cores()
    }
}

fn cores() -> usize {
    static CORES: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    // a system call on some platforms, and asked once per file
    *CORES.get_or_init(|| std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2).min(12))
}

#[cfg(target_os = "macos")]
fn performance_cores() -> Option<usize> {
    extern "C" {
        fn sysctlbyname(name: *const std::ffi::c_char, oldp: *mut std::ffi::c_void, oldlenp: *mut usize, newp: *mut std::ffi::c_void, newlen: usize) -> i32;
    }
    let mut v: i32 = 0;
    let mut len = std::mem::size_of::<i32>();
    // SAFETY: a NUL-terminated name, an i32 to write and its size, no new value
    let rc = unsafe { sysctlbyname(c"hw.perflevel0.physicalcpu".as_ptr(), (&mut v as *mut i32).cast(), &mut len, std::ptr::null_mut(), 0) };
    (rc == 0 && len == std::mem::size_of::<i32>() && v > 0).then_some(v as usize)
}

#[cfg(not(target_os = "macos"))]
fn performance_cores() -> Option<usize> {
    None
}


pub const RGIGNORE: &str = ".rgignore";


pub fn overrides(root: &Path, f: &Files) -> Result<ignore::overrides::Override> {
    let mut ob = OverrideBuilder::new(root);
    ob.add(&format!("!{}/", crate::files::INDEX_DIR))?;
    for g in &f.globs {
        ob.add(g).with_context(|| format!("invalid glob {g:?}"))?;
    }
    for t in &f.types {
        let (neg, name) = match t.strip_prefix('!') {
            Some(n) => (true, n),
            None => (false, t.as_str()),
        };
        let globs = type_globs(name).ok_or_else(|| anyhow!("unknown file type {name:?} (see --type-list)"))?;
        for g in globs {
            ob.add(&if neg { format!("!{g}") } else { g })?;
        }
    }
    Ok(ob.build()?)
}



#[derive(Debug)]
pub struct ScopedGlobs {

    dir: PathBuf,
    ov: ignore::overrides::Override,
}


enum Scope {

    Below(PathBuf),

    Above(PathBuf),
    Outside,
}

impl ScopedGlobs {
    pub fn new(dir: &Path, globs: &[String]) -> Result<ScopedGlobs> {
        let mut ob = OverrideBuilder::new(".");
        for g in globs {
            ob.add(g).with_context(|| format!("invalid glob {g:?}"))?;
        }
        Ok(ScopedGlobs { dir: std::fs::canonicalize(dir).unwrap_or_else(|_| dir.to_path_buf()), ov: ob.build()? })
    }

    pub fn dir(&self) -> &Path {
        &self.dir
    }

    fn scope(&self, root: &Path) -> Scope {
        let Ok(root) = std::fs::canonicalize(root) else { return Scope::Outside };
        if let Ok(p) = root.strip_prefix(&self.dir) {
            Scope::Below(p.to_path_buf())
        } else if let Ok(p) = self.dir.strip_prefix(&root) {
            Scope::Above(p.to_path_buf())
        } else {
            Scope::Outside
        }
    }


    fn excludes(&self, scope: &Scope, rest: &Path, is_dir: bool) -> bool {
        thread_local! {
            static JOINED: std::cell::RefCell<PathBuf> = const { std::cell::RefCell::new(PathBuf::new()) };
        }
        match scope {
            Scope::Below(p) if p.as_os_str().is_empty() => self.ov.matched(rest, is_dir).is_ignore(),
            Scope::Below(p) => JOINED.with_borrow_mut(|j| {
                j.as_mut_os_string().clear();
                j.push(p);
                j.push(rest);
                self.ov.matched(&*j, is_dir).is_ignore()
            }),
            Scope::Above(p) => rest.strip_prefix(p).is_ok_and(|r| !r.as_os_str().is_empty() && self.ov.matched(r, is_dir).is_ignore()),
            Scope::Outside => false,
        }
    }



    fn excludes_file(&self, scope: &Scope, rel: &str) -> bool {
        let mut at = 0;
        while let Some(i) = rel[at..].find('/') {
            if self.excludes(scope, Path::new(&rel[..at + i]), true) {
                return true;
            }
            at += i + 1;
        }
        self.excludes(scope, Path::new(rel), false)
    }
}

pub fn build_walker(roots: &[PathBuf], f: &Files) -> Result<ignore::WalkParallel> {
    Ok(walk_builder(roots, f)?.build_parallel())
}

fn walk_builder(roots: &[PathBuf], f: &Files) -> Result<WalkBuilder> {
    let mut wb = WalkBuilder::new(&roots[0]);
    for r in &roots[1..] {
        wb.add(r);
    }
    wb.hidden(!f.hidden)
        .ignore(!f.no_ignore)
        .git_ignore(!f.no_ignore)
        .git_global(!f.no_ignore)
        .git_exclude(!f.no_ignore)
        .parents(!f.no_ignore)
        .follow_links(f.follow_links)
        .max_depth(f.max_depth)
        .max_filesize(f.max_filesize)
        .threads(default_threads(f));
    if !f.no_ignore {
        wb.add_custom_ignore_filename(RGIGNORE);
    }
    if let Some(cwd) = &f.cwd {
        wb.process_current_dir(cwd);
    }
    // anchored at a root that is a file, the filters would miss the files of the other roots
    let anchor = if roots[0].is_dir() { roots[0].as_path() } else { roots[0].parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or(Path::new(".")) };
    wb.overrides(overrides(anchor, f)?);
    if let Some(sg) = f.scoped_globs.clone() {
        let scopes: Vec<(PathBuf, Scope)> = roots.iter().map(|r| (r.clone(), sg.scope(r))).collect();
        wb.filter_entry(move |e| {
            let path = e.path();
            match scopes.iter().find_map(|(r, s)| path.strip_prefix(r).ok().map(|rest| (s, rest))) {
                Some((s, rest)) => !sg.excludes(s, rest, e.file_type().is_some_and(|t| t.is_dir())),
                None => true,
            }
        });
    }
    Ok(wb)
}







fn small_tree_files(roots: &[PathBuf], f: &Files) -> usize {
    f.small_tree.unwrap_or_else(|| if has_dirs(roots, f) { 0 } else { 256 })
}


fn has_dirs(roots: &[PathBuf], f: &Files) -> bool {
    roots.iter().any(|r| {
        std::fs::read_dir(r).is_ok_and(|mut entries| {
            entries.any(|e| {
                e.is_ok_and(|e| {
                    let dir = if f.follow_links { e.path().is_dir() } else { e.file_type().is_ok_and(|t| t.is_dir()) };
                    dir && (f.hidden || !e.file_name().as_encoded_bytes().starts_with(b"."))
                })
            })
        })
    })
}




fn searchable(e: &ignore::DirEntry) -> bool {
    e.file_type().is_some_and(|t| t.is_file() || (e.depth() == 0 && !t.is_dir() && !e.path().is_dir()))
}

enum Small {
    Done,


    Big(std::collections::HashMap<PathBuf, AtomicUsize>),
}







#[allow(clippy::too_many_arguments)]
fn small_first(
    roots: &[PathBuf],
    labels: &[PathBuf],
    q: &Query,
    f: &Files,
    matcher: &AnyMatcher,
    c: &Counters,
    stop: &Stop,
    plain: Option<&PlainSink>,
    on_hit: &mut dyn FnMut(Record),
) -> Small {
    let limit = small_tree_files(roots, f);
    if limit == 0 {
        return Small::Big(Default::default());
    }
    let Ok(wb) = walk_builder(roots, f) else { return Small::Big(Default::default()) };
    type Job = (PathBuf, Arc<str>, Option<u64>, bool);
    let (work_tx, work_rx) = mpsc::channel::<Job>();
    let work_rx = Mutex::new(work_rx);
    let (tx, rx) = hit_channel();
    let workers = default_threads(f).min(3);
    let (seen, errors, big) = std::thread::scope(|s| {
        let work_rx = &work_rx;
        let worker = |tx: mpsc::SyncSender<Vec<Record>>| {
            #[cfg(test)]
            tests::SMALL_WORKERS.with(|n| n.set(n.get() + 1));
            // a clone per thread: each gets its own regex cache pool instead of contending for one
            let matcher = matcher.clone();
            s.spawn(move || {
                let mut fw = file_worker(q);
                loop {
                    let job = match work_rx.lock() {
                        Ok(r) => r.recv(),
                        Err(_) => break,
                    };
                    let Ok((path, rel, size, named)) = job else { break };
                    if !stop.is_set() {
                        search_one(&mut fw, &Run { matcher: &matcher, q, f, c, stop, tx: &tx, plain, labels, raw: None }, &path, rel, size, named);
                    }
                }
            });
        };
        let (mut started, mut added) = (false, 0);
        let mut held: Option<Job> = None;
        let mut seen = std::collections::HashMap::<PathBuf, AtomicUsize>::new();
        let mut taken = 0;
        let mut errors = Vec::new();
        let mut big = false;
        for entry in wb.build() {
            if stop.is_set() {
                break;
            }
            let entry = match entry {
                Ok(e) => e,
                Err(e) => {
                    errors.push(e.to_string());
                    continue;
                }
            };
            if !searchable(&entry) {
                c.met_dir(&entry);
                continue;
            }
            if taken == limit {
                big = true;
                break;
            }
            taken += 1;
            let size = if q.want_bytes { entry.metadata().ok().map(|m| m.len()) } else { None };
            let rel = label(entry.path(), labels, f);
            let named = f.paths_as_given && entry.depth() == 0;
            let path = entry.into_path();
            *seen.entry(path.clone()).or_default().get_mut() += 1;
            let job = (path, rel, size, named);
            if !started {
                let Some(first) = held.take() else {
                    held = Some(job);
                    continue;
                };
                for _ in 0..workers {
                    worker(tx.clone());
                }
                started = true;
                if work_tx.send(first).is_err() {
                    break;
                }
            }
            if work_tx.send(job).is_err() {
                break;
            }
            while added < cold_extra(f, c) {
                worker(tx.clone());
                added += 1;
            }
            while let Ok(batch) = rx.try_recv() {
                #[cfg(test)]
                c.queued.fetch_sub(1, Ordering::Relaxed);
                batch.into_iter().for_each(&mut *on_hit);
            }
        }
        drop(work_tx);
        if let Some((path, rel, size, named)) = held.filter(|_| !stop.is_set()) {
            c.alone.store(true, Ordering::Relaxed);
            let tx = tx.clone();
            let one = move || search_one(&mut file_worker(q), &Run { matcher, q, f, c, stop, tx: &tx, plain, labels, raw: None }, &path, rel, size, named);
            // plain output sends no hits; other output is drained here while the file is searched
            if plain.is_some() {
                one();
            } else {
                s.spawn(one);
            }
        }
        drop(tx);
        drain(rx, c, &mut *on_hit);
        c.alone.store(false, Ordering::Relaxed);
        (seen, errors, big)
    });
    if big && !stop.is_set() {
        return Small::Big(seen);
    }
    for e in errors {
        c.failed(e);
    }
    Small::Done
}

#[derive(Default)]
struct Counters {
    files_searched: AtomicU64,

    small_reads: AtomicU64,

    slow_reads: AtomicU64,
    files_matched: AtomicU64,
    matches: AtomicU64,
    bytes: AtomicU64,
    errors: AtomicU64,
    failures: Mutex<Vec<String>>,


    pseudo_dirs: Mutex<Vec<PathBuf>>,
    has_pseudo_dirs: AtomicBool,


    alone: AtomicBool,

    #[cfg(test)]
    queued: AtomicUsize,
    #[cfg(test)]
    most_queued: AtomicUsize,
}

impl Counters {


    #[cfg_attr(not(target_os = "linux"), allow(unused_variables))]
    fn met_dir(&self, e: &ignore::DirEntry) {
        #[cfg(target_os = "linux")]
        if e.depth() > 0 && matches!(e.file_name().as_encoded_bytes(), b"proc" | b"sys") && e.file_type().is_some_and(|t| t.is_dir()) && on_pseudo_fs(e.path())
        {
            self.pseudo_dirs.lock().unwrap_or_else(|p| p.into_inner()).push(e.path().to_path_buf());
            self.has_pseudo_dirs.store(true, Ordering::Release);
        }
    }


    fn pseudo_roots(&self, roots: Vec<PathBuf>) {
        if !roots.is_empty() {
            self.pseudo_dirs.lock().unwrap_or_else(|p| p.into_inner()).extend(roots);
            self.has_pseudo_dirs.store(true, Ordering::Release);
        }
    }


    fn read_to_end(&self, path: &Path) -> bool {
        self.has_pseudo_dirs.load(Ordering::Acquire) && self.pseudo_dirs.lock().unwrap_or_else(|p| p.into_inner()).iter().any(|p| path.starts_with(p))
    }

    fn failed(&self, what: String) {
        self.errors.fetch_add(1, Ordering::Relaxed);
        if let Ok(mut v) = self.failures.lock() {
            if v.len() < 10 {
                v.push(what);
            }
        }
    }
}



struct Stop {
    cancel: Arc<AtomicBool>,
    own: AtomicBool,
}

impl Stop {
    fn new(cancel: Arc<AtomicBool>) -> Stop {
        Stop { cancel, own: AtomicBool::new(false) }
    }

    #[inline]
    fn is_set(&self) -> bool {
        self.own.load(Ordering::Relaxed) || self.cancel.load(Ordering::Relaxed)
    }

    fn set(&self) {
        self.own.store(true, Ordering::Relaxed);
    }
}



#[derive(Clone, Copy)]
struct Run<'a> {
    matcher: &'a AnyMatcher,
    q: &'a Query,
    f: &'a Files,
    c: &'a Counters,
    stop: &'a Stop,
    tx: &'a mpsc::SyncSender<Vec<Record>>,
    plain: Option<&'a PlainSink>,

    labels: &'a [PathBuf],

    raw: Option<&'a Arc<[u8]>>,
}

impl<'a> Run<'a> {
    fn collector(&self, path: Arc<str>) -> Collector<'a> {
        let (o, f) = (self.q, self.f);
        Collector {
            path,
            raw: self.raw.cloned(),
            tx: Some(self.tx),
            counters: self.c,
            batch: Vec::new(),
            plain: self.plain,
            out: Vec::new(),
            want_spans: o.want_spans,
            text_spans: o.text_spans,
            stats_matches: &self.c.matches,
            max_results: o.max_results,
            matched: false,
            stop: self.stop,
            matcher: self.matcher,
            invert: o.invert,
            report: o.report,
            file_count: 0,
            line_base: 0,
            hold: false,
            binary: false,
            convert: false,
            binary_at: None,
            multiline: o.pattern.multiline,
            first: o.before > 0 || o.after > 0,
            whole_groups: (o.before > 0 || o.after > 0) && default_threads(f) > 1 && !self.c.alone.load(Ordering::Relaxed),
            named: o.with_filename,
            numbered: o.line_numbers,
            count_each: o.pattern.multiline && o.report == Report::Counts && !o.invert && self.matcher.spans_lines(),
        }
    }
}



fn search_one(w: &mut FileWorker, r: &Run, path: &Path, rel: Arc<str>, size: Option<u64>, named: bool) {
    let raw = label_bytes(path, r.labels, r.f);
    let r = &Run { raw: raw.as_ref(), ..*r };
    count_file(r, size);
    if r.f.search_zip {
        if let Some(kind) = crate::archive::Kind::of(&rel) {
            search_archive(w, r, path, &rel, kind);
            return;
        }
    }
    if named && path.as_os_str() == "-" {
        source::search(w, r, &mut source::Stdin, rel, true);
        return;
    }
    match source::Disk::open(path, size, !r.c.read_to_end(path)) {
        Ok(mut file) => source::search(w, r, &mut file, rel, named),
        Err(e) => r.c.failed(format!("{rel}: {e}")),
    }
}


fn count_file(r: &Run, size: Option<u64>) {
    if let Some(p) = r.plain {
        p.tick(r.stop);
    }
    r.c.files_searched.fetch_add(1, Ordering::Relaxed);
    if let Some(n) = size {
        r.c.bytes.fetch_add(n, Ordering::Relaxed);
    }
}




fn report(r: &Run, mut sink: Collector, rel: Arc<str>, named: bool) -> Vec<u8> {
    sink.flush();
    if sink.matched && (named || !sink.binary || r.q.report == Report::Lines) {
        r.c.files_matched.fetch_add(1, Ordering::Relaxed);
        match r.q.report {
            Report::Lines => {}
            Report::Counts => send(r.c, r.tx, vec![Record::Count { path: rel, path_bytes: sink.raw.clone(), count: sink.file_count }]),
            Report::Files => send(r.c, r.tx, vec![Record::File { path: rel, path_bytes: sink.raw.clone() }]),
        }
    }
    let mut out = std::mem::take(&mut sink.out);
    out.clear();
    // a buffer that grew past the usual flush size (a context group held whole) is not kept
    if out.capacity() > 1 << 17 {
        out = Vec::new();
    }
    out
}



fn search_archive(w: &mut FileWorker, run: &Run, path: &Path, rel: &Arc<str>, kind: crate::archive::Kind) {
    let (c, stop) = (run.c, run.stop);
    // the members of one archive share a searcher, made for that archive
    w.member = None;
    let mut each = |member: Option<&str>, r: &mut dyn std::io::Read| -> bool {
        let m = member.map(|m| if run.q.raw_member_names { std::borrow::Cow::Borrowed(m) } else { crate::fmt::shown(m) });
        let label: Arc<str> = match &m {
            Some(m) => Arc::from(format!("{rel}{{{m}}}")),
            None => Arc::clone(rel),
        };
        let raw = match (run.raw, &m) {
            (Some(b), Some(m)) => Some(Arc::from([&b[..], b"{", m.as_bytes(), b"}"].concat())),
            (b, _) => b.cloned(),
        };
        source::search(w, &Run { raw: raw.as_ref(), ..*run }, &mut source::Member(r), label, false);
        !stop.is_set()
    };
    let mut failed = |what: String| c.failed(format!("{rel}: {what}"));
    if let Err(e) = crate::archive::walk(path, kind, &mut each, &mut failed) {
        c.failed(format!("{rel}: {e}"));
    }
}



const HIT_BATCHES: usize = 64;

fn hit_channel() -> (mpsc::SyncSender<Vec<Record>>, mpsc::Receiver<Vec<Record>>) {
    mpsc::sync_channel(HIT_BATCHES)
}


fn send(c: &Counters, tx: &mpsc::SyncSender<Vec<Record>>, batch: Vec<Record>) {
    #[cfg(test)]
    c.most_queued.fetch_max(c.queued.fetch_add(1, Ordering::Relaxed) + 1, Ordering::Relaxed);
    #[cfg(not(test))]
    let _ = c;
    let _ = tx.send(batch);
}


fn drain(rx: mpsc::Receiver<Vec<Record>>, c: &Counters, mut on_hit: impl FnMut(Record)) {
    for batch in rx {
        #[cfg(test)]
        c.queued.fetch_sub(1, Ordering::Relaxed);
        batch.into_iter().for_each(&mut on_hit);
    }
    #[cfg(test)]
    tests::MOST_QUEUED.with(|m| m.set(m.get().max(c.most_queued.load(Ordering::Relaxed))));
    #[cfg(not(test))]
    let _ = c;
}

fn stats(c: &Counters, t0: Instant, stop: &Stop) -> Stats {
    Stats {
        files_searched: c.files_searched.load(Ordering::Relaxed),
        files_matched: c.files_matched.load(Ordering::Relaxed),
        matches: c.matches.load(Ordering::Relaxed),
        bytes_searched: c.bytes.load(Ordering::Relaxed),
        errors: c.errors.load(Ordering::Relaxed),
        elapsed_ms: t0.elapsed().as_secs_f64() * 1000.0,
        cancelled: stop.is_set(),
        failures: c.failures.lock().map(|v| v.clone()).unwrap_or_default(),
    }
}




pub fn search(query: &Query, files: &Files, cancel: Arc<AtomicBool>, out: Output) -> Result<Stats> {
    let stop = Arc::new(Stop::new(cancel));
    let mut none = |_: Record| {};
    let (plain, on_record): (Option<Arc<PlainSink>>, &mut dyn FnMut(Record)) = match out {
        Output::Records(f) => (None, f),
        Output::Plain(p) => (Some(p), &mut none),
    };
    match &files.paths {
        Paths::Walk(roots) => run_walk(roots, query, files, stop, plain, on_record),
        Paths::List { root, files: list } => run_files(root, list, query, files, stop, plain, on_record),
        Paths::Memory(texts) => run_memory(texts, query, files, stop, plain, on_record),
    }
}


fn run_memory(
    texts: &[(String, Vec<u8>)],
    q: &Query,
    f: &Files,
    stop: Arc<Stop>,
    plain: Option<Arc<PlainSink>>,
    on_hit: &mut dyn FnMut(Record),
) -> Result<Stats> {
    let t0 = Instant::now();
    if q.first_in_path_order && plain.is_some() {
        bail!("first_in_path_order needs records, not plain output");
    }
    let matcher = build_matcher(&q.pattern)?;
    let counters = Counters::default();
    let mut order: Vec<&(String, Vec<u8>)> = texts.iter().collect();
    if q.first_in_path_order {
        order.sort_by(|a, b| Path::new(&a.0).cmp(Path::new(&b.0)));
    }
    let (tx, rx) = hit_channel();
    let (c, stop) = (&counters, &*stop);
    std::thread::scope(|s| {
        let matcher = &matcher;
        let plain = plain.as_deref();
        s.spawn(move || {
            let mut fw = file_worker(q);
            let r = Run { matcher, q, f, c, stop, tx: &tx, plain, labels: &[], raw: None };
            for (name, bytes) in order {
                if stop.is_set() {
                    break;
                }
                count_file(&r, q.want_bytes.then_some(bytes.len() as u64));
                source::search(&mut fw, &r, &mut source::Bytes(bytes), Arc::from(name.as_str()), false);
            }
        });
        drain(rx, c, &mut *on_hit);
    });
    Ok(stats(&counters, t0, stop))
}

fn run_walk(roots: &[PathBuf], q: &Query, f: &Files, stop: Arc<Stop>, plain: Option<Arc<PlainSink>>, on_hit: &mut dyn FnMut(Record)) -> Result<Stats> {
    let t0 = Instant::now();
    if roots.is_empty() {
        bail!("no paths to search");
    }
    let matcher = Arc::new(build_matcher(&q.pattern)?);
    let counters = Arc::new(Counters::default());
    let rest: Vec<PathBuf>;
    let stdin_too = f.paths_as_given && roots.iter().any(|r| r.as_os_str() == "-");
    let given = roots;
    let roots = if stdin_too {
        rest = roots.iter().filter(|r| r.as_os_str() != "-").cloned().collect();
        &rest[..]
    } else {
        roots
    };
    counters.pseudo_roots(pseudo_roots(roots));
    if q.first_in_path_order {
        if plain.is_some() {
            bail!("first_in_path_order needs records, not plain output");
        }
        // as `rg --sort path`: the roots in the order given, each walked in path order
        let mut files = Vec::new();
        for root in given {
            if stdin_too && root.as_os_str() == "-" {
                files.push((PathBuf::from("-"), Arc::from(STDIN_LABEL), true));
                continue;
            }
            let at = files.len();
            files.extend(list_files(std::slice::from_ref(root), roots, f, &counters)?);
            files[at..].sort_by(|a, b| Path::new(&*a.1).cmp(Path::new(&*b.1)));
        }
        return Ok(first_in_path_order(files, roots, &matcher, q, f, &counters, &stop, on_hit, t0));
    }
    if stdin_too {
        search_stdin(q, f, &matcher, &counters, &stop, plain.as_deref(), on_hit);
    }
    if roots.is_empty() {
        return Ok(stats(&counters, t0, &stop));
    }
    // the overrides are anchored at one root: a glob naming a directory needs a walk per root
    if roots.len() > 1 && f.globs.iter().any(|g| g.contains('/')) {
        for root in roots.chunks(1) {
            if !stop.is_set() {
                walk(root, roots, q, f, &matcher, &counters, &stop, plain.clone(), on_hit)?;
            }
        }
    } else {
        walk(roots, roots, q, f, &matcher, &counters, &stop, plain, on_hit)?;
    }
    Ok(stats(&counters, t0, &stop))
}


fn search_stdin(q: &Query, f: &Files, matcher: &AnyMatcher, c: &Counters, stop: &Stop, plain: Option<&PlainSink>, on_hit: &mut dyn FnMut(Record)) {
    let (tx, rx) = hit_channel();
    c.alone.store(true, Ordering::Relaxed);
    std::thread::scope(|s| {
        s.spawn(move || {
            let mut fw = file_worker(q);
            search_one(&mut fw, &Run { matcher, q, f, c, stop, tx: &tx, plain, labels: &[], raw: None }, Path::new("-"), Arc::from(STDIN_LABEL), None, true);
        });
        drain(rx, c, &mut *on_hit);
    });
    c.alone.store(false, Ordering::Relaxed);
}






const COUNTED_AFTER: u64 = 1000;
const COUNTED_EARLY: u64 = 4;



fn show_share(shown: &AtomicUsize, running: Option<usize>, threads: usize) {
    static DEBUG: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if !*DEBUG.get_or_init(|| std::env::var_os("SCRUTATE_GREP_DEBUG").is_some_and(|v| !v.is_empty())) {
        return;
    }
    let key = running.map_or(usize::MAX, |k| k << 16 | threads);
    if shown.swap(key, Ordering::Relaxed) != key {
        match running {
            Some(k) => eprintln!("[scrutate] searches running: {k}, threads: {threads}"),
            None => eprintln!("[scrutate] searches running: not counted, threads: {threads}"),
        }
    }
}


#[allow(clippy::too_many_arguments)]
fn walk(
    roots: &[PathBuf],
    labels: &[PathBuf],
    q: &Query,
    f: &Files,
    matcher: &Arc<AnyMatcher>,
    counters: &Arc<Counters>,
    stop: &Arc<Stop>,
    plain: Option<Arc<PlainSink>>,
    on_hit: &mut dyn FnMut(Record),
) -> Result<()> {
    let searched = match small_first(roots, labels, q, f, matcher, counters, stop, plain.as_deref(), on_hit) {
        Small::Done => return Ok(()),
        Small::Big(seen) => Arc::new(seen),
    };
    let threads = default_threads(f);
    // counted only without -j: a number asked for is kept
    let counted = (f.threads == 0).then(|| Arc::new(std::sync::OnceLock::<Option<crate::running::Counted>>::new()));
    let shown = Arc::new(AtomicUsize::new(0));
    let first = match &counted {
        Some(counted) => {
            let k = counted.get_or_init(crate::running::Counted::start).as_ref().and_then(|n| n.running());
            let first = k.map_or(threads, |k| crate::running::threads(threads, k));
            show_share(&shown, k, first);
            first
        }
        None => threads,
    };
    let share = Arc::new(AtomicUsize::new(first));
    let early = Arc::new(AtomicBool::new(false));
    // raised as reads turn out to come from the disk: the walk grows by that many threads
    let cold = Arc::new(AtomicUsize::new(cold_extra(f, counters)));
    // the threads the walk runs: the share plus the cold ones
    let want = Arc::new(AtomicUsize::new(first + cold.load(Ordering::Relaxed)));
    let mut wb = walk_builder(roots, f)?;
    // the share starts, and the rest when the count falls or the reads turn out cold
    wb.threads(first);
    if f.threads == 0 {
        wb.grow_threads(cold_threads().max(threads).saturating_sub(first), Arc::clone(&want));
    }
    let walker = wb.build_parallel();
    let (tx, rx) = hit_channel();
    let labels_owned: Arc<[PathBuf]> = labels.into();
    let matcher = Arc::clone(matcher);
    let (q, f) = (Arc::new(q.clone()), Arc::new(f.clone()));
    let (c2, stop2) = (Arc::clone(counters), Arc::clone(stop));
    let worker = std::thread::spawn(move || {
        walker.run(|| {
            let tx = tx.clone();
            // a clone per thread: each gets its own regex cache pool instead of contending for one
            let matcher = AnyMatcher::clone(&matcher);
            let stop = Arc::clone(&stop2);
            let c = Arc::clone(&c2);
            let (q, f) = (Arc::clone(&q), Arc::clone(&f));
            let labels = Arc::clone(&labels_owned);
            let plain = plain.clone();
            let searched = Arc::clone(&searched);
            let (cold, want, share, shown) = (Arc::clone(&cold), Arc::clone(&want), Arc::clone(&share), Arc::clone(&shown));
            let counted = counted.clone();
            let early = Arc::clone(&early);
            let mut files = 0u32;
            // made on the first file: the threads kept for a cold walk mostly never run
            let mut fw = None;
            Box::new(move |entry| {
                if stop.is_set() {
                    return WalkState::Quit;
                }
                let entry = match entry {
                    Ok(e) => e,
                    Err(e) => {
                        c.failed(e.to_string());
                        return WalkState::Continue;
                    }
                };
                if !searchable(&entry) {
                    c.met_dir(&entry);
                    return WalkState::Continue;
                }
                if let Some(n) = if searched.is_empty() { None } else { searched.get(entry.path()) } {
                    let mut left = n.load(Ordering::Relaxed);
                    while left > 0 {
                        match n.compare_exchange_weak(left, left - 1, Ordering::Relaxed, Ordering::Relaxed) {
                            Ok(_) => return WalkState::Continue,
                            Err(now) => left = now,
                        }
                    }
                }
                let size = if q.want_bytes { entry.metadata().ok().map(|m| m.len()) } else { None };
                let rel = label(entry.path(), &labels, &f);
                let fw = fw.get_or_insert_with(|| file_worker(&q));
                let named = f.paths_as_given && entry.depth() == 0;
                let run = Run { matcher: &matcher, q: &q, f: &f, c: &c, stop: &stop, tx: &tx, plain: plain.as_deref(), labels: &labels, raw: None };
                search_one(fw, &run, entry.path(), rel, size, named);
                let extra = cold_extra(&f, &c);
                let mut changed = extra > cold.load(Ordering::Relaxed);
                if changed {
                    cold.fetch_max(extra, Ordering::Relaxed);
                }
                // looked at again as searches start and end, and once after the first few files:
                // searches started together each saw fewer of the others than there are
                files = files.wrapping_add(1);
                let searched = c.files_searched.load(Ordering::Relaxed);
                let again = (files % 64 == 16 && searched >= COUNTED_AFTER) || (searched >= COUNTED_EARLY && !early.swap(true, Ordering::Relaxed));
                if let Some(counted) = counted.as_ref().filter(|_| again) {
                    let n = counted.get_or_init(crate::running::Counted::start);
                    let k = n.as_ref().and_then(|n| n.running());
                    let now = k.map_or(threads, |k| crate::running::threads(threads, k));
                    changed |= share.swap(now, Ordering::Relaxed) != now;
                    show_share(&shown, k, now);
                }
                if changed {
                    want.store(share.load(Ordering::Relaxed) + cold.load(Ordering::Relaxed), Ordering::Relaxed);
                }
                if stop.is_set() {
                    WalkState::Quit
                } else {
                    WalkState::Continue
                }
            })
        });
    });
    drain(rx, counters, &mut *on_hit);
    worker.join().map_err(|_| anyhow!("search worker panicked"))?;
    Ok(())
}



fn run_files(
    root: &Path,
    list: &[String],
    q: &Query,
    f: &Files,
    stop: Arc<Stop>,
    plain: Option<Arc<PlainSink>>,
    on_hit: &mut dyn FnMut(Record),
) -> Result<Stats> {
    let t0 = Instant::now();
    let matcher = build_matcher(&q.pattern)?;
    let ov = overrides(root, f)?;
    let scoped = f.scoped_globs.as_ref().map(|sg| (sg, sg.scope(root)));
    let mut files: Vec<(PathBuf, Arc<str>, bool)> = list
        .iter()
        .filter(|rel| !filtered_out(&ov, rel) && !scoped.as_ref().is_some_and(|(sg, s)| sg.excludes_file(s, rel)))
        .map(|rel| (root.join(rel), Arc::from(rel.as_str()), false))
        .collect();
    let counters = Counters::default();
    if q.first_in_path_order {
        if plain.is_some() {
            bail!("first_in_path_order needs records, not plain output");
        }
        files.sort_by(|a, b| Path::new(&*a.1).cmp(Path::new(&*b.1)));
        return Ok(first_in_path_order(files, &[root.to_path_buf()], &matcher, q, f, &counters, &stop, on_hit, t0));
    }
    let threads = default_threads(f).min(files.len().max(1));
    search_list(&files, &[root.to_path_buf()], threads, None, &matcher, q, f, &counters, &stop, plain.as_deref(), on_hit);
    Ok(stats(&counters, t0, &stop))
}



fn list_files(roots: &[PathBuf], labels: &[PathBuf], f: &Files, c: &Counters) -> Result<Vec<(PathBuf, Arc<str>, bool)>> {
    let found = Mutex::new(Vec::new());
    walk_builder(roots, f)?.build_parallel().run(|| {
        Box::new(|entry| {
            match entry {
                Ok(e) if searchable(&e) => {
                    let item = (e.path().to_path_buf(), label(e.path(), labels, f), f.paths_as_given && e.depth() == 0);
                    found.lock().unwrap_or_else(|p| p.into_inner()).push(item);
                }
                Ok(e) => c.met_dir(&e),
                Err(e) => c.failed(e.to_string()),
            }
            WalkState::Continue
        })
    });
    Ok(found.into_inner().unwrap_or_else(|p| p.into_inner()))
}




#[allow(clippy::too_many_arguments)]
fn first_in_path_order(
    files: Vec<(PathBuf, Arc<str>, bool)>,
    labels: &[PathBuf],
    matcher: &AnyMatcher,
    q: &Query,
    f: &Files,
    c: &Counters,
    stop: &Stop,
    on_hit: &mut dyn FnMut(Record),
    t0: Instant,
) -> Stats {
    let n = q.max_results;
    // no file holds more than `n` of the first `n`; the cut below stops the rest
    let q = Query { max_results: None, max_count: n.map(|n| q.max_count.map_or(n, |m| m.min(n))).or(q.max_count), ..q.clone() };
    let mut records = Vec::new();
    let threads = default_threads(f).min(files.len().max(1));
    search_list(&files, labels, threads, n, matcher, &q, f, c, stop, None, |r| records.push(r));
    // a file that several roots reach is listed once per root under one label: the k-th copy of a
    // record belongs to its k-th listing
    let mut listed: std::collections::HashMap<&str, Vec<usize>> = Default::default();
    for (i, f) in files.iter().enumerate() {
        listed.entry(&*f.1).or_default().push(i);
    }
    let listing = |label: &str| {
        let mut s = label;
        loop {
            if let Some(v) = listed.get(s) {
                return Some(v);
            }
            // an archive member, `archive.zip{member}`
            s = &s[..s.rfind('{')?];
        }
    };
    let at: Vec<usize> = {
        let mut copies: std::collections::HashMap<(&str, u64, u64), usize> = Default::default();
        records
            .iter()
            .map(|r| {
                let column = if let Record::Match(l) | Record::Context(l) = r { l.column } else { 0 };
                let copy = copies.entry((r.path(), r.order(), column)).or_insert(0);
                *copy += 1;
                listing(r.path()).map_or(usize::MAX, |v| v[(*copy - 1).min(v.len() - 1)])
            })
            .collect()
    };
    let mut keyed: Vec<(usize, Record)> = at.into_iter().zip(records).collect();
    keyed.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| a.1.path().cmp(b.1.path())).then(a.1.order().cmp(&b.1.order())));
    let cap = n.unwrap_or(u64::MAX);
    let (mut left, mut files_matched, mut last) = (cap, 0u64, None::<Arc<str>>);
    for (_, mut r) in keyed {
        if left == 0 {
            break;
        }
        let take = match &mut r {
            Record::Match(_) | Record::File { .. } => 1,
            Record::Count { count, .. } => {
                *count = (*count).min(left);
                *count
            }
            Record::Context(_) | Record::Note { .. } => 0,
        };
        if take > 0 {
            left -= take;
            if last.as_ref() != Some(r.path()) {
                files_matched += 1;
                last = Some(Arc::clone(r.path()));
            }
        }
        on_hit(r);
    }
    let total = c.matches.load(Ordering::Relaxed);
    match n {
        Some(n) => Stats { matches: n - left, files_matched, cancelled: stop.is_set() || total >= n, ..stats(c, t0, stop) },
        None => stats(c, t0, stop),
    }
}



#[allow(clippy::too_many_arguments)]
fn search_list(
    files: &[(PathBuf, Arc<str>, bool)],
    labels: &[PathBuf],
    threads: usize,
    stop_at: Option<u64>,
    matcher: &AnyMatcher,
    q: &Query,
    f: &Files,
    counters: &Counters,
    stop: &Stop,
    plain: Option<&PlainSink>,
    on_hit: impl FnMut(Record),
) {
    let (tx, rx) = hit_channel();
    let next = std::sync::atomic::AtomicUsize::new(0);
    std::thread::scope(|s| {
        for _ in 0..threads {
            let tx = tx.clone();
            let next = &next;
            // a clone per thread: each gets its own regex cache pool instead of contending for one
            let matcher = matcher.clone();
            s.spawn(move || {
                let matcher = &matcher;
                let mut fw = file_worker(q);
                loop {
                    // checked before a file is taken, so the files searched are always the first ones
                    if stop.is_set() || stop_at.is_some_and(|n| counters.matches.load(Ordering::Relaxed) >= n) {
                        break;
                    }
                    let i = next.fetch_add(1, Ordering::Relaxed);
                    let Some((path, rel, named)) = files.get(i) else { break };
                    let size = if q.want_bytes { std::fs::metadata(path).ok().map(|m| m.len()) } else { None };
                    search_one(&mut fw, &Run { matcher, q, f, c: counters, stop, tx: &tx, plain, labels, raw: None }, path, Arc::clone(rel), size, *named);
                }
            });
        }
        drop(tx);
        drain(rx, counters, on_hit);
    });
}



fn filtered_out(ov: &ignore::overrides::Override, rel: &str) -> bool {
    if ov.is_empty() {
        return false;
    }
    let mut at = 0;
    while let Some(i) = rel[at..].find('/') {
        if ov.matched(&rel[..at + i], true).is_ignore() {
            return true;
        }
        at += i + 1;
    }
    ov.matched(rel, false).is_ignore()
}



#[cfg(target_os = "linux")]
fn pseudo_roots(roots: &[PathBuf]) -> Vec<PathBuf> {
    roots.iter().filter(|r| on_pseudo_fs(r)).cloned().collect()
}

#[cfg(not(target_os = "linux"))]
fn pseudo_roots(_roots: &[PathBuf]) -> Vec<PathBuf> {
    Vec::new()
}



#[cfg(target_os = "linux")]
fn on_pseudo_fs(p: &Path) -> bool {
    use std::os::unix::ffi::OsStrExt;
    extern "C" {
        fn statfs(path: *const std::ffi::c_char, buf: *mut u64) -> std::ffi::c_int;
    }
    let Ok(c) = std::ffi::CString::new(p.as_os_str().as_bytes()) else { return false };
    // larger than `struct statfs` on every Linux ABI; `f_type` is its first field
    let mut buf = [0u64; 32];
    if unsafe { statfs(c.as_ptr(), buf.as_mut_ptr()) } != 0 {
        return false;
    }
    #[cfg(target_arch = "s390x")]
    let f_type = (buf[0] >> 32) as u32;
    #[cfg(not(target_arch = "s390x"))]
    let f_type = unsafe { *(buf.as_ptr() as *const std::ffi::c_long) } as u32;
    // proc, sysfs, debugfs, tracefs, securityfs, configfs, cgroup, cgroup2
    matches!(f_type, 0x9fa0 | 0x6265_6572 | 0x6462_6720 | 0x7472_6163 | 0x7363_6673 | 0x6265_6570 | 0x0027_e0eb | 0x6367_7270)
}


fn label(path: &Path, roots: &[PathBuf], f: &Files) -> Arc<str> {
    if !f.paths_as_given {
        return Arc::from(relative(path, roots));
    }
    let s = path.to_string_lossy();
    if cfg!(windows) {
        Arc::from(slashed(s))
    } else {
        Arc::from(&*s)
    }
}



#[cfg(unix)]
fn label_bytes(path: &Path, roots: &[PathBuf], f: &Files) -> Option<Arc<[u8]>> {
    use std::os::unix::ffi::OsStrExt;
    if path.to_str().is_some() {
        return None;
    }
    fn bytes(p: &Path) -> &[u8] {
        p.as_os_str().as_bytes()
    }
    let under = if f.paths_as_given { None } else { roots.iter().find_map(|r| Some((r, path.strip_prefix(r).ok()?))) };
    Some(match under {
        Some((r, rel)) if rel.as_os_str().is_empty() => bytes(r).into(),
        Some((_, rel)) if roots.len() == 1 => bytes(rel).into(),
        Some((r, rel)) => {
            let mut root = bytes(r);
            while let [rest @ .., b'/'] = root {
                root = rest;
            }
            [root, b"/", bytes(rel)].concat().into()
        }
        None => bytes(path).into(),
    })
}

#[cfg(not(unix))]
fn label_bytes(_path: &Path, _roots: &[PathBuf], _f: &Files) -> Option<Arc<[u8]>> {
    None
}



pub fn slashed(s: std::borrow::Cow<'_, str>) -> String {
    if cfg!(windows) {
        windows_form(&s)
    } else {
        s.into_owned()
    }
}



fn windows_form(s: &str) -> String {
    let s = s.replace('\\', "/");
    match s.strip_prefix("//?/") {
        Some(rest) if rest.as_bytes().get(1) == Some(&b':') => rest.to_string(),
        _ => s,
    }
}

pub fn relative(path: &Path, roots: &[PathBuf]) -> String {
    for r in roots {
        if let Ok(rel) = path.strip_prefix(r) {
            let s = slashed(rel.to_string_lossy());
            if s.is_empty() {
                // the root is the file itself
                return slashed(r.to_string_lossy());
            }
            if roots.len() == 1 {
                return s;
            }
            return format!("{}/{}", r.to_string_lossy().trim_end_matches('/'), s);
        }
    }
    path.to_string_lossy().into_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    thread_local! {

        pub(super) static SMALL_WORKERS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };

        pub(super) static ONE_LINE: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };

        pub(super) static NO_ONE_LINE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };

        pub(super) static MOST_QUEUED: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    }

    fn query(text: &str, mode: Mode) -> Query {
        Query { pattern: Pattern { text: text.into(), mode, ..Pattern::default() }, ..Query::default() }
    }

    fn no_stop() -> Stop {
        Stop::new(Arc::default())
    }


    fn line(r: Record) -> Line {
        match r {
            Record::Match(l) | Record::Context(l) => l,
            other => panic!("not a line: {other:?}"),
        }
    }

    #[cfg(unix)]
    #[test]
    fn a_path_that_is_not_utf8_is_reported_with_its_bytes() {
        use std::os::unix::ffi::OsStrExt;
        let os = |b: &[u8]| PathBuf::from(std::ffi::OsStr::from_bytes(b));
        let walked = Files::default();
        let given = Files { paths_as_given: true, ..Files::default() };
        let file = os(b"/r/d\xff/a\xfe.c");
        let bytes = |roots: &[PathBuf], o: &Files| label_bytes(&file, roots, o).map(|b| b.to_vec());
        assert_eq!(label_bytes(&os(b"/r/d/a.c"), &[os(b"/r")], &walked), None);
        assert_eq!(bytes(&[os(b"/r")], &walked).unwrap(), b"d\xff/a\xfe.c");
        assert_eq!(bytes(&[os(b"/r//"), os(b"/x")], &walked).unwrap(), b"/r/d\xff/a\xfe.c");
        assert_eq!(bytes(std::slice::from_ref(&file), &walked).unwrap(), b"/r/d\xff/a\xfe.c");
        assert_eq!(bytes(&[os(b"/r")], &given).unwrap(), b"/r/d\xff/a\xfe.c");
        assert_eq!(&*label(&file, &[os(b"/r")], &walked), "d\u{FFFD}/a\u{FFFD}.c");

        // the plain writer writes the bytes; a hit and a count carry them
        #[derive(Clone)]
        struct Shared(Arc<Mutex<Vec<u8>>>);
        impl Write for Shared {
            fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
                self.0.lock().unwrap().extend_from_slice(b);
                Ok(b.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let written = Shared(Arc::default());
        let plain = PlainSink::new(Box::new(written.clone()));
        let raw: Arc<[u8]> = Arc::from(&b"d\xff/a\xfe.c"[..]);
        let (tx, rx) = mpsc::sync_channel(16);
        for (to_plain, kind) in [(true, Report::Lines), (false, Report::Lines), (false, Report::Counts)] {
            let o = Query { report: kind, ..query("x", Mode::Literal) };
            let matcher = build_matcher(&o.pattern).unwrap();
            let (c, stop) = (Counters::default(), no_stop());
            let r = Run { matcher: &matcher, q: &o, f: &walked, c: &c, stop: &stop, tx: &tx, plain: to_plain.then_some(&plain), labels: &[], raw: Some(&raw) };
            let rel: Arc<str> = label(&file, &[os(b"/r")], &walked);
            let mut sink = r.collector(Arc::clone(&rel));
            matcher.search_slice(&mut source::make_searcher(&o, BinaryDetection::quit(0), None, true), b"a x\n", &mut sink).unwrap();
            report(&r, sink, rel, false);
        }
        plain.flush().unwrap();
        assert_eq!(*written.0.lock().unwrap(), b"d\xff/a\xfe.c:1:a x\n");
        drop(tx);
        let records: Vec<Record> = rx.into_iter().flatten().collect();
        assert!(matches!(records[..], [Record::Match(_), Record::Count { count: 1, .. }]), "{records:?}");
        assert!(records.iter().all(|r| r.path_bytes() == Some(&raw[..]) && &**r.path() == "d\u{FFFD}/a\u{FFFD}.c"));
    }

    #[cfg(target_pointer_width = "64")]
    #[test]
    fn a_record_costs_no_more_than_the_line_it_carries_and_a_word() {
        // 104 bytes: what one result took when a flag and a sentinel line number told its kind
        assert_eq!(std::mem::size_of::<Line>(), 96);
        assert_eq!(std::mem::size_of::<Record>(), 104);
    }

    #[test]
    fn offsets_in_a_line_with_invalid_utf8_become_offsets_in_its_text() {
        // one invalid piece of three bytes keeps the length; a match inside it takes the U+FFFD whole
        let line = b"a\xF0\x9F\x98b\xFFc";
        let text = lossy(line);
        assert_eq!(text, "a\u{FFFD}b\u{FFFD}c");
        let mut spans = [(0, 1), (2, 3), (1, 4), (4, 5), (5, 6), (6, 7), (6, 9)];
        text_offsets(&mut spans, line, &text, false);
        assert_eq!(spans, [(0, 1), (1, 4), (1, 4), (4, 5), (5, 8), (8, 9), (8, 9)]);
        // valid text: only cut to its end, on a character boundary
        let mut spans = [(1, 2), (2, 7)];
        text_offsets(&mut spans, "aé".as_bytes(), "aé", true);
        assert_eq!(spans, [(1, 3), (1, 3)]);
    }

    #[test]
    fn hits_found_faster_than_the_caller_takes_them_wait_in_the_search_threads() {
        let root = std::env::temp_dir().join(format!("scrutate_bounded_hits_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(root.join("many/sub")).unwrap();
        std::fs::create_dir_all(root.join("one")).unwrap();
        let lines = "abc e\n".repeat(100_000);
        std::fs::write(root.join("one/a.txt"), &lines).unwrap();
        for i in 0..6 {
            std::fs::write(root.join(format!("many/sub/{i}.txt")), &lines).unwrap();
        }
        // one file on the calling thread; several on the small walk, the parallel walk and in ranges
        let shapes: [(&str, Option<usize>, u64); 4] =
            [("one", None, 64 << 20), ("many", Some(256), 64 << 20), ("many", None, 64 << 20), ("one", None, 1 << 16)];
        for (dir, small_tree, split_file_bytes) in shapes {
            let o = Query { want_spans: true, ..query("e", Mode::Literal) };
            let f = Files { threads: 3, small_tree, split_file_bytes, ..Files::walk(vec![root.join(dir)]) };
            MOST_QUEUED.with(|m| m.set(0));
            let mut n = 0u64;
            let mut take = |_| {
                if n == 0 {
                    std::thread::sleep(std::time::Duration::from_millis(300));
                }
                n += 1;
            };
            let stats = search(&o, &f, Arc::default(), Output::Records(&mut take)).unwrap();
            assert_eq!(n, stats.matches, "{dir}");
            assert_eq!(n, if dir == "one" { 100_000 } else { 600_000 });
            let most = MOST_QUEUED.with(|m| m.get());
            // a sender counts itself before it waits
            assert!(most <= HIT_BATCHES + 1 + f.threads, "{dir} {small_tree:?} {split_file_bytes}: {most} batches waited");
        }
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn a_thread_keeps_no_buffer_the_size_of_a_larger_file() {
        let root = std::env::temp_dir().join(format!("scrutate_thread_buffer_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("big.txt");
        std::fs::write(&path, format!("needle first\n{}needle last\n", "x\n".repeat(150_000))).unwrap();
        let o = query("needle", Mode::Literal);
        let f = Files { threads: 2, ..Files::default() };
        let matcher = build_matcher(&o.pattern).unwrap();
        let (c, stop) = (Counters::default(), no_stop());
        let (tx, rx) = mpsc::sync_channel(1024);
        let mut fw = file_worker(&o);
        for size in [None, Some(std::fs::metadata(&path).unwrap().len())] {
            search_one(
                &mut fw,
                &Run { matcher: &matcher, q: &o, f: &f, c: &c, stop: &stop, tx: &tx, plain: None, labels: &[], raw: None },
                &path,
                Arc::from("big.txt"),
                size,
                false,
            );
        }
        drop(tx);
        let lines: Vec<u64> = rx.into_iter().flatten().map(|r| line(r).line).collect();
        assert_eq!(lines, [1, 150_002, 1, 150_002]);
        assert!(fw.small.capacity() <= source::SMALL_FILE as usize + 1, "{}", fw.small.capacity());
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn only_a_file_of_one_line_is_read_whole_between_probes() {
        let root = std::env::temp_dir().join(format!("scrutate_whole_read_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("a.txt");
        // longer than the 1 MiB pieces `whole` reads
        let line = "x".repeat(3 << 19);
        for threads in [1, 3] {
            let o = query("needle", Mode::Literal);
            let f = Files { threads, ..Files::default() };
            let matcher = build_matcher(&o.pattern).unwrap();
            let (c, stop) = (Counters::default(), no_stop());
            let (tx, _rx) = mpsc::sync_channel(1024);
            let run = Run { matcher: &matcher, q: &o, f: &f, c: &c, stop: &stop, tx: &tx, plain: None, labels: &[], raw: None };
            for (text, whole) in [(format!("{line}\n").repeat(4), false), (format!("{line}\n"), true), (line.clone(), true)] {
                std::fs::write(&path, &text).unwrap();
                let file = std::fs::File::open(&path).unwrap();
                // probes every 64 MiB, so none falls inside this file
                let got = source::split(&run, &file, text.len() as u64, 64 << 20, &Arc::from("a.txt"));
                assert_eq!(matches!(got, source::Outcome::Buffer(_)), whole, "{threads} threads, {} bytes", text.len());
            }
        }
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn a_file_of_one_line_searched_in_two_passes_reports_what_one_buffer_does() {
        #[derive(Clone)]
        struct Shared(Arc<Mutex<Vec<u8>>>);
        impl Write for Shared {
            fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
                self.0.lock().unwrap().extend_from_slice(b);
                Ok(b.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let root = std::env::temp_dir().join(format!("scrutate_one_line_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("a.txt");
        const P: usize = 256 << 10;
        let n = 3 * P + 1000;
        let at = |text: &[u8], put: &[(usize, &[u8])]| {
            let mut b = text.to_vec();
            for (i, s) in put {
                b[*i..*i + s.len()].copy_from_slice(s);
            }
            b
        };
        let x = vec![b'x'; n];
        let lf = |b: Vec<u8>, end: &[u8]| [b, end.to_vec()].concat();
        // (file, whether the two passes apply)
        let cases: Vec<(Vec<u8>, bool)> = vec![
            (at(&x, &[(5000, b"needle")]), true),
            (lf(at(&x, &[(5000, b"needle")]), b"\n"), true),
            (lf(at(&x, &[(5000, b"needle")]), b"\r\n"), true),
            (lf(at(&x, &[(n - 1, b"e")]), b"\r\n"), true),
            (x.clone(), true),
            (lf(x.clone(), b"\n"), true),
            (at(&x, &[(P - 3, b"needle"), (2 * P - 1, b"needle"), (3 * P - 5, b"needle")]), true),
            (at(&x, &[(P - 5, b"needle")]), true),
            (at(&x, &[(P - 1, b"needle")]), true),
            (at(&x, &[(0, b"needle"), (100, b"needle")]), true),
            (at(&x, &[(n - 6, b"needle")]), true),
            (lf(at(&x, &[(n - 6, b"needle")]), b"\n"), true),
            (at(&x, &[(100, b"\0"), (5000, b"needle")]), false),
            (at(&x, &[(5000, b"needle"), (2 * P, b"\0")]), false),
            (at(&x, &[(5000, b"needle"), (n - 1, b"\0")]), false),
            // past the first probe's window and before the second's
            (at(&x, &[(5000, b"needle"), (n / 8 + (64 << 10) + 100, b"\n")]), false),
            (at(&x, &[(5000, b"needle"), (n - 2, b"\n")]), false),
            (at(&x, &[(5000, b"needle"), (7, b"\xFF\xFE"), (P - 1, "\u{1F600}".as_bytes()), (2 * P - 2, "日".as_bytes()), (3 * P - 1, "é".as_bytes())]), true),
            (at(&x, &[(5000, b"needle"), (P - 2, b"\xF0\x9F\x98"), (n - 2, b"\xE6\x97")]), true),
            (lf(at(&x, &[(5000, b"needle"), (n - 1, b"\xC3")]), b"\n"), true),
            (at(&x, &[(0, b"\xEF\xBB\xBF"), (5000, b"needle")]), false),
        ];
        let plain = |with_filename, line_numbers| Query { with_filename, line_numbers, ..Query::default() };
        let given = Files { paths_as_given: true, ..Files::default() };
        let walked = Files::default();
        let pattern = |case, word| Pattern { case, word, ..Pattern::default() };
        let shapes = [
            (plain(true, true), &walked, true),
            (plain(false, false), &walked, true),
            (plain(true, false), &given, true),
            (Query { report: Report::Counts, ..Query::default() }, &walked, true),
            (Query { want_spans: true, ..Query::default() }, &walked, false),
            (Query { invert: true, ..plain(true, true) }, &walked, false),
            (Query { pattern: pattern(Case::Insensitive, false), ..plain(true, true) }, &walked, false),
            (Query { pattern: pattern(Case::Sensitive, true), ..plain(true, true) }, &walked, false),
        ];
        for (k, (text, applies)) in cases.iter().enumerate() {
            std::fs::write(&path, text).unwrap();
            let size = text.len() as u64;
            for (shape, (base, files, shape_applies)) in shapes.iter().enumerate() {
                for (pattern, literal) in [("needle", true), ("e\r", true), ("", false)] {
                    for threads in [1, 3] {
                        let o = Query { pattern: Pattern { text: pattern.into(), mode: Mode::Literal, ..base.pattern.clone() }, ..base.clone() };
                        let f = Files { threads, split_file_bytes: size, ..(*files).clone() };
                        let to_plain = o.report == Report::Lines && !o.want_spans;
                        let matcher = build_matcher(&o.pattern).unwrap();
                        let run = |off: bool| {
                            NO_ONE_LINE.with(|c| c.set(off));
                            ONE_LINE.with(|c| c.set(0));
                            let (c, stop) = (Counters::default(), no_stop());
                            let out = Shared(Arc::new(Mutex::new(Vec::new())));
                            let sink = PlainSink::new(Box::new(out.clone()));
                            let (tx, rx) = mpsc::sync_channel(1024);
                            let r =
                                Run { matcher: &matcher, q: &o, f: &f, c: &c, stop: &stop, tx: &tx, plain: to_plain.then_some(&sink), labels: &[], raw: None };
                            search_one(&mut file_worker(&o), &r, &path, Arc::from("a.txt"), Some(size), f.paths_as_given);
                            drop(tx);
                            sink.flush().unwrap();
                            let hits: Vec<String> = rx.into_iter().flatten().map(|r| format!("{r:?}")).collect();
                            let stats = (c.files_matched.into_inner(), c.matches.into_inner(), c.errors.into_inner());
                            let got = (out.0.lock().unwrap().clone(), hits, stats);
                            (got, ONE_LINE.with(|c| c.get()))
                        };
                        let (two, ran) = run(false);
                        let (one, _) = run(true);
                        let what = format!("case {k}, shape {shape}, pattern {pattern:?}, {threads} threads");
                        assert!(two == one, "{what}");
                        assert_eq!(ran, usize::from(*applies && *shape_applies && literal), "{what}");
                    }
                }
            }
        }
        NO_ONE_LINE.with(|c| c.set(false));
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn an_empty_file_is_read_whole_on_any_thread_count() {
        let root = std::env::temp_dir().join(format!("scrutate_empty_whole_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("a.txt");
        std::fs::write(&path, b"").unwrap();
        let file = std::fs::File::open(&path).unwrap();
        let finder = memchr::memmem::Finder::new(b"abcd");
        for threads in [1, 3] {
            assert_eq!(source::whole(&file, 0, threads), Some(Vec::new()));
            assert_eq!(source::literal_in_pieces(&file, 0, &finder, threads, 4), Some(false));
        }
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn a_literal_across_pieces_is_found_on_any_thread_count() {
        let root = std::env::temp_dir().join(format!("scrutate_pieces_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("a.txt");
        let finder = memchr::memmem::Finder::new(b"abcd");
        for at in 0..=36 {
            let mut text = vec![b'x'; 40];
            text[at..at + 4].copy_from_slice(b"abcd");
            std::fs::write(&path, &text).unwrap();
            let file = std::fs::File::open(&path).unwrap();
            for threads in [1, 2, 5] {
                for piece in [1, 3, 4, 7] {
                    assert_eq!(source::literal_in_pieces(&file, 40, &finder, threads, piece), Some(true), "at {at}, piece {piece}");
                }
            }
            text[at] = b'\n';
            std::fs::write(&path, &text).unwrap();
            assert_eq!(source::literal_in_pieces(&file, 40, &finder, 2, 4), None, "a line break at {at}");
        }
        std::fs::write(&path, b"xxabcd\n").unwrap();
        assert_eq!(source::literal_in_pieces(&std::fs::File::open(&path).unwrap(), 7, &finder, 2, 2), Some(true));
        std::fs::write(&path, b"xxabcd").unwrap();
        // shorter than the size the first pass was told: a read comes back short
        assert_eq!(source::literal_in_pieces(&std::fs::File::open(&path).unwrap(), 7, &finder, 1, 8), None);
        std::fs::write(&path, b"ab\xC3\xA9cd").unwrap();
        let (mut out, file) = (Vec::new(), std::fs::File::open(&path).unwrap());
        assert!(write_lossy_from(&mut out, &file, 6).unwrap().is_ok());
        assert_eq!(out, "ab\u{e9}cd".as_bytes());
        out.clear();
        assert!(write_lossy_from(&mut out, &file, 9).unwrap().is_err(), "a short read");
        assert_eq!(out, "ab\u{e9}cd".as_bytes());
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn text_in_memory_gives_the_records_and_output_of_the_same_bytes_in_a_file() {
        #[derive(Clone)]
        struct Shared(Arc<Mutex<Vec<u8>>>);
        impl Write for Shared {
            fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
                self.0.lock().unwrap().extend_from_slice(b);
                Ok(b.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let root = std::env::temp_dir().join(format!("scrutate_in_memory_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let lines = |n: usize, line: &str| line.repeat(n).into_bytes();
        // `sized(n, ..)`: lines up to exactly n bytes, a needle in the first and the last
        let sized = |n: usize, end: &[u8]| {
            let mut b = lines(n / 20 + 1, "a needle line here\nx\n");
            b.truncate(n - end.len());
            b.extend_from_slice(end);
            b
        };
        let utf16: Vec<u8> = [0xFF, 0xFE].into_iter().chain("one\nneedle two\n".encode_utf16().flat_map(|u| u.to_le_bytes())).collect();
        let small = source::SMALL_FILE as usize;
        let texts: Vec<(&str, Vec<u8>)> = vec![
            ("plain", b"alpha needle\nbeta\nneedle gamma\nbeta needle\n".to_vec()),
            ("empty", Vec::new()),
            ("no line end", b"one\nneedle".to_vec()),
            ("crlf", b"needle a\r\nb\r\nneedle\r\n".to_vec()),
            ("nul early", b"needle\0 x\nneedle\n".to_vec()),
            ("nul late", [lines(10_000, "needle line\n"), b"\0needle\n".to_vec()].concat()),
            ("nul in a split", [lines(30_000, "needle line\n"), b"\0".to_vec(), lines(30_000, "needle\n")].concat()),
            ("utf-8 bom", b"\xEF\xBB\xBFneedle\nbeta\n".to_vec()),
            ("utf-8 bom, large", [b"\xEF\xBB\xBF".to_vec(), lines(30_000, "needle line\n")].concat()),
            ("utf-16 bom", utf16),
            ("invalid utf-8", b"ne\xffedle needle \xfe\n\xC3needle\n".to_vec()),
            ("one long line", [b"needle".to_vec(), vec![b'x'; 300_000]].concat()),
            ("one long line ending", [vec![b'x'; 300_000], b"needle\r\n".to_vec()].concat()),
            ("one long line, no match", vec![b'x'; 300_000]),
            ("small file", sized(small, b"needle\n")),
            ("past small file", sized(small + 1, b"needle\n")),
            ("one-line threshold", [vec![b'y'; (1 << 16) + 1], b"\n".to_vec()].concat()),
            ("mid file", sized(1 << 20, b"needle\n")),
            ("past mid file", sized((1 << 20) + 1, b"needle\n")),
            ("split", sized(400_000, b"needle\n")),
            ("past split", sized(400_001, b"needle\n")),
        ];
        let pat = |text: &str, mode: Mode| Pattern { text: text.into(), mode, ..Pattern::default() };
        let queries: Vec<Query> = vec![
            query("needle", Mode::Literal),
            Query { want_spans: true, text_spans: true, ..query("needle", Mode::Literal) },
            Query { report: Report::Counts, ..query("needle", Mode::Literal) },
            Query { report: Report::Files, ..query("needle", Mode::Literal) },
            Query { before: 1, after: 1, ..query("needle", Mode::Literal) },
            Query { invert: true, ..query("needle", Mode::Literal) },
            Query { invert: true, report: Report::Counts, ..query("needle", Mode::Literal) },
            Query { pattern: Pattern { multiline: true, ..pat("needle\\s+(beta|line)", Mode::Regex) }, ..Query::default() },
            Query { pattern: Pattern { multiline: true, ..pat("needle\\s+(beta|line)", Mode::Regex) }, report: Report::Counts, ..Query::default() },
            Query { pattern: Pattern { case: Case::Insensitive, ..pat("NEE+DLE", Mode::Regex) }, ..Query::default() },
            Query { max_count: Some(1), ..query("needle", Mode::Literal) },
            Query { max_results: Some(3), ..query("needle", Mode::Literal) },
            query("x", Mode::Literal),
        ];
        let path = root.join("a.txt");
        let mut runs = 0;
        for (what, bytes) in &texts {
            std::fs::write(&path, bytes).unwrap();
            for o in &queries {
                for (threads, split_file_bytes) in [(1, 64 << 20), (3, 64 << 20), (3, 400_000)] {
                    for to_plain in [false, true] {
                        if to_plain && o.report != Report::Lines {
                            continue;
                        }
                        let found = |paths: Paths| {
                            let f = Files { paths, threads, split_file_bytes, ..Files::default() };
                            let o = Query { want_bytes: true, ..o.clone() };
                            let written = Shared(Arc::default());
                            let plain = Arc::new(PlainSink::new(Box::new(written.clone())));
                            let mut records = Vec::new();
                            let mut push = |r: Record| records.push(format!("{r:?}"));
                            let out = if to_plain { Output::Plain(Arc::clone(&plain)) } else { Output::Records(&mut push) };
                            let stats = search(&o, &f, Arc::default(), out).unwrap();
                            plain.flush().unwrap();
                            let stats =
                                (stats.files_searched, stats.files_matched, stats.matches, stats.bytes_searched, stats.errors, stats.cancelled, stats.failures);
                            let printed = written.0.lock().unwrap().clone();
                            (records, String::from_utf8_lossy(&printed).into_owned(), stats)
                        };
                        let on_disk = found(Paths::List { root: root.clone(), files: vec!["a.txt".into()] });
                        let in_memory = found(Paths::Memory(vec![("a.txt".into(), bytes.clone())]));
                        let shape = format!(
                            "{what}: {:?} {:?} report {:?}, {threads} threads, split at {split_file_bytes}, plain {to_plain}",
                            o.pattern.text, o.pattern.mode, o.report
                        );
                        assert_eq!(on_disk.2 .0, 1, "{shape}");
                        assert!(on_disk == in_memory, "{shape}\non disk: {on_disk:?}\nin memory: {in_memory:?}");
                        runs += 1;
                    }
                }
            }
        }
        assert!(runs > 1000, "{runs}");
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn texts_not_on_disk_are_searched_in_the_order_given_or_by_name() {
        let texts = vec![("b.txt".to_string(), b"needle b\n".to_vec()), ("a.txt".to_string(), b"needle a\nneedle\n".to_vec())];
        let names = |o: &Query| {
            let mut got = Vec::new();
            let f = Files { paths: Paths::Memory(texts.clone()), ..Files::default() };
            search(o, &f, Arc::default(), Output::Records(&mut |r| got.push(format!("{}:{}", r.path().clone(), line(r).line)))).unwrap();
            got
        };
        assert_eq!(names(&query("needle", Mode::Literal)), ["b.txt:1", "a.txt:1", "a.txt:2"]);
        let sorted = Query { first_in_path_order: true, max_results: Some(2), ..query("needle", Mode::Literal) };
        assert_eq!(names(&sorted), ["a.txt:1", "a.txt:2"]);
    }

    #[test]
    fn a_tree_of_one_file_is_searched_without_a_thread() {
        let root = std::env::temp_dir().join(format!("scrutate_small_threads_{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("a.txt"), "hello\n").unwrap();
        let o = query("hello", Mode::Literal);
        let f = Files { threads: 2, ..Files::walk(vec![root.clone()]) };
        let found = |f: &Files| {
            SMALL_WORKERS.with(|n| n.set(0));
            let mut lines = Vec::new();
            search(&o, f, Arc::default(), Output::Records(&mut |r| lines.push(line(r).text))).unwrap();
            lines.sort();
            (lines, SMALL_WORKERS.with(|n| n.get()))
        };
        assert_eq!(found(&f), (vec!["hello".to_string()], 0));
        std::fs::write(root.join("b.txt"), "hello again\n").unwrap();
        assert_eq!(found(&f), (vec!["hello".to_string(), "hello again".to_string()], 2));
        // a walk cut after the first file still searches it, and the parallel walk the rest
        let cut = Files { small_tree: Some(1), ..f.clone() };
        assert_eq!(found(&cut), (vec!["hello".to_string(), "hello again".to_string()], 0));
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn a_windows_path_is_printed_with_slashes_and_a_verbatim_drive_path_in_its_plain_form() {
        assert_eq!(windows_form(r"C:\Users\x\a.txt"), "C:/Users/x/a.txt");
        assert_eq!(windows_form(r"\\?\C:\Users\x\a.txt"), "C:/Users/x/a.txt");
        assert_eq!(windows_form(r"dir\a.txt"), "dir/a.txt");
        assert_eq!(windows_form(r"\\server\share\a.txt"), "//server/share/a.txt");
        assert_eq!(windows_form(r"\\?\UNC\server\share\a.txt"), "//?/UNC/server/share/a.txt");
    }

    #[test]
    fn write_lossy_equals_from_utf8_lossy() {
        let parts: &[&[u8]] = &[b"a", b"\xC3\xA9", b"\xE6\x97\xA5", b"\xF0\x9F\x98\x80", b"\xFF", b"\xC3", b"\xE6\x97", b"\xF0\x9F", b"\x80", b"\n"];
        let mut state = 0x9E37_79B9_7F4A_7C15u64;
        let mut next = |n: usize| {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            (state % n as u64) as usize
        };
        for _ in 0..20_000 {
            let mut b = Vec::new();
            for _ in 0..next(12) {
                b.extend_from_slice(parts[next(parts.len())]);
            }
            let piece = 1 + next(9);
            let mut out = Vec::new();
            write_lossy(&mut out, &b, piece).unwrap();
            assert_eq!(out, String::from_utf8_lossy(&b).as_bytes(), "{b:?} piece {piece}");
        }
    }

    #[test]
    fn suffix_candidates_find_the_same_lines() {
        let words = [
            "dev_resume(",
            "x_suspend(",
            " _resume(",
            "KÖNIG",
            "königin",
            "pm_RESUME(",
            "rc",
            "\t",
            "ing ",
            "sing\n",
            "12px",
            "é_resume(",
            "abc",
            "_",
            "(",
            "\n",
            "\r\n",
            "\u{212A}önig",
        ];
        let mut state = 0x9E3779B97F4A7C15u64;
        let mut hay = String::new();
        for _ in 0..20000 {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            hay.push_str(words[(state % words.len() as u64) as usize]);
        }
        let lines = |m: &AnyMatcher, invert: bool| {
            let mut v = Vec::new();
            let mut s = SearcherBuilder::new().line_number(true).invert_match(invert).build();
            let AnyMatcher::Regex(m) = m else { unreachable!() };
            s.search_slice(
                m,
                hay.as_bytes(),
                grep_searcher::sinks::Lossy(|n, _| {
                    v.push(n);
                    Ok(true)
                }),
            )
            .unwrap();
            v
        };
        let mut engaged = 0;
        for (pat, case) in [
            (r"\w+_(suspend|resume)\(", Case::Sensitive),
            (r"\w+_resume\(", Case::Insensitive),
            (r"\w+KÖNIG", Case::Insensitive),
            (r"[a-z]+ing\b", Case::Sensitive),
            (r"\d+px", Case::Sensitive),
            (r".*abc", Case::Sensitive),
            (r"\S*_resume\($", Case::Sensitive),
            (r"PM_RESUME", Case::Insensitive),
        ] {
            let o = Pattern { text: pat.to_string(), case, ..Pattern::default() };
            let fast = build_matcher(&o).unwrap();
            let AnyMatcher::Regex(ref f) = fast else { unreachable!() };
            engaged += f.suffixes.is_some() as usize;
            let slow = AnyMatcher::Regex(LineRegex::plain(f.inner.clone()));
            for invert in [false, true] {
                let (a, b) = (lines(&fast, invert), lines(&slow, invert));
                assert_eq!(a, b, "{pat} {case:?} invert={invert}");
                assert!(invert || !a.is_empty(), "{pat}: no matches, the test proves nothing");
            }
        }
        // the rest have a short suffix, a literal prefix, or too many case variants (s folds to ſ too)
        assert_eq!(engaged, 5);
        let o = Pattern { text: "PM_RESUME".into(), ..Pattern::default() };
        let AnyMatcher::Regex(m) = build_matcher(&o).unwrap() else { unreachable!() };
        assert!(m.suffixes.is_none(), "a literal prefix is the engine's job");
    }

    #[test]
    fn line_start_candidates_find_the_same_lines() {
        let words = ["a", "aa", "aaa", "b", "!", "\n", "\r\n", "#include <x>", "x", "A", "é", "É", " ", "\t", "ab", "\n\n", "\nab"];
        let mut state = 0x9E3779B97F4A7C15u64;
        let mut hay = String::new();
        for _ in 0..20000 {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            hay.push_str(words[(state % words.len() as u64) as usize]);
        }
        let lines = |m: &AnyMatcher, invert: bool| {
            let mut v = Vec::new();
            let mut s = SearcherBuilder::new().line_number(true).invert_match(invert).build();
            let AnyMatcher::Regex(m) = m else { unreachable!() };
            s.search_slice(
                m,
                hay.as_bytes(),
                grep_searcher::sinks::Lossy(|n, _| {
                    v.push(n);
                    Ok(true)
                }),
            )
            .unwrap();
            v
        };
        let mut engaged = 0;
        for (pat, case) in [
            (r"^(a|aa)+$", Case::Sensitive),
            (r"^a", Case::Sensitive),
            (r"^#include", Case::Sensitive),
            (r"^(?:a|b)+!", Case::Insensitive),
            (r"^é", Case::Insensitive),
            (r"^ab?\s*$", Case::Sensitive),
            (r"^a$|^b$", Case::Sensitive),
            (r"^$", Case::Sensitive),
            (r"^\w", Case::Sensitive),
            (r"^a|b", Case::Sensitive),
            (r"^a\z", Case::Sensitive),
            (r"^a\s*", Case::Sensitive),
            (r"^(?:a|ab)(?:\n|b)", Case::Sensitive),
            (r"^a[^x]", Case::Sensitive),
        ] {
            let o = Pattern { text: pat.to_string(), case, ..Pattern::default() };
            let fast = build_matcher(&o).unwrap();
            let AnyMatcher::Regex(ref f) = fast else { unreachable!() };
            engaged += f.line_start.is_some() as usize;
            let slow = AnyMatcher::Regex(LineRegex::plain(f.inner.clone()));
            for invert in [false, true] {
                let (a, b) = (lines(&fast, invert), lines(&slow, invert));
                assert_eq!(a, b, "{pat} {case:?} invert={invert}");
                assert!(invert || !a.is_empty(), "{pat}: no matches, the test proves nothing");
            }
            for line in hay.split('\n').take(3000) {
                assert_eq!(spans_in(&fast, line.as_bytes()), spans_in(&slow, line.as_bytes()), "{pat} on {line:?}");
            }
            assert_eq!(spans_in(&fast, hay.as_bytes()), spans_in(&slow, hay.as_bytes()), "{pat} on the whole text");
            // every short text over a small alphabet, from every offset
            let (AnyMatcher::Regex(fm), AnyMatcher::Regex(sm)) = (&fast, &slow) else { unreachable!() };
            let alphabet: [&[u8]; 5] = [b"a", b"b", b"\n", b"!", "é".as_bytes()];
            let mut texts: Vec<Vec<u8>> = vec![Vec::new()];
            for _ in 0..4 {
                let more: Vec<Vec<u8>> = texts.iter().flat_map(|t| alphabet.iter().map(move |c| [t.as_slice(), c].concat())).collect();
                texts.extend(more);
            }
            for t in &texts {
                for at in 0..=t.len() {
                    assert_eq!(fm.find_at(t, at).unwrap(), sm.find_at(t, at).unwrap(), "{pat} find_at {t:?} {at}");
                    assert_eq!(fm.shortest_match_at(t, at).unwrap().is_some(), sm.shortest_match_at(t, at).unwrap().is_some(), "{pat} {t:?} {at}");
                }
            }
        }
        // `^$`, `^\w` (no finite prefix literals), `^a|b` (not anchored), `^a\z` and a line break in
        // the prefix keep the plain path
        assert_eq!(engaged, 9);
    }

    fn fuzzy_find(pat: &str, k: u8, hay: &str) -> Option<(usize, usize)> {
        let m = FuzzyMatcher::new(pat, k, false).unwrap();
        m.find_at(hay.as_bytes(), 0).unwrap().map(|m| (m.start(), m.end()))
    }


    fn naive_first_end(pat: &[u8], hay: &[u8], k: usize) -> Option<(usize, usize)> {
        let m = pat.len();
        let mut col: Vec<usize> = (0..=m).collect();
        for (i, &c) in hay.iter().enumerate() {
            let mut next = vec![0usize; m + 1];
            for j in 1..=m {
                next[j] = (next[j - 1] + 1).min(col[j] + 1).min(col[j - 1] + usize::from(pat[j - 1] != c));
            }
            col = next;
            if col[m] <= k {
                return Some((i + 1, col[m]));
            }
        }
        None
    }

    #[test]
    fn fuzzy_blocks_agree_with_the_dynamic_programme() {
        let mut state = 0x2545F4914F6CDD1Du64;
        let mut next = |n: u64| {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            state % n
        };
        for round in 0..400 {
            let m = 1 + next(300) as usize;
            let pat: Vec<u8> = (0..m).map(|_| b"abc"[next(3) as usize]).collect();
            // text: the pattern with a few edits, inside noise, so matches at small distances exist
            let mut hay: Vec<u8> = (0..next(200)).map(|_| b"abcd"[next(4) as usize]).collect();
            let mut copy = pat.clone();
            for _ in 0..next(6) {
                let at = next(copy.len() as u64) as usize;
                match next(3) {
                    0 => copy[at] = b'd',
                    1 => drop(copy.remove(at)),
                    _ => copy.insert(at, b'a'),
                }
                if copy.is_empty() {
                    copy.push(b'b');
                }
            }
            hay.extend_from_slice(&copy);
            hay.extend((0..next(50)).map(|_| b"abcd"[next(4) as usize]));
            let k = (next(8) as usize).min(m - 1);
            let f = FuzzyMatcher::new(std::str::from_utf8(&pat).unwrap(), k as u8, false).unwrap();
            assert_eq!(f.first_end(&hay, 0), naive_first_end(&pat, &hay, k), "round {round}: m={m} k={k}");
            if m <= 128 {
                // the block path on short patterns too, against the single-word one
                let b = Blocks::new(&fuzzy_classes(std::str::from_utf8(&pat).unwrap(), false));
                let (mut pv, mut mv) = b.start();
                let mut score = m as isize;
                let mut got = None;
                for i in 0..hay.len() {
                    score += b.step(&mut pv, &mut mv, b.eq_at(&hay, i).0);
                    if score <= k as isize {
                        got = Some((i + 1, score as usize));
                        break;
                    }
                }
                assert_eq!(got, naive_first_end(&pat, &hay, k), "blocks, round {round}: m={m} k={k}");
            }
        }
        assert!(FuzzyMatcher::new(&"a".repeat(FUZZY_MAX + 1), 1, false).is_err());
    }

    #[test]
    fn fuzzy_exact_and_edits() {
        assert_eq!(fuzzy_find("token", 0, "the token here"), Some((4, 9)));
        assert_eq!(fuzzy_find("token", 1, "a tokne b"), Some((2, 6))); // "tokn" is one deletion away
        assert_eq!(fuzzy_find("token", 1, "a tkoen b"), None); // a transposition is two edits
        assert_eq!(fuzzy_find("token", 2, "a tkoen b"), Some((2, 7)));
        assert_eq!(fuzzy_find("token", 1, "a tokn b"), Some((2, 6))); // one deletion
        assert_eq!(fuzzy_find("token", 1, "a tokken b"), Some((2, 8))); // one insertion
        assert_eq!(fuzzy_find("token", 1, "a tomen b"), Some((2, 7))); // one substitution
        assert_eq!(fuzzy_find("token", 0, "nothing"), None);
        assert_eq!(fuzzy_find("token", 1, "tok\nen"), None); // never across lines
    }


    fn naive_first_end_chars(classes: &[Vec<char>], hay: &[u8], k: usize) -> Option<(usize, usize)> {
        let m = classes.len();
        let mut col: Vec<usize> = (0..=m).collect();
        let mut i = 0;
        while i < hay.len() {
            let (c, n) = if hay[i] < 0x80 { (Some(hay[i] as char), 1) } else { wide_char(hay, i) };
            i += n;
            if c == Some('\n') {
                col = (0..=m).collect();
                continue;
            }
            let mut next = vec![0usize; m + 1];
            for j in 1..=m {
                let same = c.is_some_and(|c| classes[j - 1].contains(&c));
                next[j] = (next[j - 1] + 1).min(col[j] + 1).min(col[j - 1] + usize::from(!same));
            }
            col = next;
            if col[m] <= k {
                return Some((i, col[m]));
            }
        }
        None
    }

    #[test]
    fn fuzzy_edits_are_characters_and_case_folds_as_in_the_regex_engine() {
        assert_eq!(fuzzy_find("naïve", 1, "a naive b"), Some((2, 7)));
        assert_eq!(fuzzy_find("naive", 1, "a naïve b"), Some((2, 8)));
        assert_eq!(fuzzy_find("日本語", 1, "日本誤のテキスト"), Some((0, 6)));
        assert_eq!(fuzzy_find("naive", 1, "na\u{0}ve"), Some((0, 5)));
        let m = FuzzyMatcher::new("naive", 1, false).unwrap();
        assert_eq!(m.find_at(b"x na\xffve", 0).unwrap().map(|s| (s.start(), s.end())), Some((2, 7)), "invalid UTF-8 is one unit per byte");
        assert_eq!(m.find_at(b"\xff\xfe\xc3", 0).unwrap(), None);
        for (pat, hay) in [("ÉTÉ", "été"), ("été", "ÉTÉ"), ("kelvin", "\u{212A}ELVIN"), ("ß", "ẞ"), ("Σ", "ς")] {
            let m = FuzzyMatcher::new(pat, 0, true).unwrap();
            assert!(m.find_at(hay.as_bytes(), 0).unwrap().is_some(), "{pat} in {hay}");
            assert!(regex::RegexBuilder::new(pat).case_insensitive(true).build().unwrap().is_match(hay), "the regex engine agrees on {pat}");
        }
        let mut state = 0x9E37_79B9_7F4A_7C15u64;
        let mut next = |n: u64| {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            state % n
        };
        let alpha = ["a", "b", "é", "É", "ü", "日", "k", "\u{212A}", "\u{ff}"];
        for round in 0..600 {
            let fold = next(2) == 0;
            let long = next(4) == 0;
            let m = if long { 129 + next(60) as usize } else { 1 + next(9) as usize };
            let pat: String = (0..m).map(|_| alpha[next(8) as usize]).collect();
            let mut hay: Vec<u8> = Vec::new();
            for _ in 0..next(if long { 400 } else { 40 }) {
                match next(12) {
                    0 => hay.push(0xff),
                    1 => hay.push(b'\n'),
                    _ => hay.extend_from_slice(alpha[next(alpha.len() as u64) as usize].as_bytes()),
                }
            }
            if next(2) == 0 {
                let at = (next(hay.len() as u64 + 1) as usize).min(hay.len());
                hay.splice(at..at, pat.bytes().take(pat.len() - 1));
            }
            let k = (next(4) as usize).min(m - 1);
            let f = FuzzyMatcher::new(&pat, k as u8, fold).unwrap();
            let want = naive_first_end_chars(&fuzzy_classes(&pat, fold), &hay, k);
            assert_eq!(f.first_end(&hay, 0), want, "round {round}: {pat:?} k={k} fold={fold} in {hay:?}");
            let found = f.find_at(&hay, 0).unwrap();
            assert_eq!(found.map(|s| s.end()), want.map(|w| w.0), "round {round}: the prefilter keeps every match");
            if let Some(s) = found {
                let mut at = 0;
                while at < s.start() {
                    at += unit_len(&hay, at);
                }
                assert_eq!(at, s.start(), "round {round}: a match starts on a character: {s:?} in {hay:?}");
            }
        }
    }

    #[test]
    fn fuzzy_case_fold() {
        let m = FuzzyMatcher::new("Token", 0, true).unwrap();
        assert!(m.find_at(b"a TOKEN b", 0).unwrap().is_some());
        let m = FuzzyMatcher::new("Token", 0, false).unwrap();
        assert!(m.find_at(b"a TOKEN b", 0).unwrap().is_none());
    }

    #[test]
    fn smart_case_counts_only_letters_that_stand_for_themselves() {
        for (pattern, regex, upper) in [
            ("foo", true, false),
            ("Foo", true, true),
            (r"\Sfoo", true, false),
            (r"\W+\Bfoo\d", true, false),
            (r"\pLfoo\p{Lu}x", true, false),
            (r"\SFoo", true, true),
            (r"foo\\Bar", true, true),
            (r"\Sfoo", false, true),
            (r"\x41bc", true, true),
            (r"\x61bc", true, false),
            (r"\x{41}bc", true, true),
            (r"\x{1F600}bc", true, false),
            (r"\u0041bc", true, true),
            (r"\u00e9bc", true, false),
            (r"\U00000041bc", true, true),
            (r"\xzz", true, false),
        ] {
            assert_eq!(uppercase_literal(pattern, regex), upper, "{pattern:?} regex={regex}");
        }
        let o = Pattern { text: "fooz".into(), mode: Mode::Fuzzy { max_edits: 1 }, word: true, ..Pattern::default() };
        assert!(build_matcher(&o).err().unwrap().to_string().contains("-w) is not available with --fuzzy"));
        let o = Pattern { text: "fooz".into(), mode: Mode::FuzzyRegex { max_edits: 1 }, multiline: true, ..Pattern::default() };
        assert!(build_matcher(&o).err().unwrap().to_string().contains("-U) is not available with --fuzzy"));
    }

    #[test]
    fn identifier_parts_cover_digits_and_acronyms() {
        let p = |s: &str| ident_parts(s);
        assert_eq!(p("makeWidget3"), vec!["make", "Widget", "3"]);
        assert_eq!(p("make_widget_3"), vec!["make", "widget", "3"]);
        assert_eq!(p("XMLHttpRequest2"), vec!["XML", "Http", "Request", "2"]);
        assert_eq!(p("HTTP2Server"), vec!["HTTP", "2", "Server"]);
        assert_eq!(p("MAKE_WIDGET_3"), vec!["MAKE", "WIDGET", "3"]);
        let re = regex::Regex::new(&identifier_regex("makeWidget3")).unwrap();
        assert!(re.is_match("x = make_widget_3(1)") && re.is_match("MAKE_WIDGET_3") && re.is_match("makeWidget3"));
        assert!(!re.is_match("make_widget_30") && !re.is_match("make_widget_3x"));
    }

    #[test]
    fn identifier_regex_matches_every_style() {
        let re = regex::Regex::new(&identifier_regex("refreshToken")).unwrap();
        for s in ["refresh_token", "refreshToken", "RefreshToken", "REFRESH_TOKEN", "refresh-token"] {
            assert!(re.is_match(&format!("x = {s}(1)")), "{s}");
        }
        assert!(!re.is_match("refreshTokens"));
        assert!(!re.is_match("refresh tokens"));
    }

    #[test]
    fn joined_patterns_keep_each_mode_meaning() {
        let ps = |v: &[&str]| v.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        assert_eq!(join_patterns(&ps(&["a.b"]), Mode::Pcre2, true).unwrap(), (r"a\.b".to_string(), Mode::Pcre2));
        assert_eq!(join_patterns(&ps(&["a.b"]), Mode::Literal, false).unwrap(), ("a.b".to_string(), Mode::Literal));
        assert_eq!(join_patterns(&ps(&["a.b", "c"]), Mode::Literal, true).unwrap(), (r"(?:a\.b)|(?:c)".to_string(), Mode::Regex));
        assert_eq!(join_patterns(&ps(&["a.b", "c"]), Mode::Pcre2, true).unwrap().1, Mode::Pcre2);
        let (p, m) = join_patterns(&ps(&["fooBar", "x"]), Mode::Identifier, false).unwrap();
        assert_eq!((p.as_str(), m), (r"(?:(?i)\bfoo[_\-]?Bar\b)|(?:(?i)\bx\b)", Mode::Regex));
        let e = join_patterns(&ps(&["a", "b"]), Mode::Fuzzy { max_edits: 1 }, false).unwrap_err();
        assert_eq!(e.to_string(), "--fuzzy takes one pattern");
        let zip = Files { search_zip: true, hidden: true, ..Files::default() };
        assert!(zip.check_indexable().unwrap_err().to_string().starts_with("--index does not cover archive members"));
        assert!(Files { max_depth: Some(1), ..Files::default() }.check_indexable().unwrap_err().to_string().starts_with("--index searches the files"));
        assert!(Files::default().check_indexable().is_ok());
    }

    #[test]
    fn held_output_leaves_in_fewer_writes_and_never_waits_on_a_quiet_sink() {
        struct Writes(Arc<Mutex<Vec<Vec<u8>>>>);
        impl Write for Writes {
            fn write(&mut self, b: &[u8]) -> std::io::Result<usize> {
                self.0.lock().unwrap().push(b.to_vec());
                Ok(b.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let writes = Arc::new(Mutex::new(Vec::new()));
        let sink = PlainSink::new(Box::new(Writes(Arc::clone(&writes))));
        let stop = no_stop();
        let written = || writes.lock().unwrap().concat();
        let quiet = || std::thread::sleep(std::time::Duration::from_millis(5));
        let mut all = Vec::new();
        for i in 0..1000 {
            let line = format!("file{i}:1:text\n");
            sink.write(line.as_bytes(), false, &stop);
            all.extend_from_slice(line.as_bytes());
        }
        assert!(writes.lock().unwrap().len() < 500, "a burst leaves in few writes");
        quiet();
        sink.tick(&stop);
        assert_eq!(written(), all, "held output leaves once it has waited");
        quiet();
        sink.write(b"late:1:text\n", false, &stop);
        all.extend_from_slice(b"late:1:text\n");
        assert_eq!(written(), all, "output after a quiet spell leaves at once");
        sink.write(b"last:1:text\n", false, &stop);
        sink.write_line(b"", b"long:1:", Text::Here(b"x\xFFy"), false, &stop).unwrap();
        sink.flush().unwrap();
        all.extend_from_slice("last:1:text\nlong:1:x\u{FFFD}y\n".as_bytes());
        assert_eq!(written(), all);
        assert!(!sink.broken.load(Ordering::Relaxed) && !stop.is_set());
    }

    #[test]
    fn a_cold_tree_earns_threads_by_its_slow_reads() {
        let o = Files::default();
        let most = cold_threads().saturating_sub(default_threads(&o));
        let reads = |all: u64, slow: u64| {
            let c = Counters::default();
            c.small_reads.store(all, Ordering::Relaxed);
            c.slow_reads.store(slow, Ordering::Relaxed);
            cold_extra(&o, &c)
        };
        assert_eq!(reads(15, 15), 0, "too few reads to tell");
        assert_eq!(reads(1000, 700), 0, "mostly fast reads are a warm tree");
        assert_eq!(reads(16, 16), 1.min(most));
        assert_eq!(reads(100, 80), 5.min(most));
        assert_eq!(reads(1_000_000, 1_000_000), most);
        let c = Counters::default();
        c.small_reads.store(100, Ordering::Relaxed);
        c.slow_reads.store(100, Ordering::Relaxed);
        assert_eq!(cold_extra(&Files { threads: 4, ..Files::default() }, &c), 0, "-j is kept");
    }

    proptest::proptest! {
        #![proptest_config(proptest::prelude::ProptestConfig::with_cases(4000))]
        #[test]
        fn a_case_insensitive_literal_finds_every_line_the_regex_matches(
            needle in proptest::collection::vec(0usize..FOLD_CHARS.len(), 1..8),
            long in proptest::option::of((0usize..FOLD_CHARS.len(), 14usize..40)),
            pieces in proptest::collection::vec((0u8..5, 0usize..80, proptest::collection::vec(0usize..64, 8)), 0..8),
            regex in proptest::prelude::any::<bool>(),
            word in proptest::prelude::any::<bool>(),
        ) {
            let chars: Vec<char> = match long {
                Some((c, n)) => vec![FOLD_CHARS[c]; n],
                None => needle.iter().map(|&i| FOLD_CHARS[i]).collect(),
            };
            let pattern: String = chars.iter().collect();
            let mut hay = Vec::new();
            for (kind, pad, picks) in &pieces {
                // padding puts the piece on either side of 16, 32 and 64 byte boundaries
                hay.extend(std::iter::repeat_n(b'x', *pad));
                match kind {
                    0 | 1 => {
                        let miss = *kind == 1;
                        for (n, &c) in chars.iter().enumerate() {
                            let forms = fold_class(c);
                            let c = if miss && n == picks[0] % chars.len() { FOLD_CHARS[picks[1] % FOLD_CHARS.len()] } else { forms[picks[n % 8] % forms.len()] };
                            hay.extend(c.to_string().as_bytes());
                        }
                    }
                    2 => hay.extend(picks.iter().map(|&p| [b'\n', b' ', 0xFF, 0xC3, b'A', b'a', b'_', b'0'][p % 8])),
                    // a run of the first character one short of the needle, as long, or one longer
                    4 => {
                        let forms = fold_class(chars[0]);
                        for n in 0..chars.len() + picks[0] % 3 - 1 {
                            hay.extend(forms[picks[n % 8] % forms.len()].to_string().as_bytes());
                        }
                    }
                    _ => hay.push(b'\n'),
                }
            }
            let mode = if regex { Mode::Regex } else { Mode::Literal };
            let pattern = if regex { regex::escape(&pattern) } else { pattern };
            let o = Pattern { text: pattern, mode, case: Case::Insensitive, word, ..Pattern::default() };
            let AnyMatcher::Regex(m) = build_matcher(&o).unwrap() else { panic!("not a regex matcher") };
            let mut start = 0;
            for line in hay.split(|&b| b == b'\n') {
                let end = start + line.len();
                if m.inner.is_match(line).unwrap() {
                    let got = m.find_candidate_line(&hay[start..]).unwrap();
                    let at = match got {
                        Some(grep_matcher::LineMatchKind::Candidate(i) | grep_matcher::LineMatchKind::Confirmed(i)) => start + i,
                        None => usize::MAX,
                    };
                    proptest::prop_assert!(at <= end, "{:?} in {:?}: line {start}..{end}, candidate {at}", o.text, String::from_utf8_lossy(&hay));
                }
                start = end + 1;
            }
        }
    }

    #[test]
    fn a_case_insensitive_literal_costs_no_more_on_longer_near_misses() {
        // lines one byte shorter than the needle: almost every position fits the two scanned bytes
        let time = |n: usize| {
            let hay = format!("{}\n", "=".repeat(n - 1)).repeat((256 << 10) / n);
            let o = Pattern { text: "=".repeat(n), mode: Mode::Literal, case: Case::Insensitive, ..Pattern::default() };
            let AnyMatcher::Regex(m) = build_matcher(&o).unwrap() else { panic!("not a regex matcher") };
            assert!(m.fold.is_some());
            let search = || {
                let t = Instant::now();
                let sink = grep_searcher::sinks::Lossy(|_, _| -> std::io::Result<bool> { panic!("no line matches") });
                SearcherBuilder::new().build().search_slice(&m, hay.as_bytes(), sink).unwrap();
                t.elapsed()
            };
            (0..3).map(|_| search()).min().unwrap()
        };
        let (short, long) = (time(32), time(2048));
        assert!(long < short * 4, "needle of 32: {short:?}, of 2048: {long:?}");
    }

    const FOLD_CHARS: &[char] = &[
        'a', 'b', 'c', 'e', 'P', 'm', 'R', 'z', 'k', 'K', 's', 'S', '_', '0', '-', '.', 'ß', 'ẞ', 'σ', 'Σ', 'ς', 'İ', 'ı', 'i', 'I', 'é', 'Ö', 'ö', '\u{212A}',
        '\u{17F}', '\u{301}', ' ',
    ];

    #[test]
    fn a_case_insensitive_literal_has_its_own_finder_only_when_it_can() {
        let fold = |pattern: &str, mode, case| match build_matcher(&Pattern { text: pattern.into(), mode, case, ..Pattern::default() }).unwrap() {
            AnyMatcher::Regex(m) => m.fold.is_some(),
            _ => false,
        };
        assert!(fold("pm_resume", Mode::Literal, Case::Insensitive));
        assert!(fold("KÖNIG", Mode::Regex, Case::Insensitive));
        assert!(fold("error", Mode::Literal, Case::Smart));
        assert!(!fold("error", Mode::Literal, Case::Sensitive));
        assert!(!fold("[A-Z]+_RESUME", Mode::Regex, Case::Insensitive));
        assert!(!fold("ks", Mode::Literal, Case::Insensitive));
        assert!(!fold("Error", Mode::Literal, Case::Smart));
    }
}
