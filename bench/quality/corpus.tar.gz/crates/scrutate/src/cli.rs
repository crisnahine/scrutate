



use std::io::{BufRead, IsTerminal, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use anyhow::{Context, Result};
use clap::{CommandFactory, Parser, Subcommand, ValueEnum};
use termcolor::{Color, ColorChoice, ColorSpec, WriteColor};

use crate::fmt::{fmt_hits, hits_json};
use crate::instant::{self, Case, Files, Mode, Output, Paths, Pattern, Query, Record, Report};
use crate::ops::Op;
use crate::stores::Writer;
use crate::text::query_words;

pub use crate::ops::SCHEMA;




mod interrupt {
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::sync::{Arc, OnceLock};

    static FLAG: OnceLock<Arc<AtomicBool>> = OnceLock::new();

    // async-signal-safe: an atomic load of the cell and an atomic store
    fn fire() {
        if let Some(f) = FLAG.get() {
            f.store(true, Ordering::Relaxed);
        }
    }

    #[cfg(unix)]
    pub fn install(flag: Arc<AtomicBool>) {
        extern "C" fn handler(_: i32) {
            fire()
        }
        extern "C" {
            fn signal(sig: i32, handler: extern "C" fn(i32)) -> usize;
        }
        const SIGINT: i32 = 2;
        if FLAG.set(flag).is_ok() {
            unsafe {
                signal(SIGINT, handler);
            }
        }
    }

    #[cfg(windows)]
    pub fn install(flag: Arc<AtomicBool>) {
        unsafe extern "system" fn handler(_: u32) -> i32 {
            fire();
            1
        }
        #[link(name = "kernel32")]
        extern "system" {
            fn SetConsoleCtrlHandler(handler: Option<unsafe extern "system" fn(u32) -> i32>, add: i32) -> i32;
        }
        if FLAG.set(flag).is_ok() {
            unsafe {
                SetConsoleCtrlHandler(Some(handler), 1);
            }
        }
    }

    #[cfg(not(any(unix, windows)))]
    pub fn install(_flag: Arc<AtomicBool>) {}
}

#[derive(Parser)]
#[command(name = "scrutate", version, about = "Code search: instant grep-class search plus an indexed, ranked code-intelligence engine", long_about = None)]
pub struct Cli {

    #[arg(long, default_value = ".", global = true, env = "SCRUTATE_ROOT")]
    pub root: PathBuf,

    #[arg(long, global = true)]
    pub no_color: bool,

    #[arg(long, global = true, value_name = "BYTES", env = "SCRUTATE_MAX_BYTES")]
    pub max_bytes: Option<usize>,

    #[arg(long, global = true, value_name = "N", default_value_t = 0)]
    pub offset: usize,
    #[command(subcommand)]
    pub cmd: Cmd,
}

#[derive(Clone, Copy, ValueEnum, Debug)]
pub enum Shell {
    Bash,
    Zsh,
    Fish,
    Powershell,
    Elvish,
}


#[derive(clap::Args)]
#[cfg_attr(test, derive(Debug, PartialEq))]
pub struct GrepArgs {


    #[arg(required_unless_present_any = ["regexp", "type_list"])]
    pub pattern: Option<std::ffi::OsString>,


    pub paths: Vec<PathBuf>,

    #[arg(short = 'e', long = "regexp", value_name = "PATTERN", allow_hyphen_values = true)]
    pub regexp: Vec<String>,


    #[arg(long)]
    pub index: bool,


    #[arg(long, requires = "index")]
    pub update: bool,

    #[arg(short = 'F', long)]
    pub fixed_strings: bool,

    #[arg(long)]
    pub ident: bool,

    #[arg(long, value_name = "N", num_args = 0..=1, require_equals = true, default_missing_value = "1")]
    pub fuzzy: Option<u8>,


    #[arg(long, value_name = "N", num_args = 0..=1, require_equals = true, default_missing_value = "1")]
    pub fuzzy_regex: Option<u8>,

    #[arg(short = 'P', long)]
    pub pcre2: bool,

    #[arg(short = 'z', long)]
    pub search_zip: bool,

    #[arg(short = 'i', long, overrides_with = "smart_case")]
    pub ignore_case: bool,


    #[arg(short = 'S', long, overrides_with = "ignore_case")]
    pub smart_case: bool,

    #[arg(short = 'w', long)]
    pub word: bool,

    #[arg(short = 'U', long)]
    pub multiline: bool,

    #[arg(short = 'v', long)]
    pub invert_match: bool,

    #[arg(short = 'l', long)]
    pub files_with_matches: bool,

    #[arg(short = 'c', long)]
    pub count: bool,


    #[arg(short = 'H', long, overrides_with = "no_filename")]
    pub with_filename: bool,


    #[arg(short = 'I', long, overrides_with = "with_filename")]
    pub no_filename: bool,

    #[arg(short = 'n', long, overrides_with = "no_line_number")]
    pub line_number: bool,

    #[arg(short = 'N', long, overrides_with = "line_number")]
    pub no_line_number: bool,

    #[arg(short = 'A', long, default_value_t = 0)]
    pub after: usize,

    #[arg(short = 'B', long, default_value_t = 0)]
    pub before: usize,

    #[arg(short = 'C', long)]
    pub context: Option<usize>,

    #[arg(short = 'm', long)]
    pub max_count: Option<u64>,

    #[arg(long)]
    pub max_results: Option<u64>,


    #[arg(short = 'g', long = "glob")]
    pub globs: Vec<String>,

    #[arg(short = 't', long = "type", env = "SCRUTATE_GREP_TYPES", value_delimiter = ',')]
    pub types: Vec<String>,

    #[arg(long)]
    pub type_list: bool,

    #[arg(long, env = "SCRUTATE_GREP_HIDDEN", value_parser = clap::builder::FalseyValueParser::new())]
    pub hidden: bool,

    #[arg(long, env = "SCRUTATE_GREP_NO_IGNORE", value_parser = clap::builder::FalseyValueParser::new())]
    pub no_ignore: bool,

    #[arg(short = 'L', long, env = "SCRUTATE_GREP_FOLLOW", value_parser = clap::builder::FalseyValueParser::new())]
    pub follow: bool,

    #[arg(long, value_name = "SIZE", env = "SCRUTATE_GREP_MAX_FILESIZE")]
    pub max_filesize: Option<String>,

    #[arg(long, env = "SCRUTATE_GREP_MAX_DEPTH")]
    pub max_depth: Option<usize>,

    #[arg(short = 'j', long, default_value_t = 0, env = "SCRUTATE_THREADS")]
    pub threads: usize,


    #[arg(long)]
    pub sort: bool,

    #[arg(long)]
    pub json: bool,

    #[arg(long)]
    pub stats: bool,

    #[arg(long)]
    pub symbols: bool,
}



#[derive(Parser)]
#[command(name = "scrutate", version, about = "Code search: instant grep-class search plus an indexed, ranked code-intelligence engine", long_about = None)]
struct GrepCli {

    #[arg(long, default_value = ".", global = true, env = "SCRUTATE_ROOT")]
    root: PathBuf,

    #[arg(long, global = true)]
    no_color: bool,
    #[command(subcommand)]
    cmd: GrepCmd,
}

#[derive(Subcommand)]
enum GrepCmd {

    #[command(alias = "g", version)]
    Grep(GrepArgs),
}




const GREP_ENV: [&str; 8] = [
    "SCRUTATE_ROOT",
    "SCRUTATE_GREP_TYPES",
    "SCRUTATE_GREP_HIDDEN",
    "SCRUTATE_GREP_NO_IGNORE",
    "SCRUTATE_GREP_FOLLOW",
    "SCRUTATE_GREP_MAX_FILESIZE",
    "SCRUTATE_GREP_MAX_DEPTH",
    "SCRUTATE_THREADS",
];






fn plain_grep(args: &[String]) -> Option<(bool, GrepArgs)> {
    const BOOLS: [(char, &str); 24] = [
        ('F', "fixed-strings"),
        ('\0', "ident"),
        ('P', "pcre2"),
        ('z', "search-zip"),
        ('i', "ignore-case"),
        ('S', "smart-case"),
        ('w', "word"),
        ('U', "multiline"),
        ('v', "invert-match"),
        ('l', "files-with-matches"),
        ('c', "count"),
        ('H', "with-filename"),
        ('I', "no-filename"),
        ('n', "line-number"),
        ('N', "no-line-number"),
        ('L', "follow"),
        ('\0', "hidden"),
        ('\0', "no-ignore"),
        ('\0', "index"),
        ('\0', "sort"),
        ('\0', "json"),
        ('\0', "stats"),
        ('\0', "symbols"),
        ('\0', "no-color"),
    ];
    const VALUES: [(char, &str); 3] = [('e', "regexp"), ('g', "glob"), ('j', "threads")];
    let mut g = GrepArgs {
        pattern: None,
        paths: Vec::new(),
        regexp: Vec::new(),
        index: false,
        update: false,
        fixed_strings: false,
        ident: false,
        fuzzy: None,
        fuzzy_regex: None,
        pcre2: false,
        search_zip: false,
        ignore_case: false,
        smart_case: false,
        word: false,
        multiline: false,
        invert_match: false,
        files_with_matches: false,
        count: false,
        with_filename: false,
        no_filename: false,
        line_number: false,
        no_line_number: false,
        after: 0,
        before: 0,
        context: None,
        max_count: None,
        max_results: None,
        globs: Vec::new(),
        types: Vec::new(),
        type_list: false,
        hidden: false,
        no_ignore: false,
        follow: false,
        max_filesize: None,
        max_depth: None,
        threads: 0,
        sort: false,
        json: false,
        stats: false,
        symbols: false,
    };
    let mut no_color = false;
    let mut seen = 0u32;
    let mut threads_seen = false;
    let mut positional: Vec<&String> = Vec::new();
    // what clap takes for a flag's value given as the next argument
    fn value_of(v: Option<&String>) -> Option<&String> {
        v.filter(|v| !v.starts_with('-'))
    }
    let mut set = |i: usize, g: &mut GrepArgs| -> Option<()> {
        if seen & 1 << i != 0 {
            return None;
        }
        seen |= 1 << i;
        // of -i and -S, -H and -I, -n and -N the later wins
        match i {
            0 => g.fixed_strings = true,
            1 => g.ident = true,
            2 => g.pcre2 = true,
            3 => g.search_zip = true,
            4 => (g.ignore_case, g.smart_case) = (true, false),
            5 => (g.smart_case, g.ignore_case) = (true, false),
            6 => g.word = true,
            7 => g.multiline = true,
            8 => g.invert_match = true,
            9 => g.files_with_matches = true,
            10 => g.count = true,
            11 => (g.with_filename, g.no_filename) = (true, false),
            12 => (g.no_filename, g.with_filename) = (true, false),
            13 => (g.line_number, g.no_line_number) = (true, false),
            14 => (g.no_line_number, g.line_number) = (true, false),
            15 => g.follow = true,
            16 => g.hidden = true,
            17 => g.no_ignore = true,
            18 => g.index = true,
            19 => g.sort = true,
            20 => g.json = true,
            21 => g.stats = true,
            22 => g.symbols = true,
            _ => no_color = true,
        }
        Some(())
    };
    let mut value = |i: usize, v: &String, g: &mut GrepArgs| -> Option<()> {
        match i {
            0 => g.regexp.push(v.clone()),
            1 => g.globs.push(v.clone()),
            _ if threads_seen || v.is_empty() || !v.bytes().all(|b| b.is_ascii_digit()) => return None,
            _ => {
                threads_seen = true;
                g.threads = v.parse().ok()?;
            }
        }
        Some(())
    };
    if !matches!(args.get(1).map(String::as_str), Some("grep" | "g")) || args.iter().any(|a| a.contains('\u{FFFD}')) {
        return None;
    }
    let mut rest = args[2..].iter();
    while let Some(a) = rest.next() {
        if let Some(name) = a.strip_prefix("--") {
            if let Some(i) = BOOLS.iter().position(|f| f.1 == name) {
                set(i, &mut g)?;
            } else {
                let i = VALUES.iter().position(|f| f.1 == name)?;
                value(i, value_of(rest.next())?, &mut g)?;
            }
        } else if let Some(shorts) = a.strip_prefix('-').filter(|s| !s.is_empty()) {
            for (at, c) in shorts.char_indices() {
                if let Some(i) = BOOLS.iter().position(|f| f.0 == c) {
                    set(i, &mut g)?;
                    continue;
                }
                let i = VALUES.iter().position(|f| f.0 == c)?;
                let attached = &shorts[at + 1..];
                if attached.is_empty() {
                    value(i, value_of(rest.next())?, &mut g)?;
                } else if !attached.starts_with(['=', '-']) {
                    value(i, &attached.to_string(), &mut g)?;
                } else {
                    return None;
                }
                break;
            }
        } else {
            positional.push(a);
        }
    }
    // clap refuses an empty path
    if positional.iter().skip(1).any(|p| p.is_empty()) {
        return None;
    }
    let mut positional = positional.into_iter().cloned();
    g.pattern = positional.next().map(Into::into);
    g.paths = positional.map(PathBuf::from).collect();
    (g.pattern.is_some() || !g.regexp.is_empty()).then_some((no_color, g))
}

#[derive(Subcommand)]
pub enum Cmd {

    #[command(alias = "g", version)]
    Grep(GrepArgs),

    Index {
        #[arg(long)]
        force: bool,

        #[arg(long, conflicts_with = "no_text")]
        text: bool,

        #[arg(long)]
        no_text: bool,
    },

    #[command(alias = "s")]
    Search {
        query: String,

        #[arg(short = 'a', long = "alt")]
        alt: Vec<String>,

        #[arg(long = "also", value_name = "ROOT")]
        also: Vec<PathBuf>,
        #[arg(short, default_value_t = crate::ops::SEARCH_K)]
        k: usize,

        #[arg(long)]
        why: bool,
        #[arg(long)]
        json: bool,
    },

    Find {
        query: String,
        #[arg(short, default_value_t = crate::ops::SEARCH_K)]
        k: usize,
        #[arg(long)]
        json: bool,
    },

    Symbol {
        name: String,

        #[arg(long, default_value_t = crate::ops::SYMBOL_LIMIT)]
        limit: usize,
        #[arg(long)]
        json: bool,
    },

    Callers {
        name: String,

        #[arg(long, default_value_t = crate::ops::CALLERS_LIMIT)]
        limit: usize,
        #[arg(long)]
        json: bool,
    },

    Callees {
        name: String,

        #[arg(long, default_value_t = crate::ops::CALLEES_LIMIT)]
        limit: usize,
        #[arg(long)]
        json: bool,
    },

    Deps {
        file: String,
        #[arg(long)]
        json: bool,
    },

    Rdeps {
        target: String,
        #[arg(long)]
        json: bool,
    },

    Outline {
        file: String,
        #[arg(long)]
        json: bool,
    },

    Refs {
        name: String,
        #[arg(long)]
        json: bool,
        #[arg(long, default_value_t = crate::ops::REFS_MAX)]
        max_results: u64,

        #[arg(long = "def", value_name = "PATH[:LINE]")]
        def: Option<String>,

        #[arg(long, conflicts_with = "def")]
        textual: bool,
    },

    Similar {
        target: String,
        #[arg(short, default_value_t = crate::ops::SIMILAR_K)]
        k: usize,
        #[arg(long)]
        json: bool,
    },

    Dupes {

        #[arg(long, default_value_t = crate::ops::DUPES_MIN_TOKENS)]
        min_tokens: usize,

        #[arg(long, default_value_t = crate::ops::DUPES_THRESHOLD)]
        threshold: f32,
        #[arg(long, default_value_t = crate::ops::DUPES_LIMIT)]
        limit: usize,
        #[arg(long)]
        json: bool,
    },

    Tsquery {
        lang: String,
        query: String,
        #[arg(default_value = ".")]
        paths: Vec<PathBuf>,
        #[arg(long, default_value_t = crate::ops::TSQUERY_LIMIT)]
        limit: usize,
        #[arg(long)]
        json: bool,

        #[arg(long)]
        no_cache: bool,
    },

    Stats,

    Watch {

        path: Option<PathBuf>,
    },

    Serve {

        #[arg(long, env = "SCRUTATE_REFRESH_INTERVAL")]
        refresh_interval: Option<f64>,

        #[arg(long)]
        watch: bool,



        #[arg(long, env = "SCRUTATE_MCP_STRUCTURED", value_parser = clap::builder::FalseyValueParser::new())]
        structured: bool,
    },

    Lsp,


    Check {
        #[arg(long)]
        files: bool,
        #[arg(long)]
        json: bool,
    },

    Config {

        #[arg(long)]
        json: bool,
    },

    Languages {
        #[arg(long)]
        json: bool,
    },

    Completions { shell: Shell },

    #[command(hide = true)]
    Sexp { file: PathBuf },

    Batch {
        file: PathBuf,

        #[arg(long)]
        features: bool,
        #[arg(long)]
        timing: bool,
    },



    #[command(hide = true)]
    Views { file: PathBuf },
}

fn parse_size(s: &str) -> Result<u64> {
    let s = s.trim();
    let (num, mult) = match s.chars().last() {
        Some('K') | Some('k') => (&s[..s.len() - 1], 1024u64),
        Some('M') | Some('m') => (&s[..s.len() - 1], 1024 * 1024),
        Some('G') | Some('g') => (&s[..s.len() - 1], 1024 * 1024 * 1024),
        _ => (s, 1),
    };
    num.parse::<u64>().ok().and_then(|n| n.checked_mul(mult)).with_context(|| format!("bad size {s:?}"))
}


fn by_content(id: &str) -> Vec<&'static str> {
    crate::langs::BY_CONTENT.iter().filter(|(_, ids)| ids.contains(&id)).map(|(e, _)| *e).collect()
}

fn open_fresh(root: &Path) -> Result<crate::Repo> {
    let (s, st) = crate::open_updated(root, false)?;
    if st.files_changed > 0 || st.files_removed > 0 {
        eprintln!("[scrutate] indexed {} changed files ({} chunks, {:.1}s)", st.files_changed, st.chunks, st.seconds);
    }
    Ok(s)
}

fn color_choice(no_color: bool) -> ColorChoice {
    if no_color || !std::io::stdout().is_terminal() || std::env::var_os("NO_COLOR").is_some_and(|v| !v.is_empty()) {
        ColorChoice::Never
    } else {
        ColorChoice::Auto
    }
}


pub fn looks_like_regex(q: &str) -> bool {
    q.chars().any(|c| matches!(c, '*' | '+' | '?' | '[' | ']' | '(' | ')' | '|' | '^' | '$' | '\\' | '{' | '}'))
}


fn split_globs(list: &str) -> Vec<String> {
    let (mut out, mut cur, mut depth) = (Vec::new(), String::new(), 0usize);
    for c in list.chars() {
        match c {
            '{' => depth += 1,
            '}' => depth = depth.saturating_sub(1),
            ',' if depth == 0 => {
                out.push(std::mem::take(&mut cur));
                continue;
            }
            _ => {}
        }
        cur.push(c);
    }
    out.push(cur);
    out.retain(|g| !g.is_empty());
    out
}

const CONFIG_FILE: &str = ".scrutate.toml";



fn nearest_config(cwd: &Path) -> PathBuf {
    for dir in cwd.ancestors() {
        if dir.join(CONFIG_FILE).is_file() {
            return dir.to_path_buf();
        }
        if dir.join(".git").exists() || dir.join(crate::files::INDEX_DIR).is_dir() {
            break;
        }
    }
    cwd.to_path_buf()
}


fn names_below(dir: &Path, top: &Path) -> Vec<String> {
    dir.strip_prefix(top).map(|r| r.components().map(|c| c.as_os_str().to_string_lossy().into_owned()).collect()).unwrap_or_default()
}





pub(crate) fn index_above(cwd: &Path) -> Option<PathBuf> {
    let has_index = |d: &Path| d.join(crate::files::INDEX_DIR).is_dir();
    let mut nearest = None;
    for dir in cwd.ancestors() {
        if nearest.is_none() && has_index(dir) {
            nearest = Some(dir);
        }
        if dir.join(".git").exists() {
            // a home directory kept in git is no project: nothing is built there from below
            let build_here = nearest.is_none() && !is_home(dir);
            if has_index(dir) || build_here {
                nearest = Some(dir);
            }
            break;
        }
    }
    nearest.filter(|d| *d != cwd).map(Path::to_path_buf)
}


fn is_home(dir: &Path) -> bool {
    let canonical = |p: &Path| std::fs::canonicalize(p).unwrap_or_else(|_| p.to_path_buf());
    std::env::var_os(if cfg!(windows) { "USERPROFILE" } else { "HOME" }).is_some_and(|h| canonical(Path::new(&h)) == canonical(dir))
}



pub(crate) fn no_first_build(dir: &Path) -> Option<String> {
    let wide = dir.parent().is_none() || is_home(dir);
    (wide && !dir.join(crate::files::INDEX_DIR).is_dir()).then(|| {
        format!(
            "[scrutate] {} is the home directory or a filesystem root and has no index: pass --root DIR for a project, or run `scrutate index` here to index everything below it",
            dir.display().to_string().trim_start_matches(r"\\?\")
        )
    })
}



struct Here {
    cwd: PathBuf,

    root: PathBuf,
    canonical_root: PathBuf,

    inside: bool,

    below: Vec<String>,
}


enum Named {

    Given,

    Root(String),

    Outside(PathBuf),
}

impl Here {
    fn new(cwd: Option<PathBuf>, root: &Path) -> Here {
        let cwd = cwd.unwrap_or_default();
        let canonical_root = std::fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
        // both in one form: a Windows temp directory may come as an 8.3 short name
        let canonical_cwd = std::fs::canonicalize(&cwd).unwrap_or_else(|_| cwd.clone());
        let below = names_below(&canonical_cwd, &canonical_root);
        Here { inside: canonical_cwd.starts_with(&canonical_root), cwd, root: root.to_path_buf(), canonical_root, below }
    }


    fn unused() -> Here {
        Here { cwd: PathBuf::new(), root: PathBuf::new(), canonical_root: PathBuf::new(), inside: false, below: Vec::new() }
    }


    fn below(&self) -> Option<String> {
        (!self.below.is_empty()).then(|| self.below.join("/"))
    }

    fn named(&self, arg: &str) -> Named {
        let p = Path::new(arg);
        if arg.is_empty() || !self.cwd.join(p).exists() {
            return Named::Given;
        }
        if self.inside && !p.is_absolute() {
            // spelled from here, so a symbolic link inside the repository keeps its name
            let lexical = p.components().try_fold(self.below.clone(), |mut parts, c| {
                match c {
                    std::path::Component::Normal(n) => parts.push(n.to_string_lossy().into_owned()),
                    std::path::Component::ParentDir => {
                        parts.pop()?;
                    }
                    _ => {}
                }
                Some(parts)
            });
            if let Some(parts) = lexical {
                return Named::Root(parts.join("/"));
            }
        }
        match std::fs::canonicalize(self.cwd.join(p)) {
            Ok(abs) => match abs.strip_prefix(&self.canonical_root) {
                Ok(rel) => Named::Root(crate::instant::slashed(rel.to_string_lossy())),
                Err(_) => Named::Outside(abs),
            },
            Err(_) => Named::Given,
        }
    }



    fn path(&self, arg: &str) -> String {
        match self.named(arg) {
            Named::Root(r) if !r.is_empty() => r,
            _ => arg.to_string(),
        }
    }


    fn location(&self, arg: &str) -> String {
        match arg.rsplit_once(':') {
            Some((path, line)) if crate::intel::location(arg).is_some() => format!("{}:{line}", self.path(path)),
            _ => arg.to_string(),
        }
    }



    fn shell(&self, p: &Path) -> PathBuf {
        if p.is_absolute() || self.cwd.join(p).exists() {
            return p.to_path_buf();
        }
        let up: PathBuf = if self.inside { self.below.iter().map(|_| "..").collect() } else { self.root.clone() };
        if self.cwd.join(&up).join(p).exists() {
            up.join(p)
        } else {
            p.to_path_buf()
        }
    }
}


fn named_file(cmd: &Cmd) -> Option<&str> {
    fn loc(s: &str) -> Option<&str> {
        crate::intel::location(s).map(|(p, _)| p)
    }
    match cmd {
        Cmd::Symbol { name, .. } | Cmd::Callers { name, .. } | Cmd::Callees { name, .. } => loc(name),
        Cmd::Similar { target, .. } => loc(target),
        Cmd::Deps { file, .. } | Cmd::Outline { file, .. } => Some(file),
        Cmd::Rdeps { target, .. } => Some(target),
        Cmd::Refs { def: Some(d), .. } => loc(d).or(Some(d)),
        _ => None,
    }
}

pub fn run() -> Result<i32> {
    // configuration file -> environment -> clap (command line still wins)
    let args: Vec<String> = std::env::args_os().map(|a| a.to_string_lossy().into_owned()).collect();
    let cwd = std::env::current_dir().ok();
    let root_given = std::env::var_os("SCRUTATE_ROOT").is_some() || args.iter().any(|a| a == "--root" || a.starts_with("--root="));
    let cfg_root = match &cwd {
        Some(cwd) if !root_given => nearest_config(cwd),
        _ => crate::config::root_from_args(&args),
    };
    let cfg_path = crate::config::locate(&cfg_root);
    let local = cfg_path.as_deref() == Some(cfg_root.join(CONFIG_FILE).as_path());
    // the globs of a .scrutate.toml match from its directory, so they do not go through the
    // environment, where -g's meaning (from each searched path) would apply
    let mut cfg_globs = Vec::new();
    let mut cfg_excludes = false;
    // a bad file stops the commands that read it, after clap has had --help and --version
    let cfg_error = cfg_path.as_deref().and_then(|p| {
        crate::config::load(p)
            .map(|mut cfg| {
                cfg_excludes = !cfg.index.exclude_dirs.is_empty();
                if local {
                    cfg_globs = std::mem::take(&mut cfg.grep.globs);
                    crate::config::confine(&mut cfg);
                }
                crate::config::apply_as_env(&cfg)
            })
            .err()
    });
    // as with every other setting, the environment and the command line replace the file's globs
    let cfg_globs = if std::env::var_os("SCRUTATE_GREP_GLOBS").is_none() { cfg_globs } else { Vec::new() };
    let mut cli = if matches!(args.get(1).map(String::as_str), Some("grep" | "g")) {
        // a setting from a file, or from a variable clap reads for grep, is clap's to read
        let settings = cfg_path.is_some() || GREP_ENV.iter().any(|name| std::env::var_os(name).is_some());
        let (root, no_color, grep) = match (!settings).then(|| plain_grep(&args)).flatten() {
            Some((no_color, grep)) => (PathBuf::from("."), no_color, grep),
            None => {
                let GrepCli { root, no_color, cmd: GrepCmd::Grep(grep) } = GrepCli::parse();
                if grep.regexp.is_empty() && grep.pattern.as_ref().is_some_and(|p| p.to_str().is_none()) {
                    // clap's own error for a `String` argument
                    let mut cmd = GrepCli::command();
                    cmd.build();
                    let grep = cmd.find_subcommand_mut("grep").expect("the grep subcommand");
                    grep.error(clap::error::ErrorKind::InvalidUtf8, "invalid UTF-8 was detected in one or more arguments").exit();
                }
                (root, no_color, grep)
            }
        };
        Cli { root, no_color, max_bytes: None, offset: 0, cmd: Cmd::Grep(grep) }
    } else {
        Cli::parse()
    };
    if let Some(e) = cfg_error {
        if !matches!(cli.cmd, Cmd::Config { .. } | Cmd::Completions { .. }) {
            return Err(e);
        }
        diagnostic("warning", &format!("{e:#}"));
    }
    let uses_index = match &cli.cmd {
        Cmd::Grep(g) => g.index || g.symbols,
        // the language server applies the rule to the editor's folder
        Cmd::Config { .. } | Cmd::Completions { .. } | Cmd::Languages { .. } | Cmd::Sexp { .. } | Cmd::Watch { path: Some(_) } | Cmd::Lsp => false,
        _ => true,
    };
    let mut found_index = None;
    if uses_index && !root_given {
        if let Some(top) = cwd.as_deref().and_then(index_above) {
            cli.root = top.clone();
            found_index = Some(top);
        }
    }
    // a search without the index never looks at the root: two canonical paths, 0.3 M instructions
    let mut here = match &cli.cmd {
        Cmd::Grep(g) if !g.index => Here::unused(),
        _ => Here::new(cwd.clone(), &cli.root),
    };
    // a file of another indexed repository (a path `search --also` printed) is answered from its index
    let mut outside = None;
    if let Some(arg) = named_file(&cli.cmd) {
        if let Named::Outside(abs) = here.named(arg) {
            match abs.ancestors().find(|d| d.join(crate::files::INDEX_DIR).is_dir()) {
                Some(top) => {
                    cli.root = top.to_path_buf();
                    found_index = Some(top.to_path_buf());
                    here = Here::new(cwd.clone(), &cli.root);
                }
                None => outside = Some(format!("{} is outside the repository", crate::fmt::echo(arg))),
            }
        }
    }
    // `index` there is the user's stated wish; any other first build there is not
    if uses_index && !root_given && found_index.is_none() && !matches!(cli.cmd, Cmd::Index { .. }) {
        if let Some(why) = cwd.as_deref().and_then(no_first_build) {
            eprintln!("{why}");
            return Ok(2);
        }
    }
    if let Some(top) = found_index {
        eprintln!("[scrutate] using the index in {}", top.display().to_string().trim_start_matches(r"\\?\"));
    }
    // every process that updates an index must leave out the same directories, so only the root's own file counts
    if cfg_excludes && uses_index && std::env::var_os("SCRUTATE_INDEX_EXCLUDE_DIRS").is_none() {
        let own = cli.root.join(CONFIG_FILE);
        let same = |a: &Path, b: &Path| std::fs::canonicalize(a).ok().zip(std::fs::canonicalize(b).ok()).is_some_and(|(a, b)| a == b);
        if let Some(p) = cfg_path.as_deref().filter(|p| !same(p, &own)) {
            diagnostic(
                "warning",
                &format!("exclude_dirs in {} is ignored: the index reads it from {} (or SCRUTATE_INDEX_EXCLUDE_DIRS)", p.display(), own.display()),
            );
        }
    }
    let no_color = cli.no_color;
    let page = (cli.max_bytes.unwrap_or(usize::MAX), cli.offset);
    match cli.cmd {
        Cmd::Grep(GrepArgs {
            pattern,
            mut paths,
            regexp,
            index,
            update,
            fixed_strings,
            pcre2,
            fuzzy_regex,
            search_zip,
            ident,
            fuzzy,
            ignore_case,
            smart_case,
            word,
            multiline,
            invert_match,
            files_with_matches,
            count,
            with_filename,
            no_filename,
            line_number: _,
            no_line_number,
            after,
            before,
            context,
            max_count,
            max_results,
            globs,
            types,
            type_list,
            hidden,
            no_ignore,
            follow,
            max_filesize,
            max_depth,
            threads,
            sort,
            json,
            stats,
            symbols,
        }) => {
            // read here, not by clap: with an environment value clap rejects -i as conflicting
            let smart_case = smart_case
                || !ignore_case
                    && std::env::var("SCRUTATE_GREP_SMART_CASE")
                        .is_ok_and(|v| !matches!(v.to_ascii_lowercase().as_str(), "" | "0" | "n" | "no" | "f" | "false" | "off"));
            let scoped_globs = if globs.is_empty() && !cfg_globs.is_empty() { Some(Arc::new(instant::ScopedGlobs::new(&cfg_root, &cfg_globs)?)) } else { None };
            let globs = if globs.is_empty() { std::env::var("SCRUTATE_GREP_GLOBS").map(|v| split_globs(&v)).unwrap_or_default() } else { globs };
            if type_list {
                let mut so = std::io::stdout().lock();
                for (name, globs) in instant::type_list() {
                    match writeln!(so, "{name}: {}", globs.join(", ")) {
                        Err(e) if e.kind() == std::io::ErrorKind::BrokenPipe => break,
                        r => r?,
                    }
                }
                return Ok(0);
            }
            if pcre2 && (ident || fuzzy.is_some()) {
                anyhow::bail!("-P/--pcre2 cannot be combined with --ident or --fuzzy");
            }
            if fuzzy_regex.is_some() && (pcre2 || ident || fuzzy.is_some() || fixed_strings) {
                anyhow::bail!("--fuzzy-regex cannot be combined with -P, --ident, --fuzzy or -F (use --fuzzy for a literal)");
            }
            let mode = match (fixed_strings, ident, fuzzy) {
                _ if fuzzy_regex.is_some() => Mode::FuzzyRegex { max_edits: fuzzy_regex.unwrap_or(1) },
                (_, _, Some(n)) => Mode::Fuzzy { max_edits: n },
                (_, true, _) => Mode::Identifier,
                _ if pcre2 => Mode::Pcre2,
                (true, _, _) => Mode::Literal,
                _ => Mode::Regex,
            };
            let (pattern, mode) = if regexp.is_empty() {
                instant::join_patterns(&[pattern.and_then(|p| p.into_string().ok()).unwrap_or_default()], mode, fixed_strings)?
            } else {
                // with -e, the first positional argument is a path
                if let Some(p) = pattern {
                    paths.insert(0, PathBuf::from(p));
                }
                instant::join_patterns(&regexp, mode, fixed_strings)?
            };
            // as ripgrep: no path, and a pipe or a file on standard input, searches standard input
            if paths.is_empty() && !index && grep_cli::is_readable_stdin() {
                paths.push(PathBuf::from("-"));
            }
            let case = if ignore_case {
                Case::Insensitive
            } else if smart_case {
                Case::Smart
            } else {
                Case::Sensitive
            };
            let q = Query {
                pattern: Pattern { text: pattern, mode, case, word, multiline, ..Pattern::default() },
                invert: invert_match,
                // -c with -l prints the count of the one match -l stops at
                report: if files_with_matches {
                    Report::Files
                } else if count {
                    Report::Counts
                } else {
                    Report::Lines
                },
                max_count,
                max_results,
                first_in_path_order: sort,
                before: context.unwrap_or(before),
                after: context.unwrap_or(after),
                want_bytes: stats || json,
                want_spans: json || color_choice(no_color) != ColorChoice::Never,
                text_spans: true,
                raw_member_names: json,
                // as ripgrep: one path that is not a directory is searched without its name; with
                // -z an archive is a directory of its members
                with_filename: with_filename
                    || (!no_filename
                        && !(paths.len() == 1
                            && !paths[0].is_dir()
                            && !(search_zip && crate::archive::Kind::of(&paths[0].to_string_lossy()).is_some_and(|k| k.has_members())))),
                line_numbers: !no_line_number,
            };
            let mut f = Files {
                hidden,
                no_ignore,
                follow_links: follow,
                globs,
                scoped_globs,
                types,
                max_filesize: max_filesize.as_deref().map(parse_size).transpose()?,
                max_depth,
                threads,
                search_zip,
                paths_as_given: !paths.is_empty(),
                small_tree: std::env::var("SCRUTATE_SMALL_TREE").ok().and_then(|v| v.parse().ok()),
                cwd: cwd.clone(),
                ..Files::default()
            };
            if let Some(n) = std::env::var("SCRUTATE_SPLIT_FILE_BYTES").ok().and_then(|v| v.parse().ok()) {
                f.split_file_bytes = n;
            }
            if index {
                f.check_indexable()?;
                if !paths.is_empty() {
                    anyhow::bail!("--index searches the indexed repository (--root); narrow it with -g/-t instead of paths");
                }
            }
            let roots: Vec<PathBuf> = if paths.is_empty() { vec![PathBuf::from(".")] } else { paths };
            f.paths = Paths::Walk(roots);
            let under = here.below();
            grep_command(q, f, GrepOutput { files_with_matches, count, sort, json, stats, symbols, root: cli.root, no_color, indexed: index, update, under })
        }
        Cmd::Index { force, text, no_text } => {
            let w = match (text, no_text) {
                (true, _) => Writer::IndexText,
                (_, true) => Writer::IndexCode,
                _ => Writer::Index,
            };
            let up = crate::stores::update(&cli.root, w, force)?;
            if let Some(st) = up.code {
                println!("{} files, {} changed, {} chunks, semantic={}, {:.1}s", st.files_total, st.files_changed, st.chunks, st.semantic, st.seconds);
            }
            if let Some(t) = up.text {
                println!(
                    "text index: {} files, {} changed, {} removed, {} segment(s), {:.1} MB, {:.1}s",
                    t.files,
                    t.files_changed,
                    t.files_removed,
                    t.segments,
                    t.bytes as f64 / 1e6,
                    t.seconds
                );
            }
            Ok(0)
        }
        Cmd::Stats => {
            let s = open_fresh(&cli.root)?;
            let mut v = s.ix.stats()?;
            if let Some(t) = crate::textindex::TextIndex::open(&s.ix.root)? {
                v["text_index"] =
                    serde_json::json!({"files": t.files(), "segments": t.segments(), "bytes": crate::textindex::TextIndex::disk_bytes(&s.ix.root)});
            }
            println!("{}", serde_json::to_string(&v)?);
            Ok(0)
        }
        Cmd::Search { query, alt, also, k, why, json } => {
            let mut qs = vec![query.clone()];
            qs.extend(alt.iter().cloned());
            // each repository once, whatever the spelling; the first is the current one
            let mut roots: Vec<(PathBuf, PathBuf)> = Vec::new();
            for root in std::iter::once(&cli.root).chain(&also) {
                let canonical = std::fs::canonicalize(root).unwrap_or_else(|_| root.clone());
                if !roots.iter().any(|(_, c)| *c == canonical) {
                    roots.push((root.clone(), canonical));
                }
            }
            // (hit, its repository) with the path a reader opens from here: another repository's
            // results carry its path as given
            let mut hits: Vec<(crate::search::Hit, usize)> = Vec::new();
            for (i, (root, _)) in roots.iter().enumerate() {
                let mut s = open_fresh(root)?;
                let part = s.recovering(|s| if alt.is_empty() { s.search(&query, k, true) } else { s.search_many(&qs, k, true) })?;
                hits.extend(part.into_iter().map(|h| (h, i)));
            }
            let shown = |(h, i): &(crate::search::Hit, usize)| {
                if *i == 0 {
                    h.path.clone()
                } else {
                    format!("{}/{}", roots[*i].0.to_string_lossy().trim_end_matches('/'), h.path)
                }
            };
            if roots.len() > 1 {
                // the ranker's scores are comparable across repositories (same model, same features)
                hits.sort_by(|a, b| b.0.score.partial_cmp(&a.0.score).unwrap_or(std::cmp::Ordering::Equal).then_with(|| shown(a).cmp(&shown(b))));
                hits.truncate(k);
            }
            let other = hits.iter().find(|(_, i)| *i > 0).map(|x| format!("{}:{}-{}", shown(x), x.0.start, x.0.end));
            if json && roots.len() > 1 {
                let plain: Vec<crate::search::Hit> = hits.iter().map(|(h, _)| h.clone()).collect();
                let mut v = hits_json(&plain);
                for (rec, (_, i)) in v.as_array_mut().into_iter().flatten().zip(&hits) {
                    rec["root"] = serde_json::json!(roots[*i].1.to_string_lossy());
                }
                println!("{}", serde_json::to_string_pretty(&v)?);
            } else {
                let hits: Vec<crate::search::Hit> = hits.iter().map(|x| crate::search::Hit { path: shown(x), ..x.0.clone() }).collect();
                if json || hits.is_empty() {
                    print_hits(&hits, &qs, why, json)?;
                } else {
                    let words: Vec<String> = qs.iter().flat_map(|q| query_words(q)).collect();
                    println!("{}", crate::ops::paged(crate::fmt::hit_blocks(&hits, &words, true, why), "results", page.0, page.1));
                }
            }
            if let (Some(other), false) = (other, json) {
                eprintln!("[scrutate] a location of another repository is answered from its own index as printed (scrutate symbol {other})");
            }
            Ok(if hits.is_empty() { 1 } else { 0 })
        }
        Cmd::Check { files, json } => check_command(&cli.root, files, json),
        Cmd::Config { json: true } => {
            let root = match (root_given, &cwd) {
                (false, Some(cwd)) => index_above(cwd).unwrap_or_else(|| cwd.clone()),
                _ => std::path::absolute(&cli.root).unwrap_or(cli.root),
            };
            println!("{}", serde_json::json!({"root": root.to_string_lossy(), "configuration_file": cfg_path.map(|p| p.to_string_lossy().into_owned())}));
            Ok(0)
        }
        Cmd::Config { json: false } => {
            match &cfg_path {
                Some(p) => {
                    println!("configuration file: {}", p.display());
                    println!("{}", std::fs::read_to_string(p)?.trim_end());
                    if !cfg_globs.is_empty() {
                        println!("\ngrep globs, matched from {}: {}", cfg_root.display().to_string().trim_start_matches(r"\\?\"), cfg_globs.join(", "));
                    }
                }
                None if root_given => println!(
                    "no configuration file (looked for $SCRUTATE_CONFIG, {}/{CONFIG_FILE}, $XDG_CONFIG_HOME/scrutate/config.toml)",
                    cfg_root.display()
                ),
                None => println!(
                    "no configuration file (looked for $SCRUTATE_CONFIG, {CONFIG_FILE} here and in each directory above up to the repository top, $XDG_CONFIG_HOME/scrutate/config.toml)"
                ),
            }
            println!("\nenvironment in effect:");
            let mut vars: Vec<(String, String)> = std::env::vars().filter(|(k, _)| k.starts_with("SCRUTATE_")).collect();
            vars.sort();
            for (k, v) in vars {
                println!("  {k}={v}");
            }
            let root = match (root_given, &cwd) {
                (false, Some(cwd)) => index_above(cwd).unwrap_or_else(|| cwd.clone()),
                _ => cli.root.clone(),
            };
            let excluded = crate::files::config_excludes(&root);
            if std::env::var_os("SCRUTATE_INDEX_EXCLUDE_DIRS").is_none() && !excluded.is_empty() {
                println!("\nindex exclude_dirs, from {}: {}", root.join(CONFIG_FILE).display(), excluded.join(", "));
            }
            Ok(0)
        }
        Cmd::Find { query, k, json } => find_command(&cli.root, &query, k, json, no_color),
        Cmd::Symbol { name, limit, json } => run_op(&cli.root, Op::Symbol { name: here.location(&name), limit }, json, page, outside.as_deref()),
        Cmd::Callers { name, limit, json } => run_op(&cli.root, Op::Callers { name: here.location(&name), limit }, json, page, outside.as_deref()),
        Cmd::Callees { name, limit, json } => run_op(&cli.root, Op::Callees { name: here.location(&name), limit }, json, page, outside.as_deref()),
        Cmd::Deps { file, json } => run_op(&cli.root, Op::Deps { path: here.path(&file) }, json, page, outside.as_deref()),
        Cmd::Rdeps { target, json } => run_op(&cli.root, Op::Rdeps { target: here.path(&target) }, json, page, outside.as_deref()),
        Cmd::Outline { file, json } => run_op(&cli.root, Op::Outline { path: here.path(&file) }, json, page, outside.as_deref()),
        Cmd::Refs { name, json, max_results, def, textual } => {
            let def = def.map(|d| if crate::intel::location(&d).is_some() { here.location(&d) } else { here.path(&d) });
            run_op(&cli.root, Op::Refs { name, max_results, textual, def }, json, page, outside.as_deref())
        }
        Cmd::Similar { target, k, json } => run_op(&cli.root, Op::Similar { target: here.location(&target), k }, json, page, outside.as_deref()),
        Cmd::Dupes { min_tokens, threshold, limit, json } => run_op(&cli.root, Op::Dupes { min_tokens, threshold, limit }, json, page, outside.as_deref()),
        Cmd::Tsquery { lang, query, paths, limit, json, no_cache } => {
            // streamed: one JSON object or one text line per capture, in path order
            let stdout = std::io::stdout();
            let mut w = std::io::BufWriter::new(stdout.lock());
            let mut err: Option<std::io::Error> = None;
            let cache_root = (!no_cache).then_some(cli.root.as_path());
            let paths: Vec<PathBuf> = paths.iter().map(|p| here.shell(p)).collect();
            // as grep: a path that cannot be read is named, the others are still searched, exit 2
            let mut missing = false;
            for p in &paths {
                if let Err(e) = std::fs::metadata(p) {
                    diagnostic("warning", &format!("{}: {e}", p.display()));
                    missing = true;
                }
            }
            // with a size limit or an offset the lines are collected and paged as other answers are
            let paging = !json && page != (usize::MAX, 0);
            let mut lines: Vec<String> = Vec::new();
            // one more than the limit, to tell whether it cut the answer
            let mut seen = 0usize;
            let n = crate::intel::tsquery_each(&lang, &query, &paths, true, limit.saturating_add(1), cache_root, &mut |c| {
                seen += 1;
                if err.is_some() || seen > limit {
                    return;
                }
                if paging {
                    lines.push(crate::ops::capture_line(&c));
                    return;
                }
                let r = if json {
                    serde_json::to_writer(&mut w, &c)
                        .map_err(|e| std::io::Error::new(e.io_error_kind().unwrap_or(std::io::ErrorKind::Other), e))
                        .and_then(|_| w.write_all(b"\n"))
                } else {
                    writeln!(w, "{}", crate::ops::capture_line(&c))
                };
                if let Err(e) = r {
                    err = Some(e);
                }
            })?;
            if paging && !lines.is_empty() {
                err = writeln!(w, "{}", crate::ops::paged(lines, "matches", page.0, page.1)).err();
            }
            if n > limit && err.is_none() {
                let note = crate::ops::stop_line(Some(crate::ops::Stop { at: limit, how: crate::ops::RAISE_LIMIT }), "matches");
                if json {
                    eprintln!("{note}");
                } else {
                    err = writeln!(w, "{note}").err();
                }
            }
            if let Some(e) = err {
                if e.kind() != std::io::ErrorKind::BrokenPipe {
                    return Err(e.into());
                }
            }
            let _ = w.flush();
            Ok(if missing {
                2
            } else if n == 0 {
                1
            } else {
                0
            })
        }
        Cmd::Serve { refresh_interval, watch, structured } => {
            if cli.offset != 0 {
                anyhow::bail!("--offset does nothing with serve: a tool call takes its own offset");
            }
            let s = crate::Repo::open(&cli.root)?;
            let root = s.ix.root.clone();
            let s = Arc::new(Mutex::new(s));
            if watch {
                let s = Arc::clone(&s);
                std::thread::Builder::new().name("scrutate-watch".into()).spawn(move || {
                    static NEVER: AtomicBool = AtomicBool::new(false);
                    // the searcher's lock makes this the only writer in the process; the index's own
                    // locks order it with other processes
                    let r = crate::watch::run(
                        &root,
                        &NEVER,
                        || eprintln!("[scrutate] watching {}", root.display()),
                        unwinding(|changes| {
                            s.lock().unwrap_or_else(|p| p.into_inner()).update_stores(Writer::Watch, changes, false)?;
                            Ok(())
                        }),
                    );
                    if let Err(e) = r {
                        eprintln!("[scrutate] watching stopped: {e:#}");
                    }
                })?;
            }
            crate::mcp::serve(s, crate::mcp::Settings::new(cli.max_bytes, refresh_interval), crate::VERSION, structured)?;
            Ok(0)
        }
        Cmd::Lsp => crate::lsp::serve(&cli.root, root_given),
        Cmd::Watch { path } => watch_command(path.as_deref().unwrap_or(&cli.root)),
        Cmd::Languages { json: true } => {
            // the verified capability registry: what each grammar's rules extract
            let v: Vec<serde_json::Value> = crate::langs::LANGS
                .iter()
                .map(|spec| {
                    let kinds = crate::langs::definition_kinds(spec);
                    serde_json::json!({
                        "id": spec.id, "extensions": spec.exts, "extensions_by_content": by_content(spec.id), "filenames": spec.files,
                        "definitions": !spec.defs.is_empty(), "definition_kinds": kinds,
                        "call_edges": !spec.calls.is_empty(), "imports": !spec.imports.is_empty(),
                        "docstrings": spec.docstring, "tier": "grammar"
                    })
                })
                .collect();
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(0)
        }
        Cmd::Languages { json: false } => {
            let mut so = std::io::stdout().lock();
            for spec in crate::langs::LANGS.iter() {
                let labelled = |label: &str, v: &[&str]| (!v.is_empty()).then(|| format!("{label}{}", v.join(" ")));
                let parts = [labelled("", spec.exts), labelled("by content: ", &by_content(spec.id)), labelled("files: ", spec.files)];
                match writeln!(so, "{:<16} {}", spec.id, parts.into_iter().flatten().collect::<Vec<_>>().join("  ")) {
                    Err(e) if e.kind() == std::io::ErrorKind::BrokenPipe => break,
                    r => r?,
                }
            }
            Ok(0)
        }
        Cmd::Completions { shell } => {
            let mut cmd = Cli::command();
            let name = cmd.get_name().to_string();
            let sh = match shell {
                Shell::Bash => clap_complete::Shell::Bash,
                Shell::Zsh => clap_complete::Shell::Zsh,
                Shell::Fish => clap_complete::Shell::Fish,
                Shell::Powershell => clap_complete::Shell::PowerShell,
                Shell::Elvish => clap_complete::Shell::Elvish,
            };
            clap_complete::generate(sh, &mut cmd, name, &mut std::io::stdout());
            Ok(0)
        }
        Cmd::Sexp { file } => {
            let source = std::fs::read_to_string(&file)?;
            let rel = file.to_string_lossy().into_owned();
            match crate::parse::spec_for(&rel, &source) {
                Some(spec) => {
                    println!("grammar: {}", spec.id);
                    println!("{}", crate::parse::sexp(spec, &source));
                }
                None => println!("no grammar for {rel} (heuristic symbols)"),
            }
            for c in crate::parse::parse_source(&rel, &source) {
                println!(
                    "CHUNK {:<9} {:<30} L{}-{} doc={:?} calls={:?}",
                    c.kind,
                    c.qualname,
                    c.start,
                    c.end,
                    c.doc.lines().next().unwrap_or(""),
                    c.calls.iter().take(6).collect::<Vec<_>>()
                );
            }
            Ok(0)
        }
        Cmd::Batch { file, features, timing } => batch_command(&cli.root, &file, features, timing),
        Cmd::Views { file } => views_command(&file),
    }
}



fn views_command(file: &Path) -> Result<i32> {
    use crate::text::{query_terms, tokenize2, BODY_CAP};
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    for line in std::io::BufReader::new(std::fs::File::open(file)?).lines() {
        let line = line?;
        if line.trim().is_empty() {
            continue;
        }
        let req: serde_json::Value = serde_json::from_str(&line)?;
        let s = |k: &str| req.get(k).and_then(|v| v.as_str());
        if let Some(q) = s("query") {
            writeln!(out, "{}", serde_json::json!({"query": q, "terms": query_terms(q)}))?;
            continue;
        }
        let (Some(src), Some(rel)) = (s("file"), s("path")) else { anyhow::bail!("a request needs \"query\", or \"file\" and \"path\": {line}") };
        let parsed = std::fs::read(src)
            .map_err(anyhow::Error::from)
            .and_then(|raw| String::from_utf8(raw).map_err(anyhow::Error::from))
            .and_then(|text| std::panic::catch_unwind(|| crate::parse::parse_source(rel, &text)).map_err(|_| anyhow::anyhow!("the parser panicked")));
        let rec = match parsed {
            Ok(chunks) => {
                let chunks: Vec<serde_json::Value> = chunks
                    .iter()
                    .map(|c| {
                        let qual = c.qualname.rfind('.').map_or("", |i| &c.qualname[..i]);
                        serde_json::json!({
                            "kind": c.kind, "name": c.name, "qualname": c.qualname, "start": c.start, "doc": c.doc,
                            "views": {
                                "name": tokenize2(&c.name, None).0,
                                "qual": tokenize2(qual, None).0,
                                "sig": tokenize2(&c.sig, Some(80)).0,
                                "doc": tokenize2(&c.doc, Some(200)).0,
                                "body": tokenize2(&c.body, Some(BODY_CAP)).0,
                            }
                        })
                    })
                    .collect();
                serde_json::json!({"path": rel, "chunks": chunks})
            }
            Err(e) => serde_json::json!({"path": rel, "error": format!("{e:#}")}),
        };
        writeln!(out, "{rec}")?;
    }
    Ok(0)
}



fn run_op(root: &Path, op: Op, json: bool, (max_bytes, offset): (usize, usize), outside: Option<&str>) -> Result<i32> {
    use crate::ops::Answer;
    let mut s = open_fresh(root)?;
    let answer = match (s.recovering(|s| crate::ops::run(s, &op)), outside) {
        (Err(e), Some(why)) => anyhow::bail!("{e:#} ({why})"),
        (answer, _) => answer?,
    };
    // these print nothing on standard output when empty, so a pipeline sees no lines
    let quiet = matches!(answer, Answer::Outline { .. } | Answer::Deps { .. } | Answer::Rdeps { .. } | Answer::Similar(_) | Answer::Dupes(..));
    let why = outside.filter(|_| answer.is_empty());
    if json {
        println!("{}", serde_json::to_string_pretty(&answer.json())?);
        // standard output keeps the JSON's shape, so the stop line goes beside it
        let note = answer.stop_note();
        if !note.is_empty() {
            eprintln!("{note}");
        }
    } else if quiet && answer.is_empty() {
        eprintln!("{}{}", answer.text(), why.map(|w| format!(" ({w})")).unwrap_or_default());
        return Ok(1);
    } else {
        let text = answer.text_within(max_bytes, offset);
        print!("{text}{}", if text.ends_with('\n') { "" } else { "\n" });
    }
    if let Some(w) = why {
        eprintln!("[scrutate] {w}");
    }
    Ok(if answer.is_empty() { 1 } else { 0 })
}



fn watch_command(root: &Path) -> Result<i32> {
    let root = std::fs::canonicalize(root).with_context(|| format!("watch {}", root.display()))?;
    let stop = Arc::new(AtomicBool::new(false));
    interrupt::install(Arc::clone(&stop));
    let mut repo = crate::Repo::open(&root)?;
    let update = |changes: &crate::stores::Changes| -> Result<()> {
        let up = repo.update_stores(Writer::Watch, changes, false)?;
        let (st, text) = (up.code.unwrap_or_default(), up.text);
        let text_changed = text.as_ref().map(|t| t.files_changed + t.files_removed).unwrap_or(0);
        if st.files_changed + st.files_removed + text_changed > 0 {
            eprintln!(
                "[scrutate] {} changed, {} removed ({} chunks){}",
                st.files_changed,
                st.files_removed,
                st.chunks,
                text.map(|t| format!("; text index: {} changed, {} removed", t.files_changed, t.files_removed)).unwrap_or_default()
            );
        }
        Ok(())
    };
    crate::watch::run(&root, &stop, || eprintln!("[scrutate] watching {}", root.display()), unwinding(update))?;
    Ok(if stop.load(Ordering::Relaxed) { 130 } else { 0 })
}


fn unwinding(mut update: impl FnMut(&crate::stores::Changes) -> Result<()>) -> impl FnMut(&crate::stores::Changes) -> Result<()> {
    move |changes| {
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| update(changes)))
            .unwrap_or_else(|_| Err(anyhow::anyhow!("internal failure (a bug: please report it); the next change updates again")))
    }
}


fn check_command(root: &Path, files: bool, json: bool) -> Result<i32> {
    let mut s = crate::open(root)?;
    let report = s.ix.check(files)?;
    // a constant has no postings, so no segment row: the counts below leave it out
    let constants = s.ix.constants();
    if json {
        let mut v = serde_json::to_value(&report)?;
        v["constants"] = serde_json::json!(constants);
        println!("{}", serde_json::to_string_pretty(&v)?);
    } else {
        println!("database: {}", if report.database_ok { "ok" } else { "CORRUPT" });
        println!("segments: {} checked, {}", report.segments, if report.segments_ok { "ok" } else { "DAMAGED" });
        println!(
            "chunks: {} ranked in the database, {} alive in segments{}, {constants} constants (no postings)",
            report.chunks_db,
            report.chunks_alive,
            if report.chunks_db == report.chunks_alive { "" } else { "  MISMATCH" }
        );
        if files {
            println!("files: {} indexed, {} changed since indexing, {} missing", report.files_indexed, report.files_changed, report.files_missing);
        }
        for p in &report.problems {
            println!("problem: {p}");
        }
        println!("{}", if report.ok() { "OK" } else { "PROBLEMS FOUND (run `scrutate index` to repair; `scrutate index --force` rebuilds from scratch)" });
    }
    Ok(if report.ok() { 0 } else { 1 })
}

fn print_hits(hits: &[crate::search::Hit], qs: &[String], why: bool, json: bool) -> Result<()> {
    if json {
        println!("{}", serde_json::to_string_pretty(&hits_json(hits))?);
    } else {
        let words: Vec<String> = qs.iter().flat_map(|q| query_words(q)).collect();
        println!("{}", fmt_hits(hits, &words, true, why));
    }
    Ok(())
}

struct GrepOutput {
    files_with_matches: bool,
    count: bool,
    sort: bool,
    json: bool,
    stats: bool,
    symbols: bool,
    root: PathBuf,
    no_color: bool,

    indexed: bool,

    update: bool,


    under: Option<String>,
}



fn indexed_candidates(root: &Path, q: &Query, update: bool, under: Option<&str>) -> Result<(PathBuf, Vec<String>)> {
    let root = std::fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    if let Some(dir) = under {
        // the walk of the root never enters a hidden or ignored directory, so its index cannot answer for one
        let mut at = root.clone();
        for step in dir.split('/') {
            let next = at.join(step);
            if !crate::textindex::walk_entries(&at, Some(1)).0.contains(&next) {
                anyhow::bail!("the current directory is not in the index (hidden or ignored); search without --index");
            }
            at = next;
        }
    }
    if update {
        crate::stores::update(&root, Writer::GrepUpdate, false)?;
    }
    let ti = crate::textindex::TextIndex::open(&root)?
        .ok_or_else(|| anyhow::anyhow!("no text index in {}; build it with `scrutate index --text` (or add --update)", root.display()))?;
    let mut files = ti.candidates(&crate::textindex::query_for(q)?, q.pattern.multiline)?;
    if let Some(dir) = under {
        files = files.into_iter().filter_map(|f| f.strip_prefix(dir).and_then(|f| f.strip_prefix('/')).map(String::from)).collect();
        return Ok((root.join(dir), files));
    }
    Ok((root, files))
}


fn grep_command(q: Query, mut f: Files, out: GrepOutput) -> Result<i32> {
    let cancel = Arc::new(AtomicBool::new(false));
    interrupt::install(Arc::clone(&cancel));
    let roots = match &f.paths {
        Paths::Walk(roots) => roots.clone(),
        Paths::List { .. } | Paths::Memory(_) => Vec::new(),
    };
    let colour = color_choice(out.no_color) != ColorChoice::Never;
    let plain = !out.json && !colour && !out.sort && !out.symbols && q.report == Report::Lines;
    let sink = plain.then(|| Arc::new(instant::PlainSink::new(Box::new(crate::running::GivesWay(std::io::stdout())))));
    if out.indexed {
        let (root, files) = indexed_candidates(&out.root, &q, out.update, out.under.as_deref())?;
        f.paths = Paths::List { root, files };
    }
    if let Some(sink) = sink {
        return grep_plain(&roots, &q, &f, out, cancel, sink);
    }
    // buffered: one write per 64 KB instead of several per matching line
    let mut w = termcolor::BufferedStandardStream::stdout(color_choice(out.no_color));
    let mut collected: Vec<Record> = Vec::new();
    let mut pipe_closed = false; // the reader went away (`| head`): stop quietly, like ripgrep (exit 0)
    let mut counts: Vec<Record> = Vec::new();
    let defer = out.sort || out.count || out.files_with_matches || out.symbols;
    let mut found = false;
    let mut linebuf: Vec<u8> = Vec::with_capacity(512);
    let groups = q.before > 0 || q.after > 0;
    let mut last: Option<(Arc<str>, u64, u64)> = None;
    let mut emit = |r: &Record, w: &mut termcolor::BufferedStandardStream| -> Result<()> {
        let (h, context) = match r {
            Record::Match(h) => (h, false),
            Record::Context(h) => (h, true),
            Record::Note { path, path_bytes, text } => {
                if out.json {
                    let rec = serde_json::json!({"type": "binary", "schema": SCHEMA, "path": path, "text": text});
                    writeln!(w, "{}", with_path_bytes(rec, path_bytes.as_deref()))?;
                } else if q.with_filename {
                    w.write_all(&grep_path(path, path_bytes.as_deref(), colour))?;
                    writeln!(w, ": {text}")?;
                } else {
                    writeln!(w, "{text}")?;
                }
                return Ok(());
            }
            Record::Count { .. } | Record::File { .. } => return Ok(()),
        };
        if out.json {
            let rec = serde_json::json!({"type": if context { "context" } else { "match" }, "schema": SCHEMA, "path": h.path, "line": h.line,
                "column": h.column, "text": h.text, "spans": h.spans.iter().map(|(a, b)| serde_json::json!({"start": a, "end": b})).collect::<Vec<_>>()});
            writeln!(w, "{}", with_path_bytes(rec, h.path_bytes.as_deref()))?;
            return Ok(());
        }
        if groups {
            // `--` between lines that are not adjacent in one file, as the plain path's searcher does;
            // a line at or before the previous one starts another search of the same file
            if last.as_ref().is_some_and(|(p, s, l)| **p != *h.path || h.line > l + 1 || h.line <= *s) {
                w.write_all(b"--\n")?;
            }
            last = Some((Arc::clone(&h.path), h.line, h.line + h.text.matches('\n').count() as u64));
        }
        if !colour {
            // plain output: one assembled line, one write (the common piped case)
            linebuf.clear();
            instant::format_plain(
                &mut linebuf,
                if q.with_filename { h.path_bytes.as_deref().unwrap_or(h.path.as_bytes()) } else { b"" },
                if q.line_numbers { h.line } else { 0 },
                h.text.as_bytes(),
                context,
            );
            w.write_all(&linebuf)?;
            return Ok(());
        }
        write_colour(w, h, context, q.with_filename, q.line_numbers)?;
        Ok(())
    };
    let stats = {
        let mut sink = |r: Record| {
            match r {
                Record::Context(_) => {}
                Record::Count { .. } | Record::File { .. } => {
                    found = true;
                    counts.push(r);
                    return;
                }
                Record::Match(_) | Record::Note { .. } => found = true,
            }
            if defer {
                collected.push(r);
            } else if let Err(e) = emit(&r, &mut w) {
                if broken_pipe(&e) {
                    pipe_closed = true;
                    cancel.store(true, Ordering::Relaxed);
                }
            }
        };
        instant::search(&q, &f, Arc::clone(&cancel), Output::Records(&mut sink))?
    };
    warn_failures(&stats);
    if pipe_closed {
        return Ok(if found { 0 } else { 1 });
    }
    // a record per file searched: a file two paths reach is counted and listed twice, as ripgrep does
    // with --sort the search hands them over in ripgrep's order
    if !out.sort {
        counts.sort_by(|a, b| a.path().cmp(b.path()));
    }
    // a reader that went away (`| head`) ends the output quietly, as on the line path
    let written = (|| -> Result<()> {
        if out.count {
            for r in &counts {
                let (p, b) = (r.path(), r.path_bytes());
                let c = if let Record::Count { count, .. } = r { *count } else { 1 };
                if out.json {
                    writeln!(w, "{}", with_path_bytes(serde_json::json!({"type": "count", "schema": SCHEMA, "path": p, "count": c}), b))?;
                } else if q.with_filename {
                    w.write_all(&grep_path(p, b, colour))?;
                    writeln!(w, ":{c}")?;
                } else {
                    writeln!(w, "{c}")?;
                }
            }
        } else if out.files_with_matches {
            for r in &counts {
                let (p, b) = (r.path(), r.path_bytes());
                if out.json {
                    writeln!(w, "{}", with_path_bytes(serde_json::json!({"type": "file", "schema": SCHEMA, "path": p}), b))?;
                } else {
                    w.write_all(&grep_path(p, b, colour))?;
                    writeln!(w)?;
                }
            }
        } else if out.symbols {
            grouped_by_symbol(&out.root, &mut collected, &mut w, out.json)?;
        } else if defer {
            for r in &collected {
                emit(r, &mut w)?;
            }
        }
        if out.stats || out.json {
            // -l stops each file at its first match: the matches were not counted
            let matches = (q.report != Report::Files).then_some(stats.matches);
            let rec = serde_json::json!({"type": "summary", "schema": SCHEMA, "files_searched": stats.files_searched, "files_matched": stats.files_matched,
                "matches": matches, "bytes_searched": stats.bytes_searched, "errors": stats.errors, "elapsed_ms": stats.elapsed_ms, "cancelled": stats.cancelled});
            if out.json {
                writeln!(w, "{rec}")?;
            } else {
                eprintln!(
                    "{}{} of {} files{} ({:.1} MB) in {:.1} ms{}{}",
                    matches.map(|n| format!("{n} matches in ")).unwrap_or_default(),
                    stats.files_matched,
                    stats.files_searched,
                    if matches.is_none() { " match" } else { "" },
                    stats.bytes_searched as f64 / 1e6,
                    stats.elapsed_ms,
                    if stats.errors > 0 { format!(", {} unreadable", stats.errors) } else { String::new() },
                    if stats.cancelled { ", stopped early" } else { "" }
                );
            }
        }
        Ok(())
    })();
    if let Err(e) = written {
        if broken_pipe(&e) {
            return Ok(if found { 0 } else { 1 });
        }
        return Err(e);
    }
    if let Err(e) = w.flush() {
        if e.kind() != std::io::ErrorKind::BrokenPipe {
            return Err(e.into());
        }
    }
    if stats.cancelled && !q.max_results.map(|m| stats.matches >= m).unwrap_or(false) {
        return Ok(130);
    }
    Ok(if missing_root(&roots, &stats) {
        2
    } else if found {
        0
    } else {
        1
    })
}



fn grep_path<'p>(path: &'p str, bytes: Option<&'p [u8]>, terminal: bool) -> std::borrow::Cow<'p, [u8]> {
    use std::borrow::Cow;
    match (terminal, crate::fmt::shown(path)) {
        (true, Cow::Owned(s)) => Cow::Owned(s.into_bytes()),
        (true, Cow::Borrowed(s)) => Cow::Borrowed(s.as_bytes()),
        (false, _) => Cow::Borrowed(bytes.unwrap_or(path.as_bytes())),
    }
}


fn with_path_bytes(mut rec: serde_json::Value, bytes: Option<&[u8]>) -> serde_json::Value {
    if let Some(b) = bytes {
        rec["path_bytes"] = b.into();
    }
    rec
}



fn write_colour(w: &mut impl WriteColor, h: &instant::Line, context: bool, path: bool, number: bool) -> std::io::Result<()> {
    let sep = if context { "-" } else { ":" };
    let text = h.text.as_str();
    let mut start = 0;
    for (k, part) in text.split('\n').enumerate() {
        let end = start + part.len();
        if path {
            w.set_color(ColorSpec::new().set_fg(Some(Color::Magenta)))?;
            write!(w, "{}", crate::fmt::shown(&h.path))?;
            w.reset()?;
            write!(w, "{sep}")?;
        }
        if number {
            w.set_color(ColorSpec::new().set_fg(Some(Color::Green)))?;
            write!(w, "{}", h.line + k as u64)?;
            w.reset()?;
            write!(w, "{sep}")?;
        }
        // the spans lie on character boundaries of the text
        let mut pos = start;
        for &(a, b) in &h.spans {
            let (x, y) = (a.max(start), b.min(end));
            if x < pos || x > y || (x == y && a < b) || !text.is_char_boundary(x) || !text.is_char_boundary(y) {
                continue;
            }
            write!(w, "{}", &text[pos..x])?;
            w.set_color(ColorSpec::new().set_fg(Some(Color::Red)).set_bold(true))?;
            write!(w, "{}", &text[x..y])?;
            w.reset()?;
            pos = y;
        }
        writeln!(w, "{}", &text[pos..end])?;
        start = end + 1;
    }
    Ok(())
}

fn broken_pipe(e: &anyhow::Error) -> bool {
    e.downcast_ref::<std::io::Error>().is_some_and(|e| e.kind() == std::io::ErrorKind::BrokenPipe)
}



fn missing_root(roots: &[PathBuf], stats: &instant::Stats) -> bool {
    stats.errors > 0 && roots.iter().any(|r| r.as_os_str() != "-" && std::fs::metadata(r).is_err())
}


fn warn_failures(stats: &instant::Stats) {
    for f in &stats.failures {
        diagnostic("warning", f);
    }
    let more = stats.errors.saturating_sub(stats.failures.len() as u64);
    if more > 0 {
        diagnostic("warning", &format!("{more} more files could not be searched"));
    }
}


fn grep_plain(roots: &[PathBuf], q: &Query, f: &Files, out: GrepOutput, cancel: Arc<AtomicBool>, sink: Arc<instant::PlainSink>) -> Result<i32> {
    let stats = instant::search(q, f, Arc::clone(&cancel), Output::Plain(Arc::clone(&sink)))?;
    warn_failures(&stats);
    let found = stats.matches > 0;
    if sink.broken.load(Ordering::Relaxed) {
        return Ok(if found { 0 } else { 1 }); // the reader went away (`| head`): stop quietly
    }
    if let Err(e) = sink.flush() {
        if e.kind() != std::io::ErrorKind::BrokenPipe {
            return Err(e.into());
        }
    }
    if out.stats {
        eprintln!(
            "{} matches in {} of {} files ({:.1} MB) in {:.1} ms{}{}",
            stats.matches,
            stats.files_matched,
            stats.files_searched,
            stats.bytes_searched as f64 / 1e6,
            stats.elapsed_ms,
            if stats.errors > 0 { format!(", {} unreadable", stats.errors) } else { String::new() },
            if stats.cancelled { ", stopped early" } else { "" }
        );
    }
    if stats.cancelled && !q.max_results.map(|m| stats.matches >= m).unwrap_or(false) {
        return Ok(130);
    }
    Ok(if missing_root(roots, &stats) {
        2
    } else if found {
        0
    } else {
        1
    })
}


fn grouped_by_symbol(root: &Path, records: &mut Vec<Record>, w: &mut termcolor::BufferedStandardStream, json: bool) -> Result<()> {
    let s = open_fresh(root)?;
    let mut lines: Vec<Record> = std::mem::take(records).into_iter().filter(|r| matches!(r, Record::Match(_) | Record::Note { .. })).collect();
    // the index names a file by its path under the root, whatever path the search was given
    let mut named: std::collections::HashMap<std::sync::Arc<str>, std::sync::Arc<str>> = std::collections::HashMap::new();
    for r in &mut lines {
        let under = |p: &str| std::fs::canonicalize(p).ok().and_then(|c| c.strip_prefix(&s.ix.root).ok().map(|r| instant::slashed(r.to_string_lossy())));
        let path = match r {
            Record::Match(h) => &mut h.path,
            Record::Note { path, .. } => path,
            _ => continue,
        };
        *path = named.entry(path.clone()).or_insert_with_key(|p| under(p).map_or_else(|| p.clone(), Into::into)).clone();
    }
    lines.sort_by(|a, b| a.path().cmp(b.path()).then(a.order().cmp(&b.order())));
    for g in crate::intel::group_by_symbol(&s.ix, lines)? {
        // the text form is for a person or an agent: names escaped, as the index commands print them
        let shown = |s: &str| if json { std::borrow::Cow::Borrowed(s) } else { crate::fmt::shown(s) }.into_owned();
        let name = g
            .symbol
            .as_ref()
            .map(|r| format!("{}:{}-{}  [{}] {}", shown(&r.path), r.start, r.end, r.kind, shown(if r.qualname.is_empty() { &r.name } else { &r.qualname })));
        if json {
            let mut rec = serde_json::json!({"type": "symbol_group", "schema": SCHEMA, "symbol": name, "path": g.path,
            "matches": g.lines.iter().map(|h| serde_json::json!({"line": h.line, "text": h.text})).collect::<Vec<_>>()});
            if let Some(note) = &g.note {
                rec["note"] = note.as_str().into();
            }
            writeln!(w, "{rec}")?;
        } else {
            writeln!(w, "{}", name.unwrap_or_else(|| format!("{}  (no symbol)", shown(&g.path))))?;
            for h in &g.lines {
                writeln!(w, "    {}: {}", h.line, h.text.trim_end())?;
            }
            if let Some(note) = &g.note {
                writeln!(w, "    note: {note}")?;
            }
        }
    }
    Ok(())
}



fn find_command(root: &Path, query: &str, k: usize, json: bool, no_color: bool) -> Result<i32> {
    let has_index = crate::index::exists(root);
    let small_repo = || crate::files::list_files(root).len() <= 3000;
    // a question mark ends a question, it does not make the words a regex
    let query = if query.contains(' ') { query.trim_end().strip_suffix('?').unwrap_or(query) } else { query };
    if looks_like_regex(query) {
        let q = Query { pattern: Pattern { text: query.to_string(), mode: Mode::Regex, case: Case::Smart, ..Pattern::default() }, ..Query::default() };
        let r = grep_command(
            q,
            Files::walk(vec![root.to_path_buf()]),
            GrepOutput {
                files_with_matches: false,
                count: false,
                sort: true,
                json,
                stats: false,
                symbols: false,
                root: root.to_path_buf(),
                no_color,
                indexed: false,
                update: false,
                under: None,
            },
        );
        // nothing grepped, or not a valid regex: words with punctuation, for the ranked search
        match r {
            Ok(1) if has_index && !json => {}
            Err(_) if has_index => {}
            r => return r,
        }
    }
    if has_index || small_repo() {
        let mut s = open_fresh(root)?;
        let hits = s.recovering(|s| s.search(query, k, true))?;
        print_hits(&hits, &[query.to_string()], false, json)?;
        return Ok(if hits.is_empty() { 1 } else { 0 });
    }
    eprintln!("[scrutate] no index for this large repository: identifier search (run `scrutate index` for ranked results)");
    let q = Query { pattern: Pattern { text: query.to_string(), mode: Mode::Identifier, case: Case::Smart, ..Pattern::default() }, ..Query::default() };
    grep_command(
        q,
        Files::walk(vec![root.to_path_buf()]),
        GrepOutput {
            files_with_matches: false,
            count: false,
            sort: true,
            json,
            stats: false,
            symbols: false,
            root: root.to_path_buf(),
            no_color,
            indexed: false,
            update: false,
            under: None,
        },
    )
}

fn batch_command(root: &Path, file: &Path, features: bool, timing: bool) -> Result<i32> {
    let mut s = crate::Repo::open(root)?;
    if let Some(st) = s.refresh(0.0)?.filter(|st| st.files_changed > 0 || st.files_removed > 0) {
        eprintln!("[scrutate] indexed {} changed files ({} chunks, {:.1}s)", st.files_changed, st.chunks, st.seconds);
    }
    let f = std::fs::File::open(file)?;
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    for (n, line) in std::io::BufReader::new(f).lines().enumerate() {
        let line = line?;
        if line.trim().is_empty() {
            continue;
        }
        let req: serde_json::Value = match serde_json::from_str(&line) {
            Ok(v) => v,
            Err(e) => {
                let why = e.to_string();
                let why = why.rsplit_once(" at line ").map_or(why.as_str(), |(w, _)| w);
                writeln!(out, "{}", serde_json::json!({"error": format!("line {}, column {}: not JSON ({why})", n + 1, e.column())}))?;
                continue;
            }
        };
        if let Some(tool) = req.get("op").and_then(|v| v.as_str()) {
            // any operation, named and given arguments as an MCP tool call is
            let rec = match Op::from_tool(tool, &req).and_then(|op| s.run_as_is(&op)) {
                Ok(answer) => {
                    let mut rec = serde_json::json!({"op": tool, "result": answer.json()});
                    if let Some(stop) = answer.stopped() {
                        rec["stopped_at"] = serde_json::json!(stop.at);
                    }
                    rec
                }
                Err(e) => serde_json::json!({"op": tool, "error": e.to_string()}),
            };
            writeln!(out, "{rec}")?;
            continue;
        }
        let query = req.get("query").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let k = req.get("k").and_then(|v| v.as_u64()).unwrap_or(crate::ops::SEARCH_K as u64) as usize;
        let alt: Vec<String> =
            req.get("alt").and_then(|v| v.as_array()).map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect()).unwrap_or_default();
        let t = Instant::now();
        let mut rec = serde_json::Map::new();
        rec.insert("query".into(), serde_json::Value::String(query.clone()));
        if features {
            let c = s.recovering(|s| s.candidates(&query, true))?;
            let scores = s.score(&c.x)?;
            let hits = s.hits(&c, &scores, k, false)?;
            rec.insert("hits".into(), hits_json(&hits));
            let cands: Vec<serde_json::Value> = c
                .rows
                .iter()
                .zip(&c.x)
                .zip(&scores)
                .map(|((r, x), sc)| serde_json::json!({"id": r.id, "path": r.path, "name": r.name, "qualname": r.qualname, "kind": r.kind, "score": sc, "x": x.to_vec()}))
                .collect();
            // once per query, so a candidate's `x` stays a plain array in this order
            rec.insert("feature_names".into(), serde_json::json!(crate::search::FEATURES.as_slice()));
            rec.insert("candidates".into(), serde_json::Value::Array(cands));
            rec.insert("terms".into(), serde_json::json!(c.q.terms));
            rec.insert("lits".into(), serde_json::json!(c.q.lits));
            for source in crate::search::Source::ALL {
                rec.insert(format!("{}_ids", source.name()), serde_json::json!(c.ids(source)));
            }
        } else {
            let mut qs = vec![query.clone()];
            qs.extend(alt.iter().cloned());
            let hits = s.recovering(|s| if alt.is_empty() { s.search(&query, k, false) } else { s.search_many(&qs, k, false) })?;
            rec.insert("hits".into(), hits_json(&hits));
        }
        if timing {
            rec.insert("ms".into(), serde_json::json!(t.elapsed().as_secs_f64() * 1000.0));
        }
        writeln!(out, "{}", serde_json::Value::Object(rec))?;
    }
    Ok(0)
}




fn diagnostic(kind: &str, message: &str) {
    let json = std::env::var("SCRUTATE_DIAGNOSTICS").map(|v| v == "json").unwrap_or(false) || std::env::args_os().any(|a| a == "--json");
    if json {
        eprintln!("{}", serde_json::json!({"type": kind, "schema": SCHEMA, "message": message}));
    } else {
        eprintln!("scrutate: {}: {message}", kind.replace('_', " "));
    }
}


fn panic_text(msg: &str, location: &str) -> String {
    if msg.contains("failed to spawn thread") {
        format!("{msg} ({location}). The system refused another thread: lower -j or SCRUTATE_THREADS, or raise the process limit.")
    } else {
        format!("{msg} ({location}). If this persists run `scrutate index --force`; please report it with RUST_BACKTRACE=1.")
    }
}

pub fn main_exit() {
    // a panic is a bug, but the user still gets a one-line diagnosis and a stable exit code
    // (2 = error) instead of a backtrace dump; RUST_BACKTRACE=1 shows the details
    std::panic::set_hook(Box::new(|info| {
        let msg = info.payload().downcast_ref::<&str>().map(|s| s.to_string()).or_else(|| info.payload().downcast_ref::<String>().cloned()).unwrap_or_default();
        diagnostic("internal_error", &panic_text(&msg, &info.location().map(|l| l.to_string()).unwrap_or_default()));
    }));
    let code = match std::panic::catch_unwind(run) {
        Ok(Ok(c)) => c,
        Ok(Err(e)) => {
            diagnostic("error", &format!("{e:#}"));
            2
        }
        Err(_) => 2,
    };
    std::process::exit(code);
}

#[cfg(test)]
mod tests {
    use clap::Parser;
    use proptest::prelude::*;


    fn coloured(dir: &std::path::Path, pattern: &str, multiline: bool) -> String {
        use crate::instant::{Files, Output, Pattern, Query, Record};
        let q = Query {
            pattern: Pattern { text: pattern.into(), multiline, ..Pattern::default() },
            want_spans: true,
            text_spans: true,
            first_in_path_order: true,
            ..Query::default()
        };
        let mut records = Vec::new();
        crate::instant::search(&q, &Files::walk(vec![dir.to_path_buf()]), std::sync::Arc::default(), Output::Records(&mut |r| records.push(r))).unwrap();
        let mut w = termcolor::Buffer::ansi();
        for r in &records {
            if let Record::Match(h) = r {
                super::write_colour(&mut w, h, false, true, true).unwrap();
            }
        }
        String::from_utf8(w.into_inner()).unwrap()
    }


    fn highlighted(out: &str) -> Vec<&str> {
        out.split("\x1b[31m").skip(1).map(|s| &s[..s.find("\x1b[0m").unwrap()]).collect()
    }

    #[test]
    fn colour_highlights_the_matches_in_lines_with_invalid_utf8() {
        let root = std::env::temp_dir().join(format!("scrutate_cli_colour_inv_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("a.txt"), b"x\x80\xffabc def abc\nab\xffcd\n").unwrap();
        let out = coloured(&root, r"abc|b(?-u:\xFF)c", false);
        assert_eq!(highlighted(&out), ["abc", "abc", "b\u{FFFD}c"], "{out:?}");
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn colour_gives_each_line_of_a_multi_line_match_its_path_and_number() {
        let root = std::env::temp_dir().join(format!("scrutate_cli_colour_ml_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("m.txt"), "one\nfoo\nbar baz\nend\n").unwrap();
        let out = coloured(&root, r"foo\nbar|baz", true);
        let plain = regex::Regex::new("\x1b\\[[0-9;]*m").unwrap().replace_all(&out, "");
        assert_eq!(plain, "m.txt:2:foo\nm.txt:3:bar baz\n", "{out:?}");
        // a highlight that crosses a line break is cut at it
        assert_eq!(highlighted(&out), ["foo", "bar", "baz"], "{out:?}");
        std::fs::remove_dir_all(&root).unwrap();
    }

    #[test]
    fn grep_names_a_file_exactly_for_a_program_and_escaped_on_a_terminal() {
        let raw = b"x\xff\n.c";
        assert_eq!(&*super::grep_path("x\u{FFFD}\n.c", Some(raw), false), raw);
        assert_eq!(&*super::grep_path("x\u{FFFD}\n.c", Some(raw), true), "x\u{FFFD}\\n.c".as_bytes());
        assert_eq!(&*super::grep_path("a\nb\x1b.c", None, false), b"a\nb\x1b.c");
        assert_eq!(&*super::grep_path("a\nb\x1b.c", None, true), br"a\nb\x1b.c");
        let rec = super::with_path_bytes(serde_json::json!({"path": "x\u{FFFD}\n.c"}), Some(raw));
        assert_eq!(rec["path_bytes"], serde_json::json!([120, 255, 10, 46, 99]));
        assert!(super::with_path_bytes(serde_json::json!({"path": "a.c"}), None).get("path_bytes").is_none());
        // colour output is for a person: a line break in a name cannot start a line of its own
        let h = crate::instant::Line { path: "x\nfake.txt:1:needle".into(), path_bytes: None, line: 3, column: 1, text: "needle".into(), spans: vec![(0, 6)] };
        let mut w = termcolor::Buffer::ansi();
        super::write_colour(&mut w, &h, false, true, true).unwrap();
        let out = String::from_utf8(w.into_inner()).unwrap();
        let plain = regex::Regex::new("\x1b\\[[0-9;]*m").unwrap().replace_all(&out, "").into_owned();
        assert_eq!(plain, "x\\nfake.txt:1:needle:3:needle\n");
    }

    #[test]
    fn a_watch_whose_update_panics_goes_on_and_runs_the_next_update() {
        let root = std::env::temp_dir().join(format!("scrutate_cli_watch_panic_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&root);
        std::fs::create_dir_all(&root).unwrap();
        std::fs::write(root.join("a.txt"), "0\n").unwrap();
        let stop = std::sync::atomic::AtomicBool::new(false);
        let calls = std::sync::atomic::AtomicUsize::new(0);
        let r = std::thread::scope(|sc| {
            let watch = sc.spawn(|| {
                crate::watch::run(
                    &root,
                    &stop,
                    || {},
                    super::unwinding(|_| {
                        let n = calls.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1;
                        if n == 2 {
                            panic!("an update that panics");
                        }
                        if n > 2 {
                            stop.store(true, std::sync::atomic::Ordering::Relaxed);
                        }
                        Ok(())
                    }),
                )
            });
            let t0 = std::time::Instant::now();
            for i in 1.. {
                if watch.is_finished() || t0.elapsed().as_secs() > 30 {
                    break;
                }
                std::fs::write(root.join("a.txt"), format!("{i}\n")).unwrap();
                std::thread::sleep(std::time::Duration::from_millis(300));
            }
            stop.store(true, std::sync::atomic::Ordering::Relaxed);
            watch.join()
        });
        let _ = std::fs::remove_dir_all(&root);
        assert!(r.is_ok_and(|r| r.is_ok()), "the watch stopped at the panic");
        assert!(calls.into_inner() > 2, "no update after the panic");
    }


    fn clap_grep(args: &[String]) -> Option<(bool, super::GrepArgs)> {
        let super::GrepCli { root, no_color, cmd: super::GrepCmd::Grep(g) } = super::GrepCli::try_parse_from(args).ok()?;
        assert_eq!(root, std::path::PathBuf::from("."));
        Some((no_color, g))
    }

    // inside the shapes, near them (values that start with `-` or `=`, flags given twice) and outside
    const TOKENS: &str = "-F|-i|-S|-w|-U|-v|-l|-c|-H|-I|-n|-N|-L|-P|-z|-Fi|-nF|-iw|-lc|-HI|--fixed-strings|--ignore-case|--smart-case|--word|--count|--line-number|--no-line-number|--with-filename|--no-filename|--hidden|--no-ignore|--ident|--index|--sort|--json|--stats|--no-color|--follow|-e|-e|-ex|-Fex|-e=x|-e-x|--regexp|-g|-g|-g*.rs|--glob|-j|-j1|-j4|-Fj2|-j=2|--threads|--regexp=x|--glob=x|--threads=2|hello|a.txt|src|x y||-|--|-x|-1|01|+1|*.c|!*.h|=x|--fuzzy|--update|-A|-C|2|-h|--help|-V|--root|--max-count|-t|rs|--type-list|é|-é";

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(20000))]
        #[test]
        fn plain_grep_is_clap(sub in prop::sample::select(vec!["grep", "g"]), picks in prop::collection::vec(0..TOKENS.split('|').count(), 0..7)) {
            if std::env::vars_os().any(|(k, _)| k.as_encoded_bytes().starts_with(b"SCRUTATE_")) {
                return Ok(()); // clap would read them, and plain_grep is not asked then
            }
            let args: Vec<String> = ["scrutate", sub].into_iter().chain(picks.iter().map(|&i| TOKENS.split('|').nth(i).unwrap())).map(String::from).collect();
            if let Some(plain) = super::plain_grep(&args) {
                prop_assert_eq!(Some(plain), clap_grep(&args), "{:?}", args);
            }
        }

        #[test]
        fn plain_grep_is_clap_inside_its_shapes(
            flags in prop::sample::subsequence(vec!["-F", "-i", "-S", "-w", "-U", "-v", "-l", "-c", "-H", "-I", "-n", "-N", "--hidden", "--no-ignore", "--ident", "--no-color", "--json", "-j2"], 0..6).prop_shuffle(),
            values in prop::collection::vec(prop::sample::select(vec!["-e", "-g", "--regexp", "--glob", "", "pos"]), 0..5),
            words in prop::collection::vec("[a-z.*!/é]{0,4}", 5),
        ) {
            let mut args: Vec<String> = vec!["scrutate".into(), "grep".into()];
            for (i, v) in values.iter().enumerate() {
                match *v {
                    "pos" | "" => args.push(words[i].clone()),
                    flag => args.extend([flag.to_string(), words[i].clone()]),
                }
            }
            for (i, f) in flags.iter().enumerate() {
                args.insert(2 + (i * 3) % (args.len() - 1), f.to_string());
            }
            let plain = super::plain_grep(&args);
            let clap = clap_grep(&args);
            if plain.is_some() {
                prop_assert_eq!(plain, clap, "{:?}", args);
            } else {
                // declined only where clap fails, a value is empty, or a pattern given with -e
                // starts with a dash (clap takes that one)
                let dashed = args.windows(2).any(|w| matches!(w[0].as_str(), "-e" | "--regexp") && w[1].starts_with('-'));
                prop_assert!(clap.is_none() || dashed || args.iter().any(|a| a.is_empty()), "{:?}", args);
            }
        }
    }

    #[test]
    fn plain_grep_takes_the_common_shapes() {
        for line in [
            "grep -F -e zqxjkvbw_never_present_symbol",
            "grep -j1 -F -i -w -e a -e b",
            "g -n -U pattern src a.txt",
            "grep --no-ignore --hidden -g !.git -g !.scrutate -e x",
            "grep -Fl x -",
            "grep --ident refreshToken",
            "grep -g *.c -g *.h -e x",
        ] {
            let args: Vec<String> = std::iter::once("scrutate").chain(line.split(' ')).map(String::from).collect();
            assert!(super::plain_grep(&args).is_some(), "{line}");
        }
        let args = |s: &str| -> Vec<String> { std::iter::once("scrutate").chain(s.split(' ')).map(String::from).collect() };
        for line in ["grep -F -F x", "grep --help", "grep -A 2 x", "grep -e", "grep -- -x", "index x", "grep -j=1 x", "grep x --root ."] {
            assert!(super::plain_grep(&args(line)).is_none(), "{line}");
        }
    }

    #[test]
    fn every_variable_clap_reads_for_grep_sends_the_arguments_to_clap() {
        use clap::CommandFactory;
        let cmd = super::GrepCli::command();
        let mut read: Vec<String> = Vec::new();
        for c in std::iter::once(&cmd).chain(cmd.get_subcommands()) {
            read.extend(c.get_arguments().filter_map(|a| a.get_env()).map(|e| e.to_string_lossy().into_owned()));
        }
        read.sort();
        read.dedup();
        let mut listed: Vec<String> = super::GREP_ENV.iter().map(|s| s.to_string()).collect();
        listed.sort();
        assert_eq!(read, listed);
    }

    #[test]
    fn sizes_that_overflow_are_refused() {
        assert_eq!(super::parse_size("10M").unwrap(), 10 << 20);
        assert_eq!(super::parse_size("17179869183G").unwrap(), 17179869183 << 30);
        assert!(super::parse_size("17179869184G").is_err());
        assert!(super::parse_size("x").is_err());
    }

    #[test]
    fn a_failed_thread_spawn_does_not_blame_the_index() {
        let t = super::panic_text("failed to spawn thread: Os { code: 35 }", "x.rs:1:1");
        assert!(!t.contains("index") && t.contains("-j"), "{t}");
        assert!(super::panic_text("index out of bounds", "x.rs:1:1").contains("index --force"));
    }
}
